"""
config/__init__.py

Makes `import config as cfg` work for the class-based modelling module
(src/modeling.py).  modeling_config.__all__ controls exactly which constants
are exported — Path and other internal imports inside modeling_config are NOT
re-exported.
"""
from .modeling_config import *
