"""
data_source_config.py
Defines WHERE the source data comes from.

Keep source-system details here, not in transformation code.
"""
from .paths_config import DATA_DIR

SOURCE_FILE_NAME = "lifecycle_claims_1.xlsx"
SOURCE_FILE_PATH = DATA_DIR / SOURCE_FILE_NAME

SOURCE_SHEETS = {
    "837": "837_Claims",
    "277": "277_ClaimStatus",
    "835": "835_Remittance",
}
