"""
paths_config.py
Central path configuration for the Recovery Intelligence Modeling pipeline.

Only this file should know the physical project/output locations.
"""
from pathlib import Path

PROJECT_DIR = Path(__file__).resolve().parents[1]
BASE_DIR    = PROJECT_DIR

DATA_DIR   = BASE_DIR / "data"
OUTPUT_DIR = BASE_DIR / "output"

# Stage output areas
DATA_UNDERSTANDING_DIR      = OUTPUT_DIR / "Data_Understanding"
MERGED_DATA_DIR             = OUTPUT_DIR / "Merged_Data"
CLEANED_DATA_DIR            = OUTPUT_DIR / "Cleaned_Data"
PREPROCESSED_DATA_DIR       = OUTPUT_DIR / "Preprocessed_Data"
FEATURE_ENGINEERED_DATA_DIR = OUTPUT_DIR / "Feature_Engineered_Data"

# Model areas
MODEL_DIR        = OUTPUT_DIR / "Model"
PKL_DIR          = MODEL_DIR / "PKL"
MODEL_OUTPUT_DIR = MODEL_DIR / "Model_output"

# Operational outputs
LOGS_DIR = OUTPUT_DIR / "logs"

# Compatibility aliases
MODELS_DIR      = PKL_DIR
REPORTS_DIR     = MODEL_OUTPUT_DIR
PREDICTIONS_DIR = MODEL_OUTPUT_DIR
VALIDATION_DIR  = MODEL_OUTPUT_DIR
LOG_FILE        = LOGS_DIR / "pipeline.log"

# Stage 2: Merged data
MERGED_DATA_FILE = MERGED_DATA_DIR / "merged_data.xlsx"

# Stage 3: Cleaned merged data (before split)
MERGED_CLEANED_FILE = CLEANED_DATA_DIR / "merged_cleaned.xlsx"

# Stage 4: Train / test cleaned split 
TRAIN_CLEANED_FILE = CLEANED_DATA_DIR / "train_cleaned.xlsx"
TEST_CLEANED_FILE  = CLEANED_DATA_DIR / "test_cleaned.xlsx"

# Stage 5: Feature-engineered ADS (one file per split) 
TRAIN_ADS_FILE = FEATURE_ENGINEERED_DATA_DIR / "train_ads.xlsx"
TEST_ADS_FILE  = FEATURE_ENGINEERED_DATA_DIR / "test_ads.xlsx"

# Stage 6: Preprocessed (imputed / encoded / scaled) 
TRAIN_PREPROCESSED_FILE = PREPROCESSED_DATA_DIR / "train_preprocessed.xlsx"
TEST_PREPROCESSED_FILE  = PREPROCESSED_DATA_DIR / "test_preprocessed.xlsx"

# Model artifacts 
CHAMPION_MODEL_PKL       = PKL_DIR / "champion_model.pkl"
PREPROCESSING_BUNDLE_PKL = PKL_DIR / "preprocessing_bundle.pkl"
PAYER_LOOKUP_BUNDLE_PKL  = PKL_DIR / "payer_lookup_bundle.pkl"  # payer + early-signal lookup tables
MLFLOW_MODEL_DIR         = MODEL_DIR / "mlflow_model"            # saved MLflow pyfunc model
