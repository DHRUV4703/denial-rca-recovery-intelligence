"""
split_config.py
Configuration for Stage 4: train / test split.

All tunable parameters for the stratified-group split live here.
No business logic — just constants read by train_test_split.py.
"""
from .paths_config import MERGED_CLEANED_FILE, TRAIN_CLEANED_FILE, TEST_CLEANED_FILE, CLEANED_DATA_DIR

MERGED_CLEANED_FILE = MERGED_CLEANED_FILE
TRAIN_CLEANED_FILE  = TRAIN_CLEANED_FILE
TEST_CLEANED_FILE   = TEST_CLEANED_FILE
CLEANED_DATA_DIR    = CLEANED_DATA_DIR

# Split method: "stratified_group" splits at claim level within each
# payer_id + year + month group, stratifying on STRATIFY_COLUMN.
SPLIT_METHOD = "stratified_group"

# Date column used to extract year and month for group construction.
DATE_COLUMN = "bht_date"

# Claim-level ID column (used to avoid splitting a single claim across train/test).
CLAIM_ID_COL = "claim_control_number"

# Payer ID column (one dimension of the grouping key).
PAYER_ID_COL = "payer_id"

# Fraction of claims reserved for test within each group.
TEST_SIZE    = 0.30

# Random seed for reproducibility.
RANDOM_STATE = 42

# Target label column — used for stratification AND distribution reporting.
STRATIFY_COLUMN = "recovery_status"
