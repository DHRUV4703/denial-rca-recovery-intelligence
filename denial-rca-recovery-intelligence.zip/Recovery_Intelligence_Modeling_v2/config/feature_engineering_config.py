"""
feature_engineering_config.py
Configuration for Stage 5: business features and Analytical Dataset (ADS).

Stage 5 reads the cleaned train/test files from Stage 4 and writes two ADS
files (train_ads.xlsx + test_ads.xlsx) to Feature_Engineered_Data/.
Payer behaviour signals are computed on the training split only and then
applied to the test split to prevent target leakage.
"""
from .paths_config import (
    TRAIN_CLEANED_FILE,
    TEST_CLEANED_FILE,
    TRAIN_ADS_FILE,
    TEST_ADS_FILE,
    FEATURE_ENGINEERED_DATA_DIR,
)

TRAIN_CLEANED_FILE          = TRAIN_CLEANED_FILE
TEST_CLEANED_FILE           = TEST_CLEANED_FILE
TRAIN_ADS_FILE              = TRAIN_ADS_FILE
TEST_ADS_FILE               = TEST_ADS_FILE
FEATURE_ENGINEERED_DATA_DIR = FEATURE_ENGINEERED_DATA_DIR

# Claim details
CLAIM_CONTROL_NUMBER_COL = "claim_control_number"
INITIAL_OUTCOME_COL      = "initial_outcome"
CLAIM_DENIED_LABEL       = "Denied"
TARGET_COLUMN            = "recovery_status"
TARGET_NAMES             = ["Not Recovered", "Recovered"]

SUBMISSION_DATE_COL   = "bht_date"
FINAL_STATUS_DATE_COL = "claim_final_status_date"
PAYMENT_DATE_COL      = "payment_effective_date"
CORRECTED_SUBMISSION_CODE = 7

DIAGNOSIS_COLUMNS      = ["principal_diagnosis", "diagnosis_2", "diagnosis_3", "diagnosis_4"]
DIAGNOSIS_ABSENT_VALUE = "NONE"

MISSING_FLAG_FEATURES = {
    "has_prior_auth":             ("prior_authorization_number", "NO_AUTH"),
    "has_modifier":               ("procedure_modifier_1",       "NO_MOD"),
    "has_secondary_diagnosis":    ("diagnosis_2",                "NONE"),
    "has_billing_provider_npi":   ("billing_provider_npi",       None),
    "has_rendering_provider_npi": ("rendering_provider_npi",     None),
    "has_attachment":             ("attachment_report_type_code", None),
    "has_line_modifier":          ("line_procedure_modifier_1",  "NO_MOD"),
}

DENIAL_GROUP_FLAGS = {
    "is_oa_denial": "OA",
    "is_pi_denial": "PI",
}


RARC_ABSENT_VALUE          = "NO_CODE"
PRIOR_AUTH_ABSENT_VALUE    = "NO_AUTH"
GROUP_COL              = "GROUP"
CARC_COL               = "CARC"
RARC_COL               = "RARC"
BILLING_PROVIDER_COL   = "billing_provider_npi"
PROCEDURE_CODE_COL     = "procedure_code"
TOTAL_CLAIM_CHARGE_COL = "total_claim_charge"
TOTAL_PAID_AMOUNT_COL  = "total_paid_amount"
PRIOR_CLAIM_REF_COL    = "original_reference_number"
DENIAL_GROUP_CODES     = {"CO", "PR", "OA", "PI"}

# PAYER BEHAVIOR SETTINGS
PAYER_ID_COL            = "payer_id"
PAYER_BEHAVIOR_FEATURES = [
    "b01_flag",
    "b02_flag",
    "b03_flag",
    "b04_flag",
    "b05_flag",
    "b05_slope_per_month",
    "b06_flag",
    "b07_flag",
    "b08_flag",
    "b09_flag",
    "b10_flag",
    "b11_flag",
    "b12_flag",
]

BUNDLING_CARCS        = ["97", "236"]
SHAVE_RATIO_THRESHOLD = 0.80
PEND_STATUS_CODE      = "P1"

# EARLY SIGNAL FEATURES (E01-E03)
EARLY_SIGNAL_FEATURES = [
    # E01: Embedding Drift Velocity
    "e01_edv",
    "e01_flag",
    "e01_line_drift",
    # E02: Predicted-Denial Pressure
    "e02_pdp",
    "e02_confidence",
    "e02_flag",
    "e02_max_prob",
    "e02_line_at_risk",
    # E03: Structural Anomaly Score
    "e03_sas",
    "e03_flag",
    "e03_line_anomalous",
]

# KRI FEATURES (KRI-1 to KRI-4)
KRI_FEATURES = [
    # KRI-1: Policy Concentration Index — (payer, carc_code) level
    "kri1_carc_denied_dollars",
    "kri1_carc_denial_share",
    "kri1_pci_flag",
    # KRI-2: Family Capture Ratio — (payer, cpt_family) level
    "kri2_family_total_dollars",
    "kri2_family_denied_dollars",
    "kri2_fcr",
    "kri2_fcr_flag",
    # KRI-3: Contradiction Density — payer level
    "kri3_cd",
    "kri3_cd_dollars",
    "kri3_cd_flag",
    # KRI-4: Provider Blast Radius — (payer, carc_code) level
    "kri4_pbr_cnt",
    "kri4_pbr_pct",
    "kri4_pbr_flag",
]

# KPI FEATURES (KPI-01 to KPI-05)
KPI_FEATURES = [
    # KPI-01: QoQ Denial Risk — payer level
    "kpi01_latest_denial_rate",
    "kpi01_max_consecutive_rising",
    "kpi01_band",
    "kpi01_flag",
    # KPI-02: Recovery Rate — payer level
    "kpi02_win_rate",
    "kpi02_recovery_rate",
    "kpi02_band",
    "kpi02_flag",
    # KPI-03: Resubmission Rate — payer level
    "kpi03_resub_rate",
    "kpi03_band",
    "kpi03_flag",
    # KPI-04: Time-to-Pay — payer level
    "kpi04_median_days",
    "kpi04_band",
    "kpi04_flag",
    # KPI-05: Billed-vs-Paid Gap — payer level (informational)
    "kpi05_gap_pct",
    "kpi05_band",
    "kpi05_flag",
]

# CPT FAMILY SCRAPER SETTINGS (used by cpt_family_lookup.py)
CPT_CODE_SYSTEMS = [
    {"name": "CPT",            "url": "https://www.aapc.com/codes/cpt-codes-range/"},
    {"name": "HCPCS Level II", "url": "https://www.aapc.com/codes/hcpcs-codes-range/"},
    {"name": "ICD-10-CM",      "url": "https://www.aapc.com/codes/icd-10-codes-range/"},
    {"name": "ICD-10-PCS",     "url": "https://www.aapc.com/codes/icd-10-pcs-codes-range/"},
]
CPT_SYSTEM_PRIORITY      = [s["name"] for s in CPT_CODE_SYSTEMS]
CPT_ROW_SELECTORS        = ["div.list-code-range", "div.drg-bluebox", "div.cpt-dark-grey"]
CPT_SCRAPER_PAGE_SIZE    = 10
CPT_SCRAPER_MAX_DEPTH    = 6
CPT_SCRAPER_WAIT_SECONDS = 8
CPT_NORMALISE_THRESHOLD  = 90
