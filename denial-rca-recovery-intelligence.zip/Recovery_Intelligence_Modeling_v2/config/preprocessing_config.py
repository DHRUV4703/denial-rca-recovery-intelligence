"""
preprocessing_config.py
Configuration for Stage 3 (data cleaning) and Stage 6 (preprocessing:
imputation, encoding, and scaling).

Stage 3 reads the merged data from Stage 2 and writes a single cleaned file.
Stage 6 reads the ADS files from Stage 5, fits all transformers on the
training set only, applies them to both splits, and saves the preprocessing
bundle for downstream model inference.

Change cleaning rules or transformation rules here — data_cleaning.py and
preprocessing.py read all of them.
"""
from .paths_config import (
    MERGED_DATA_FILE,
    MERGED_CLEANED_FILE,
    CLEANED_DATA_DIR,
    TRAIN_ADS_FILE,
    TEST_ADS_FILE,
    PREPROCESSED_DATA_DIR,
    TRAIN_PREPROCESSED_FILE,
    TEST_PREPROCESSED_FILE,
    PKL_DIR,
    PREPROCESSING_BUNDLE_PKL,
)

# Pass-through aliases (so `config.VARIABLE` works in importing modules)
MERGED_DATA_FILE         = MERGED_DATA_FILE
MERGED_CLEANED_FILE      = MERGED_CLEANED_FILE
CLEANED_DATA_DIR         = CLEANED_DATA_DIR
TRAIN_ADS_FILE           = TRAIN_ADS_FILE
TEST_ADS_FILE            = TEST_ADS_FILE
PREPROCESSED_DATA_DIR    = PREPROCESSED_DATA_DIR
TRAIN_PREPROCESSED_FILE  = TRAIN_PREPROCESSED_FILE
TEST_PREPROCESSED_FILE   = TEST_PREPROCESSED_FILE
PKL_DIR                  = PKL_DIR
PREPROCESSING_BUNDLE_PKL = PREPROCESSING_BUNDLE_PKL

RANDOM_STATE = 42

NULL_THRESHOLD = 0.85

DATE_COLUMNS = [
    "bht_date",
    "claim_final_status_date",
    "service_date",
    "subscriber_dob",
    "payment_effective_date",
]

NUMERIC_COLUMNS = [
    "total_claim_charge",
    "total_paid_amount",
    "total_charge_amount",
    "patient_responsibility_amount",
    "line_charge_amount",
    "line_paid_amount",
    "adjustment_amount",
    "claim_payment_amount",
    "units",
    "units_paid",
    "submission_number",
]

INTEGER_COLUMNS = [
    "CARC",
    "procedure_code",
]

BOOLEAN_COLUMNS = [
    "is_resubmitted",
]

# Stage 6 — Imputation, Encoding, Scaling
# Change rules here; preprocessing.py reads all of them.

# Imputation groups
# For each method, list the RAW column names (before encoding).

# Fill with the literal string "None" — missing means "no code assigned"
IMPUTE_FILL_NONE = []

# Fill with the literal string "Missing" — missing is a data quality signal
IMPUTE_FILL_MISSING = []

# Drop the raw column and replace with a binary flag column instead.
# Format:  { "new_flag_column": "raw_source_column" }
# The raw column is dropped; the flag is 1 when the raw value is NOT null.
IMPUTE_DROP_TO_FLAG = {}

# Impute with the column median (missing is random or structural)
IMPUTE_MEDIAN = [
    "submission_lag_days",
    "b03_worst_rr",
    "slope_per_month",
    "b11_stale_rate",
    # Early signal continuous scores
    "e01_edv",
    "e02_pdp",
    "e02_confidence",
    "e03_sas",
]

# Impute with the column mean
IMPUTE_MEAN = []

# Impute with the column mode (most frequent value)
IMPUTE_MODE = []

# Fill missing with 0 (absence = 0 is the natural interpretation)
IMPUTE_ZERO = [
    # Payer behaviour binary flags (B01-B12)
    "b01_flag", "b02_flag", "b03_flag", "b04_flag", "b05_flag",
    "b06_flag", "b07_flag", "b08_flag", "b09_flag", "b10_flag",
    "b11_flag", "b12_flag",
    # Early signal binary flags and line-level indicators (E01-E03)
    "e01_flag", "e01_line_drift",
    "e02_flag", "e02_line_at_risk",
    "e03_flag", "e03_line_anomalous",
]

# MICE (IterativeImputer) — multivariate imputation for correlated features
IMPUTE_MICE = []

# KNN imputation — useful when missing values cluster by similar rows
IMPUTE_KNN = []
IMPUTE_KNN_NEIGHBORS = 5


# Encoding groups
# List the column names to be encoded by each method.

# One-hot encoding — low cardinality (≤ 8 unique values), no order
OHE_COLUMNS = [
    "billing_provider_taxonomy",
    "billing_provider_state",
]
OHE_DROP = "first"   # drop first category to avoid multicollinearity; set None to keep all dummies

# Frequency encoding — medium-to-high cardinality, production-safe
FREQUENCY_ENCODE_COLUMNS = []

# Binary manual mapping — exactly 2 values with a known meaning
# Format: { "column_name": { "value_to_encode_as_1": 1, "other_value": 0 } }
BINARY_MAP_COLUMNS = {}

# Ordinal / as-is — already numeric with a natural order; pass through unchanged.
ORDINAL_AS_IS_COLUMNS = [
    "units",
    "num_diagnoses",
]

# Scaling groups 
# List columns to be scaled AFTER encoding.

# RobustScaler — skewed or outlier-heavy dollar amounts and lag features
SCALE_ROBUST = [
    "total_claim_charge",
    "submission_lag_days",
]

# StandardScaler — approximately normally distributed payer behaviour metrics
SCALE_STANDARD = [
    "slope_per_month",
]

# MinMaxScaler — use when you need values bounded to [0, 1]
SCALE_MINMAX = []
