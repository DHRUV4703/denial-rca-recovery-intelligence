"""
modeling_config.py
Configuration for Stage 7: model training, hyperparameter tuning, calibration,
thresholding, and model outputs.

Imputation / encoding / scaling configuration has moved to preprocessing_config.py.
Change features, model list, tuning params, calibration, or threshold method
here — modeling.py reads all of it.
"""
from pathlib import Path

# Paths
PROJECT_DIR = Path(__file__).resolve().parents[1]
BASE_DIR    = PROJECT_DIR

MODEL_DIR        = BASE_DIR / "output" / "Model"
PKL_DIR          = MODEL_DIR / "PKL"
MODEL_OUTPUT_DIR = MODEL_DIR / "Model_output"
MODELS_DIR       = PKL_DIR
REPORTS_DIR      = MODEL_OUTPUT_DIR
PREDICTIONS_DIR  = MODEL_OUTPUT_DIR
VALIDATION_DIR   = MODEL_OUTPUT_DIR
LOGS_DIR         = BASE_DIR / "output" / "logs"
FEATURE_ENGINEERED_DATA_DIR = BASE_DIR / "output" / "Feature_Engineered_Data"
TRAIN_ADS_FILE              = FEATURE_ENGINEERED_DATA_DIR / "train_ads.xlsx"
TEST_ADS_FILE               = FEATURE_ENGINEERED_DATA_DIR / "test_ads.xlsx"

PREPROCESSED_DATA_DIR    = BASE_DIR / "output" / "Preprocessed_Data"
TRAIN_PREPROCESSED_FILE  = PREPROCESSED_DATA_DIR / "train_preprocessed.xlsx"
TEST_PREPROCESSED_FILE   = PREPROCESSED_DATA_DIR / "test_preprocessed.xlsx"

CHAMPION_MODEL_PKL       = PKL_DIR / "champion_model.pkl"
PREPROCESSING_BUNDLE_PKL = PKL_DIR / "preprocessing_bundle.pkl"
PAYER_LOOKUP_BUNDLE_PKL  = PKL_DIR / "payer_lookup_bundle.pkl"  # payer + early-signal lookup tables
MLFLOW_MODEL_DIR         = MODEL_DIR / "mlflow_model"            # saved MLflow pyfunc model
TEST_PREDICTIONS_CSV     = MODEL_OUTPUT_DIR / "recoverability_predictions.csv"
THRESHOLD_JSON           = MODEL_OUTPUT_DIR / "champion_threshold.json"
ACTUAL_VS_PREDICTED_CSV  = MODEL_OUTPUT_DIR / "actual_vs_predicted.csv"

# Merge-stage column contracts
CLAIM_CONTROL_NUMBER_COL = "claim_control_number"
CLAIM_LINE_NUMBER_COL    = "line_number"

# 1. TARGET

TARGET_COLUMN   = "recovery_status"
TARGET_ENCODING = {"Recovered": 1, "Not Recovered": 0}
TARGET_NAMES    = ["Not Recovered", "Recovered"]

# Groups excluded from training (CO/PR are operationally resolved, not predicted)
ML_EXCLUDE_GROUPS    = ["CO", "PR"]
ML_EXCLUDE_GROUP_COL = "GROUP"

# 2. FEATURE LISTS
#    Add / remove column names here to change the model's input without
#    touching modeling.py.

# Columns that are IDs, PII, post-adjudication outcomes, or duplicates.
# Stripped before any modelling work begins.
LEAKAGE_COLUMNS = [
    # Post-adjudication outcome fields — directly encode the label
    "initial_outcome", "final_outcome", "recovery_method",
    "total_paid_amount", "line_paid_amount", "payment_status_code",
    "payment_effective_date", "denied_amount", "days_to_payment",
    "time_to_final_resolution", "payment_attempts", "number_of_status_updates",
    "resubmission_count", "appeal_count", "submission_count",
    "days_to_resubmit", "days_to_adjudication",
    "days_to_first_denial",
    "adjustment_amount",
    "claim_payment_amount",
    "line_charge_amount",
    # IDs and PII
    "claim_control_number", "payer_claim_control_number",
    "root_claim_control_number", "original_reference_number",
    "claim_trace_number", "subscriber_id",
    "patient_last_name", "patient_first_name",
    "subscriber_last_name", "subscriber_first_name",
    "subscriber_gender", "subscriber_dob",
    "billing_provider_npi", "rendering_provider_npi",
    "billing_provider_name", "payer_name",
    "info_source_payer_name", "info_source_payer_id",
    "info_receiver_name", "info_receiver_id", "provider_npi",
    "bht_reference_id",
    # Raw date columns
    "bht_date", "claim_final_status_date", "service_date",
    "line_service_date", "statement_from_date", "statement_to_date",
    "admission_date", "claim_received_date",
    # Raw denial codes
    "GROUP", "CARC", "RARC",
    # Raw clinical codes
    "principal_diagnosis", "diagnosis_2", "diagnosis_3", "diagnosis_4",
    "procedure_code", "procedure_modifier_1",
    "prior_authorization_number",
    # Administrative fields not useful as model inputs
    "claim_final_status", "is_resubmitted", "is_resubmission",
    "submission_type",
    "e02_at_risk_codes",   # free-text list of CPT codes — not a model feature
    "place_of_service", "acknowledgment_status_code",
    "line_revenue_code", "line_procedure_code", "line_procedure_modifier_1",
    "facility_type_code", "units_paid",
    "attachment_report_type_code", "attachment_transmission_code",
    "revenue_code", "claim_frequency_code",
]

# Final feature list sent to the model.
# Add or remove names here when the feature set changes.
MODEL_FEATURES = [
    # Denial Reason Flags
    "is_oa_denial",
    "is_pi_denial",
    "has_rarc",
    # Claim Characteristics
    "submission_lag_days",
    "total_claim_charge",
    "units",
    "num_diagnoses",
    "has_attachment",
    "has_prior_auth",
    "has_billing_provider_npi",
    "has_rendering_provider_npi",
    "resubmission_indicator",
    "resubmission_count_per_claim",
    "denial_count",
    # Payer Behaviour Signals (B01-B12)
    "b01_flag", "b01_confidence",
    "b02_flag", "b02_confidence",
    "b03_flag", "b03_confidence",
    "b04_flag", "b04_confidence",
    "b05_flag", "b05_slope_per_month", "b05_total_drift", "b05_confidence",
    "b06_flag", "b06_confidence",
    "b07_flag", "b07_confidence",
    "b08_flag", "b08_confidence",
    "b09_flag", "b09_confidence",
    "b10_flag", "b10_confidence",
    "b11_flag", "b11_confidence",
    "b12_flag", "b12_confidence",
    # Early Signal Features (E01-E03)
    "e01_edv",
    "e01_flag",
    "e01_line_drift",
    "e02_pdp",
    "e02_confidence",
    "e02_flag",
    "e02_line_at_risk",
    "e03_sas",
    "e03_flag",
    "e03_line_anomalous",
]

# 3. CROSS-VALIDATION

RANDOM_STATE = 42
CV_FOLDS     = 5


# 4. CLASS IMBALANCE HANDLING
#    Options: None | "class_weight" | "SMOTE" | "RandomUnderSampling" | "NearMiss"

IMBALANCE_METHOD = "class_weight"

IMBALANCE_METHOD_PARAMS = {
    "NearMiss":            {"version": 1, "n_neighbors": 5},
    "SMOTE":               {"sampling_strategy": 0.3},
    "RandomUnderSampling": {"sampling_strategy": 0.5},
}

# 5. HYPERPARAMETER TUNING
#    TUNING_METHOD: "RandomizedSearchCV" | "GridSearchCV" | "none"
#    N_ITER: number of random combinations for RandomizedSearchCV

TUNING_METHOD = "RandomizedSearchCV"
N_ITER        = 20

# 6. PROBABILITY CALIBRATION
#    CALIBRATION_METHOD: "isotonic" | "sigmoid" | "both"
CALIBRATION_METHOD       = "both"
CALIBRATION_HOLDOUT_SIZE = 0.20

# 7. THRESHOLD SELECTION
#    "youdens_j" | "f1_optimal" | "cost_sensitive" | "min_precision_floor" | "sweep"
THRESHOLD_METHOD = "f1_optimal"

# Parameters for "cost_sensitive"
THRESHOLD_FP_COST = 1.0
THRESHOLD_FN_COST = 3.0

# Parameters for "min_precision_floor"
THRESHOLD_MIN_PRECISION = 0.70

# Parameters for "sweep"
THRESHOLD_SWEEP_START  = 0.10
THRESHOLD_SWEEP_STOP   = 0.90
THRESHOLD_SWEEP_STEP   = 0.01
THRESHOLD_SWEEP_METRIC = "f1"

# Safety guard — if any method returns a threshold outside this range fall back
THRESHOLD_GUARD_LOWER = 0.05
THRESHOLD_GUARD_UPPER = 0.95
DEFAULT_THRESHOLD     = 0.50

# 8. OUTPUT FILE NAMES
MODEL_COMPARISON_CSV     = "model_comparison.csv"
TRAIN_TEST_METRICS_XLSX  = "train_test_metrics.xlsx"

# 9. MODELLING MODULE CONSTANTS
#    Required by the class-based modelling module (DenialModelBase hierarchy).
#    Defined in __all__ below so `import config as cfg` exposes them.

# Alias — modelling module uses RANDOM_SEED; pipeline uses RANDOM_STATE
RANDOM_SEED = RANDOM_STATE

# Catch-rate gate
CATCH_RATE_THRESHOLD     = 40.0
PROBABILITY_SPREAD_MIN   = 0.40
PROBABILITY_DISTINCT_MIN = 40

# Calibration aliases
CALIBRATION_SIZE    = CALIBRATION_HOLDOUT_SIZE
CALIBRATION_SEED    = 0

# Threshold aliases
THRESHOLD_FALLBACK      = DEFAULT_THRESHOLD
THRESHOLD_SWEEP_ENABLED = True
THRESHOLD_SELECT_METRIC = THRESHOLD_SWEEP_METRIC
CALIBRATION_METHODS     = ["isotonic", "sigmoid"]

# Search strategy
GRID_SEARCH_MAX_COMBINATIONS = 50

# Per-model random-search budgets
TUNE_N_ITER                   = N_ITER
XGBOOST_N_ITER                = 20
LIGHTGBM_N_ITER               = 20
RF_N_ITER                     = 20
GRADIENT_BOOSTING_N_ITER      = 20
SVM_N_ITER                    = 15
CATBOOST_N_ITER               = 20
HIST_GRADIENT_BOOSTING_N_ITER = 20
MLP_N_ITER                    = 15
SGD_N_ITER                    = 15

# Default hyperparameters (one dict per model class)
XGBOOST_DEFAULTS = dict(
    n_estimators=100, max_depth=4, learning_rate=0.1,
    subsample=0.8, colsample_bytree=0.8,
)
LIGHTGBM_DEFAULTS = dict(
    n_estimators=100, num_leaves=31, learning_rate=0.1,
)
RANDOM_FOREST_DEFAULTS = dict(
    n_estimators=100, max_depth=None, min_samples_split=2,
)
LOGISTIC_REGRESSION_DEFAULTS = dict(
    C=1.0, max_iter=1000, solver="lbfgs",
)
GRADIENT_BOOSTING_DEFAULTS = dict(
    n_estimators=100, max_depth=3, learning_rate=0.1,
    subsample=0.8, min_samples_split=2,
)
EXTRA_TREES_DEFAULTS = dict(
    n_estimators=100, max_depth=None, min_samples_split=2,
)
ADA_BOOST_DEFAULTS = dict(
    n_estimators=50, learning_rate=1.0,
)
DECISION_TREE_DEFAULTS = dict(
    max_depth=5, min_samples_split=2, criterion="gini",
)
SVM_DEFAULTS = dict(
    C=1.0, kernel="rbf", gamma="scale",
)
KNN_DEFAULTS = dict(
    n_neighbors=5, weights="uniform", metric="minkowski",
)
NAIVE_BAYES_DEFAULTS = dict(
    var_smoothing=1e-9,
)
CATBOOST_DEFAULTS = dict(
    iterations=100, depth=6, learning_rate=0.1, l2_leaf_reg=3,
)
HIST_GRADIENT_BOOSTING_DEFAULTS = dict(
    max_iter=100, max_depth=None, learning_rate=0.1, min_samples_leaf=20,
)
MLP_DEFAULTS = dict(
    hidden_layer_sizes=(100,), activation="relu", solver="adam",
    alpha=0.0001, max_iter=500,
)
BAGGING_DEFAULTS = dict(
    n_estimators=10, max_samples=1.0, max_features=1.0,
)
LDA_DEFAULTS = dict(
    solver="svd", shrinkage=None,
)
QDA_DEFAULTS = dict(reg_param=0.1)
SGD_DEFAULTS = dict(
    loss="log_loss", penalty="l2", alpha=0.0001, max_iter=1000,
)
BERNOULLI_NB_DEFAULTS  = dict(alpha=1.0, binarize=0.0)
COMPLEMENT_NB_DEFAULTS = dict(alpha=1.0)

# Ensemble membership
VOTING_ENSEMBLE_MEMBERS   = ("XGBoost", "LightGBM", "Random Forest", "Logistic Regression")
STACKING_ENSEMBLE_MEMBERS = ("XGBoost", "LightGBM", "Random Forest", "Logistic Regression")
BOOSTING_ENSEMBLE_MEMBERS = ("XGBoost", "LightGBM", "Gradient Boosting", "CatBoost")
STACKING_CV_FOLDS    = 5
STACKING_PASSTHROUGH = False

# FastAI tabular (disabled by default)
FASTAI_ENABLED       = False
FASTAI_EPOCHS        = 20
FASTAI_BATCH_SIZE    = 256
FASTAI_LAYERS        = [200, 100]
FASTAI_BASE_LR       = None
FASTAI_PATIENCE      = 3
FASTAI_USE_LR_FINDER = True
FASTAI_VALID_SIZE    = 0.2

# Explainability
XAI_ENABLED             = False  # set True to re-enable SHAP/explainability reports
XAI_TOP_N_FEATURES      = 15
XAI_PERMUTATION_REPEATS = 5
XAI_SHAP_MAX_SAMPLES    = 200

# Path aliases required by class-based modelling module default parameters
# (evaluated at function-definition time when `import config as cfg` runs)
CHAMPION_MODEL_PATH       = CHAMPION_MODEL_PKL
MODEL_THRESHOLD_PATH      = THRESHOLD_JSON
XAI_CHAMPION_REPORT_PATH  = MODEL_OUTPUT_DIR / "xai_champion_report.csv"
XAI_BUSINESS_SUMMARY_PATH = MODEL_OUTPUT_DIR / "champion_business_summary.csv"

# __all__ — controls what `from .modeling_config import *` exports.
# config/__init__.py uses this so `import config as cfg` exposes exactly
# the constants the class-based modelling module needs at import time.
__all__ = [
    # Core
    "RANDOM_SEED",
    "CV_FOLDS",
    # Calibration
    "CALIBRATION_SIZE",
    "CALIBRATION_SEED",
    "CALIBRATION_METHODS",
    # Champion gate
    "CATCH_RATE_THRESHOLD",
    "PROBABILITY_SPREAD_MIN",
    "PROBABILITY_DISTINCT_MIN",
    # Threshold
    "THRESHOLD_GUARD_UPPER",
    "THRESHOLD_GUARD_LOWER",
    "THRESHOLD_FALLBACK",
    "THRESHOLD_SWEEP_ENABLED",
    "THRESHOLD_SWEEP_START",
    "THRESHOLD_SWEEP_STOP",
    "THRESHOLD_SWEEP_STEP",
    "THRESHOLD_SELECT_METRIC",
    # Search strategy
    "GRID_SEARCH_MAX_COMBINATIONS",
    # Search budgets
    "TUNE_N_ITER",
    "XGBOOST_N_ITER",
    "LIGHTGBM_N_ITER",
    "RF_N_ITER",
    "GRADIENT_BOOSTING_N_ITER",
    "SVM_N_ITER",
    "CATBOOST_N_ITER",
    "HIST_GRADIENT_BOOSTING_N_ITER",
    "MLP_N_ITER",
    "SGD_N_ITER",
    # Model defaults
    "XGBOOST_DEFAULTS",
    "LIGHTGBM_DEFAULTS",
    "RANDOM_FOREST_DEFAULTS",
    "LOGISTIC_REGRESSION_DEFAULTS",
    "GRADIENT_BOOSTING_DEFAULTS",
    "EXTRA_TREES_DEFAULTS",
    "ADA_BOOST_DEFAULTS",
    "DECISION_TREE_DEFAULTS",
    "SVM_DEFAULTS",
    "KNN_DEFAULTS",
    "NAIVE_BAYES_DEFAULTS",
    "CATBOOST_DEFAULTS",
    "HIST_GRADIENT_BOOSTING_DEFAULTS",
    "MLP_DEFAULTS",
    "BAGGING_DEFAULTS",
    "LDA_DEFAULTS",
    "QDA_DEFAULTS",
    "SGD_DEFAULTS",
    "BERNOULLI_NB_DEFAULTS",
    "COMPLEMENT_NB_DEFAULTS",
    # Ensembles
    "VOTING_ENSEMBLE_MEMBERS",
    "STACKING_ENSEMBLE_MEMBERS",
    "BOOSTING_ENSEMBLE_MEMBERS",
    "STACKING_CV_FOLDS",
    "STACKING_PASSTHROUGH",
    # FastAI
    "FASTAI_ENABLED",
    "FASTAI_EPOCHS",
    "FASTAI_BATCH_SIZE",
    "FASTAI_LAYERS",
    "FASTAI_BASE_LR",
    "FASTAI_PATIENCE",
    "FASTAI_USE_LR_FINDER",
    "FASTAI_VALID_SIZE",
    # XAI
    "XAI_ENABLED",
    "XAI_TOP_N_FEATURES",
    "XAI_PERMUTATION_REPEATS",
    "XAI_SHAP_MAX_SAMPLES",
    # Path aliases (required as function-default parameter values)
    "CHAMPION_MODEL_PATH",
    "MODEL_THRESHOLD_PATH",
    "XAI_CHAMPION_REPORT_PATH",
    "XAI_BUSINESS_SUMMARY_PATH",
]
