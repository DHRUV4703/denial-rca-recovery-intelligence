"""
merge_config.py
Configuration for Stage 2: 837 + 277 + 835 data merging.
"""
from .data_source_config import SOURCE_FILE_PATH, SOURCE_SHEETS
from .paths_config import MERGED_DATA_FILE

DATA_FILE = SOURCE_FILE_PATH
MERGED_ADS_FILE = MERGED_DATA_FILE


SHEET_837 = "837_Claims"
SHEET_277 = "277_ClaimStatus"
SHEET_835 = "835_Remittance"

COLS_DROP_FROM_277 = [
    "transaction_set",
    "implementation_convention_reference",
    "transaction_set_control_number",
    "is_resubmitted",
    "original_reference_number",
    "bht_date",
    "bht_reference_id",
    "subscriber_first_name",
    "subscriber_id",
    "subscriber_last_name",
    "total_claim_charge",
]

COLS_DROP_FROM_835 = [
    "transaction_set",
    "implementation_convention_reference",
    "transaction_set_control_number",
    "claim_filing_indicator",
    "claim_frequency_code",
    "line_charge_amount",
    "patient_first_name",
    "patient_last_name",
    "payer_id",
    "payer_name",
    "rendering_provider_npi",
    "statement_from_date",
    "statement_to_date",
    "claim_status_code",
    "payer_claim_control_number",
    "is_resubmitted",
    "original_reference_number",
]

CLAIM_FREQ_SUBMISSION_TYPE_MAP = {1: "Original", 7: "Corrected", 8: "Void"}
CORRECTED_SUBMISSION_LABEL     = CLAIM_FREQ_SUBMISSION_TYPE_MAP[7]
DEDUP_SUBMISSION_TYPES         = [CLAIM_FREQ_SUBMISSION_TYPE_MAP[7],
                                   CLAIM_FREQ_SUBMISSION_TYPE_MAP[8]]

# Primary key column names used across pipeline stages
CLAIM_CONTROL_NUMBER_COL     = "claim_control_number"
CLAIM_LINE_NUMBER_COL        = "line_number"
SUBMISSION_DATE_COL          = "bht_date"
FINAL_STATUS_DATE_COL        = "claim_final_status_date"
PAYMENT_DATE_COL             = "payment_effective_date"
GROUP_COL                    = "GROUP"

# Model target values produced by this stage and consumed downstream.
TARGET_COLUMN = "recovery_status"
TARGET_NAMES  = ["Not Recovered", "Recovered"]

# Derived outcome column names (written by data_merging.py, read by downstream stages)
INITIAL_OUTCOME_COL          = "initial_outcome"
FINAL_OUTCOME_COL            = "final_outcome"
RECOVERY_METHOD_COL          = "recovery_method"

# Business outcome label strings for initial / final adjudication outcome
CLAIM_DENIED_LABEL           = "Denied"
CLAIM_PAID_LABEL             = "Paid"

# Recovery status category label for claims paid on first submission (excluded from modelling)
FIRST_PAID_LABEL             = "First Paid"

# Recovery method labels for Recovered claims
RECOVERY_METHOD_RESUBMISSION = "Resubmission"
RECOVERY_METHOD_APPEAL       = "Appeal"

