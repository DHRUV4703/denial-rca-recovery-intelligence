# 04- Train_Test_Split.py

"""
train_test_split.py - Stage 4: Train / Test Split

Reads the cleaned merged dataset produced by Stage 3 and splits it into a
training set and a test set using stratified group splitting.

Strategy
--------
- Unit of split   : claim (claim_control_number) — no claim is shared across sets.
- Grouping key    : payer_id + year + month (derived from bht_date).
- Stratification  : recovery_status (target label) within each group.

This ensures both Train and Test contain the same payer-month-year distribution
and the same class ratio (recoverable / non-recoverable) as the full dataset.

Input  : output/Cleaned_Data/merged_cleaned.xlsx
Output : output/Cleaned_Data/train_cleaned.xlsx
         output/Cleaned_Data/test_cleaned.xlsx
"""

import logging
import os
import sys

import pandas as pd
from sklearn.model_selection import train_test_split as _sk_split

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import config.split_config as config

logger = logging.getLogger(__name__)


def load_data():
    print(f"\nStep 0: Load cleaned merged data")
    print(f"  Input : {config.MERGED_CLEANED_FILE}")

    if not os.path.exists(config.MERGED_CLEANED_FILE):
        raise FileNotFoundError(
            f"Cleaned data not found at:\n  {config.MERGED_CLEANED_FILE}\n"
            "Run data_cleaning.py first."
        )

    df = pd.read_excel(config.MERGED_CLEANED_FILE)
    print(f"  Loaded : {df.shape[0]:,} rows x {df.shape[1]} columns")
    logger.info("INPUT  : %s | %d rows x %d cols", config.MERGED_CLEANED_FILE, df.shape[0], df.shape[1])
    logger.info("Columns (%d): %s", len(df.columns), ", ".join(df.columns.tolist()))
    return df


def split_data(df):
    date_col  = config.DATE_COLUMN       # bht_date
    label_col = config.STRATIFY_COLUMN   # recovery_status
    claim_col = config.CLAIM_ID_COL      # claim_control_number
    payer_col = config.PAYER_ID_COL      # payer_id

    print(f"\nStep A: Stratified-group train / test split")
    print(f"  Group key  : {payer_col} + year + month  (date from {date_col})")
    print(f"  Stratify on: {label_col}")
    print(f"  Test size  : {config.TEST_SIZE:.0%}  |  seed: {config.RANDOM_STATE}")

    # ── 1. Validate required columns ────────────────────────────────────────
    for col in [date_col, claim_col, payer_col, label_col]:
        if col not in df.columns:
            raise ValueError(
                f"Required column '{col}' not found. Available: {list(df.columns)}"
            )

    df = df.copy()
    df[date_col] = pd.to_datetime(df[date_col], errors="coerce")

    null_dates = df[date_col].isna().sum()
    if null_dates > 0:
        print(f"  WARNING: {null_dates:,} rows have null/unparseable {date_col} — dropped.")
        logger.warning("Dropped %d rows with null %s before split.", null_dates, date_col)
        df = df.dropna(subset=[date_col]).reset_index(drop=True)

    # ── 2. Build claim-level summary (one row per unique claim) ─────────────
    df["_year"]  = df[date_col].dt.year
    df["_month"] = df[date_col].dt.month

    claim_df = (
        df.drop_duplicates(claim_col)
          [[claim_col, payer_col, "_year", "_month", label_col]]
          .copy()
          .reset_index(drop=True)
    )

    n_claims_total = len(claim_df)
    n_groups       = claim_df.groupby([payer_col, "_year", "_month"]).ngroups
    print(f"\n  Unique claims : {n_claims_total:,}")
    print(f"  Unique groups : {n_groups:,}  ({payer_col} × year × month)")

    # 3. Split claims within each group 
    train_claims   = []
    test_claims    = []
    fallback_groups = 0  # groups where stratification fell back to random

    for _, grp in claim_df.groupby([payer_col, "_year", "_month"]):
        n = len(grp)
        ids = grp[claim_col].tolist()

        # Groups with only 1 claim cannot be split — send to train
        if n <= 1:
            train_claims.extend(ids)
            continue

        n_test  = max(1, int(round(n * config.TEST_SIZE)))
        n_train = n - n_test
        if n_train < 1:
            train_claims.extend(ids)
            continue

        labels = grp[label_col].values
        min_class_n = pd.Series(labels).value_counts().min()

        try:
            # Stratified split: requires >= 2 samples per class in each split
            if min_class_n >= 2 and n_test >= len(pd.Series(labels).unique()):
                tr, te = _sk_split(
                    ids,
                    test_size=n_test,
                    random_state=config.RANDOM_STATE,
                    stratify=labels,
                )
            else:
                raise ValueError("too few samples per class for stratification")
        except ValueError:
            # Fall back to plain random split for this group
            fallback_groups += 1
            tr, te = _sk_split(
                ids,
                test_size=n_test,
                random_state=config.RANDOM_STATE,
            )

        train_claims.extend(tr)
        test_claims.extend(te)

    # ── 4. Map claim assignments back to row level ───────────────────────────
    train_claim_set = set(train_claims)
    test_claim_set  = set(test_claims)

    train_df = df[df[claim_col].isin(train_claim_set)].copy().reset_index(drop=True)
    test_df  = df[df[claim_col].isin(test_claim_set)].copy().reset_index(drop=True)

    # Drop the helper year/month columns we added (keep data clean)
    for _c in ["_year", "_month"]:
        train_df.drop(columns=[_c], inplace=True, errors="ignore")
        test_df.drop(columns=[_c], inplace=True, errors="ignore")
        df.drop(columns=[_c], inplace=True, errors="ignore")

    n_total = len(train_df) + len(test_df)
    print(f"\n  Train rows : {len(train_df):,}  ({len(train_df) / n_total:.0%})")
    print(f"  Test rows  : {len(test_df):,}  ({len(test_df)  / n_total:.0%})")
    if fallback_groups:
        print(f"  Groups using random (no-stratify) fallback: {fallback_groups}")

    logger.info(
        "STEP A — stratified-group split | train=%d rows (%.0f%%) | test=%d rows (%.0f%%) | "
        "groups=%d | fallback=%d",
        len(train_df), len(train_df) / n_total * 100,
        len(test_df),  len(test_df)  / n_total * 100,
        n_groups, fallback_groups,
    )

    # 5. Label distribution report
    if label_col in train_df.columns:
        print(f"\n  {label_col} distribution in train:")
        for lbl, cnt in train_df[label_col].value_counts().items():
            print(f"    {str(lbl):20s} : {cnt:,}  ({cnt / len(train_df):.1%})")
        print(f"\n  {label_col} distribution in test:")
        for lbl, cnt in test_df[label_col].value_counts().items():
            print(f"    {str(lbl):20s} : {cnt:,}  ({cnt / len(test_df):.1%})")

    return train_df, test_df


def save_splits(train_df, test_df):
    print(f"\nStep B: Save splits")

    os.makedirs(config.CLEANED_DATA_DIR, exist_ok=True)

    train_df.to_excel(config.TRAIN_CLEANED_FILE, index=False, engine="openpyxl")
    test_df.to_excel(config.TEST_CLEANED_FILE,  index=False, engine="openpyxl")

    print(f"  Train saved : {config.TRAIN_CLEANED_FILE}  ({train_df.shape[0]:,} rows x {train_df.shape[1]} cols)")
    print(f"  Test  saved : {config.TEST_CLEANED_FILE}  ({test_df.shape[0]:,} rows x {test_df.shape[1]} cols)")
    logger.info("OUTPUT train : %s | %d rows x %d cols", config.TRAIN_CLEANED_FILE, train_df.shape[0], train_df.shape[1])
    logger.info("OUTPUT test  : %s | %d rows x %d cols", config.TEST_CLEANED_FILE,  test_df.shape[0],  test_df.shape[1])
    logger.info("Columns (%d): %s", len(train_df.columns), ", ".join(train_df.columns.tolist()))


def run():
    logger.info("Stage 4 - Train/Test Split started.")
    logger.info("INPUT  : %s", config.MERGED_CLEANED_FILE)
    logger.info("OUTPUT : %s  |  %s", config.TRAIN_CLEANED_FILE, config.TEST_CLEANED_FILE)

    df = load_data()
    train_df, test_df = split_data(df)
    save_splits(train_df, test_df)

    logger.info(
        "Stage 4 complete. Train: %d rows, Test: %d rows.",
        len(train_df), len(test_df),
    )
    print("\nStage 4 complete.\n")


if __name__ == "__main__":
     # Configure logging when the script is executed directly.
    logging.basicConfig(level=logging.INFO, format="%(asctime)s  %(levelname)s  %(message)s")
    run()
