# 06- Payer_Behaviours.py
"""
Payer_Behaviours.py - Payer Behaviors (B01-B12) + EBS (E01-E03)

Called by feature_engineering.py (orchestrator).
Leakage-safe: all signals computed on TRAINING split only, applied to test
via payer_id LEFT JOIN.
"""

import os
import sys

import joblib
import numpy as np
import pandas as pd
from scipy.stats import norm, linregress

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import config.feature_engineering_config as config

import logging
logger = logging.getLogger(__name__)

# PAYER BEHAVIOR FUNCTIONS (B01-B12)

def find_break(df, claim_level=False, claim_id=[], min_n=20, p_thresh=0.05, rr_thresh=1.1, conf_thresh=0.80):
    """B01 - Sudden Denial Rate Jump"""
    if claim_level:
        df = df[df["claim_id"].isin(claim_id)]

    claims = df.drop_duplicates("claim_id")[[
        "claim_id", "payer_id", "service_date", "claim_denial_flag"
    ]].copy()
    claims["month"] = claims["service_date"].dt.to_period("M")

    def scan(g):
        monthly = (
            g.groupby("month")
             .agg(n_claims=("claim_id", "size"), n_denied=("claim_denial_flag", "sum"))
             .reset_index().sort_values("month")
        )
        for i in range(1, len(monthly)):
            before = monthly.iloc[:i]
            after  = monthly.iloc[i:]
            n1, x1 = before["n_claims"].sum(), before["n_denied"].sum()
            n2, x2 = after["n_claims"].sum(),  after["n_denied"].sum()
            if n1 < min_n or n2 < min_n:
                continue
            p1, p2 = x1 / n1, x2 / n2
            p_pool = (x1 + x2) / (n1 + n2)
            se     = (p_pool * (1 - p_pool) * (1 / n1 + 1 / n2)) ** 0.5
            z      = (p2 - p1) / se if se > 0 else 0
            p_val  = round(1 - norm.cdf(z), 6)
            rr     = round(p2 / p1, 4) if p1 > 0 else float("nan")
            c1 = min(1 - p_val, 1.0)
            c2 = min((rr - 1) / 4, 1.0) if rr > 1 else 0.0
            c3 = min(n2 / 200, 1.0)
            c4 = 0.1 if z > 0 else 0.0
            confidence = round(min(c1*0.4 + c2*0.3 + c3*0.2 + c4, 1.0), 4)
            if p_val < p_thresh and rr >= rr_thresh and confidence >= conf_thresh:
                return pd.Series({
                    "break_month": monthly.iloc[i]["month"], "rate_before": round(p1, 4),
                    "rate_after": round(p2, 4), "z": round(z, 4),
                    "n_before": int(n1), "n_after": int(n2),
                    "p_value": p_val, "relative_risk": rr, "confidence": confidence, "b01_flag": True,
                })
        return pd.Series({"break_month": None, "rate_before": None, "rate_after": None,
                          "z": None, "n_before": None, "n_after": None,
                          "p_value": None, "relative_risk": None, "confidence": None, "b01_flag": False})

    rows = []
    for payer, g in claims.groupby("payer_id"):
        row = scan(g); row["payer_id"] = payer; rows.append(row)
    payer_df = pd.DataFrame(rows).sort_values("break_month", ascending=True).reset_index(drop=True)

    feat = (payer_df[["payer_id", "break_month", "b01_flag", "confidence"]]
            .rename(columns={"break_month": "b01_break_month", "confidence": "b01confidence"}))
    df = df.drop(columns=[c for c in df.columns if c.startswith("b01_")], errors="ignore")
    df_out = df.merge(feat, on="payer_id", how="left")
    claim_month = df_out["service_date"].dt.to_period("M")
    break_month = df_out["b01_break_month"]
    df_out["b01_flag"] = (
        df_out["b01_flag"].fillna(False).astype(bool) &
        break_month.notna() &
        (claim_month >= break_month.where(break_month.notna(), claim_month))
    ).astype(int)
    return df_out, payer_df


def find_excuse_shift(df, claim_level=False, claim_id=[], min_n=15, psi_thresh=1.0, p_thresh=0.05, conf_thresh=0.80):
    """B02 - The Excuses Change (denial reason-code mix shift)"""
    if claim_level:
        df = df[df["claim_id"].isin(claim_id)]

    denied = df.drop_duplicates("claim_id")
    denied = denied[denied["claim_denial_flag"] == 1][[
        "claim_id", "payer_id", "service_date", "carc"
    ]].dropna(subset=["carc"]).copy()
    denied["month"] = denied["service_date"].dt.to_period("M")

    def scan(g):
        months = sorted(g["month"].unique())
        for i in range(1, len(months)):
            before = g[g["month"] < months[i]]
            after  = g[g["month"] >= months[i]]
            n1, n2 = len(before), len(after)
            if n1 < min_n or n2 < min_n:
                continue
            mix1 = before["carc"].value_counts(normalize=True)
            mix2 = after["carc"].value_counts(normalize=True)
            reasons = mix1.index.union(mix2.index)
            p1 = mix1.reindex(reasons, fill_value=0) + 1e-4
            p2 = mix2.reindex(reasons, fill_value=0) + 1e-4
            psi = ((p2 - p1) * np.log(p2 / p1)).sum()
            top_reason  = (p2 - p1).idxmax()
            cnt_before  = (before["carc"] == top_reason).sum()
            cnt_after   = (after["carc"]  == top_reason).sum()
            rate_before = (cnt_before + 0.5) / (n1 + 1)
            expected    = rate_before * n2
            z_poisson   = (cnt_after - expected) / np.sqrt(expected) if expected > 0 else 0
            p_val       = round(1 - norm.cdf(z_poisson), 6)
            c1 = min(1 - p_val, 1.0)
            c2 = min(psi / psi_thresh, 1.0)
            c3 = min(n2 / 200, 1.0)
            c4 = 0.1 if (mix2.get(top_reason, 0) > mix1.get(top_reason, 0)) else 0.0
            confidence = round(min(c1*0.4 + c2*0.3 + c3*0.2 + c4, 1.0), 4)
            if psi > psi_thresh and p_val < p_thresh and confidence >= conf_thresh:
                return pd.Series({
                    "break_month": months[i], "psi": round(psi, 4), "top_reason": top_reason,
                    "share_before": round(mix1.get(top_reason, 0), 4),
                    "share_after":  round(mix2.get(top_reason, 0), 4),
                    "n_before": int(n1), "n_after": int(n2),
                    "z": round(z_poisson, 4), "p_value": p_val, "confidence": confidence, "b02_flag": True,
                })
        return pd.Series({"break_month": None, "psi": None, "top_reason": None,
                          "share_before": None, "share_after": None,
                          "n_before": None, "n_after": None, "z": None,
                          "p_value": None, "confidence": None, "b02_flag": False})

    rows = []
    for payer, g in denied.groupby("payer_id"):
        row = scan(g); row["payer_id"] = payer; rows.append(row)
    payer_df = pd.DataFrame(rows).sort_values("break_month", ascending=True).reset_index(drop=True)

    feat = (payer_df[["payer_id", "break_month", "top_reason", "b02_flag", "confidence"]]
            .rename(columns={"break_month": "b02_break_month", "top_reason": "b02_top_reason",
                             "confidence": "b02confidence"}))
    df = df.drop(columns=[c for c in df.columns if c.startswith("b02_")], errors="ignore")
    df_out = df.merge(feat, on="payer_id", how="left")
    claim_month = df_out["service_date"].dt.to_period("M")
    break_month = df_out["b02_break_month"]
    df_out["b02_flag"] = (
        df_out["b02_flag"].fillna(False).astype(bool) &
        break_month.notna() &
        (claim_month >= break_month.where(break_month.notna(), claim_month))
    ).astype(int)
    return df_out, payer_df


def find_coverage_shrinkage(df, claim_level=False, claim_id=[], min_n=5, p_thresh=0.05, rr_thresh=0.75, conf_thresh=0.80):
    """B03 - That's Not Necessary Anymore (CPT-level coverage shrinkage)"""
    if claim_level:
        df = df[df["claim_id"].isin(claim_id)]

    lines = df[["claim_id", "payer_id", "service_date", "billed_cpt", "claim_denial_flag"]].dropna(subset=["billed_cpt"]).copy()
    lines["month"]     = lines["service_date"].dt.to_period("M")
    lines["paid_flag"] = 1 - lines["claim_denial_flag"]

    def scan(g):
        for cpt, cg in g.groupby("billed_cpt"):
            months = sorted(cg["month"].unique())
            for i in range(1, len(months)):
                before = cg[cg["month"] < months[i]]
                after  = cg[cg["month"] >= months[i]]
                n1, x1 = len(before), before["paid_flag"].sum()
                n2, x2 = len(after),  after["paid_flag"].sum()
                if n1 < min_n or n2 < min_n or x1 == 0:
                    continue
                p1, p2 = x1 / n1, x2 / n2
                p_pool = (x1 + x2) / (n1 + n2)
                se     = (p_pool * (1 - p_pool) * (1 / n1 + 1 / n2)) ** 0.5
                z      = (p2 - p1) / se if se > 0 else 0
                p_val  = round(norm.cdf(z), 6)
                rr     = round(p2 / p1, 4)
                c1 = min(1 - p_val, 1.0)
                c2 = min((1 - rr) / 0.5, 1.0) if rr < 1 else 0.0
                c3 = min(n2 / 200, 1.0)
                c4 = 0.1 if z < 0 and rr < 1 else 0.0
                confidence = round(min(c1*0.4 + c2*0.3 + c3*0.2 + c4, 1.0), 4)
                if p_val < p_thresh and rr <= rr_thresh and confidence >= conf_thresh:
                    return pd.Series({
                        "billed_cpt": cpt, "break_month": months[i],
                        "pay_rate_before": round(p1, 4), "pay_rate_after": round(p2, 4),
                        "z": round(z, 4), "n_before": int(n1), "n_after": int(n2),
                        "p_value": p_val, "relative_risk": rr, "confidence": confidence, "b03_flag": True,
                    })
        return pd.Series({"billed_cpt": None, "break_month": None,
                          "pay_rate_before": None, "pay_rate_after": None,
                          "z": None, "n_before": None, "n_after": None,
                          "p_value": None, "relative_risk": None, "confidence": None, "b03_flag": False})

    rows = []
    for payer, g in lines.groupby("payer_id"):
        row = scan(g); row["payer_id"] = payer; rows.append(row)
    payer_df = pd.DataFrame(rows).sort_values("break_month", ascending=True).reset_index(drop=True)

    feat = (payer_df[["payer_id", "break_month", "b03_flag", "confidence"]]
            .rename(columns={"break_month": "b03_break_month", "confidence": "b03confidence"}))
    df = df.drop(columns=[c for c in df.columns if c.startswith("b03_")], errors="ignore")
    df_out = df.merge(feat, on="payer_id", how="left")
    claim_month = df_out["service_date"].dt.to_period("M")
    break_month = df_out["b03_break_month"]
    df_out["b03_flag"] = (
        df_out["b03_flag"].fillna(False).astype(bool) &
        break_month.notna() &
        (claim_month >= break_month.where(break_month.notna(), claim_month))
    ).astype(int)
    return df_out, payer_df


def find_downcoding(df, claim_level=False, claim_id=[], min_n=5, p_thresh=0.01, rr_thresh=1.5, conf_thresh=0.50):
    """B04 - Paying for a Smaller Job Than You Did (downcoding)"""
    if claim_level:
        df = df[df["claim_id"].isin(claim_id)]

    lines = df[["claim_id", "line_number", "payer_id", "service_date",
                "billed_cpt", "paid_cpt", "line_paid"]].dropna(subset=["billed_cpt", "paid_cpt"]).copy()
    lines["downcode_flag"] = (
        (lines["billed_cpt"].astype(str) != lines["paid_cpt"].astype(str)) &
        (lines["line_paid"] > 0)
    ).astype(int)
    lines["month"] = lines["service_date"].dt.to_period("M")

    def scan(g):
        monthly = (
            g.groupby("month")
             .agg(n=("downcode_flag", "size"), downcodes=("downcode_flag", "sum"))
             .sort_index().reset_index()
        )
        for i in range(1, len(monthly)):
            before, after = monthly.iloc[:i], monthly.iloc[i:]
            n1, x1 = before["n"].sum(), before["downcodes"].sum()
            n2, x2 = after["n"].sum(),  after["downcodes"].sum()
            if n1 < min_n or n2 < min_n or x1 == 0:
                continue
            p1, p2 = x1 / n1, x2 / n2
            p_pool = (x1 + x2) / (n1 + n2)
            se     = (p_pool * (1 - p_pool) * (1 / n1 + 1 / n2)) ** 0.5
            z      = (p2 - p1) / se if se > 0 else 0
            p_val  = round(1 - norm.cdf(z), 6)
            rr     = round(p2 / p1, 4) if p1 > 0 else float("nan")
            c1 = min(1 - p_val, 1.0)
            c2 = min((rr - 1) / 4, 1.0) if rr > 1 else 0.0
            c3 = min(n2 / 200, 1.0)
            c4 = 0.1 if z > 0 else 0.0
            confidence = round(min(c1*0.4 + c2*0.3 + c3*0.2 + c4, 1.0), 4)
            if p_val < p_thresh and rr >= rr_thresh and confidence >= conf_thresh:
                return pd.Series({
                    "break_month": monthly.iloc[i]["month"], "rate_before": round(p1, 4),
                    "rate_after": round(p2, 4), "z": round(z, 4),
                    "n_before": int(n1), "n_after": int(n2),
                    "p_value": p_val, "relative_risk": rr, "confidence": confidence, "b04_flag": True,
                })
        return pd.Series({"break_month": None, "rate_before": None, "rate_after": None,
                          "z": None, "n_before": None, "n_after": None,
                          "p_value": None, "relative_risk": None, "confidence": None, "b04_flag": False})

    rows = []
    for payer, g in lines.groupby("payer_id"):
        row = scan(g); row["payer_id"] = payer; rows.append(row)
    payer_df = pd.DataFrame(rows).sort_values("break_month", ascending=True).reset_index(drop=True)

    line_feat = lines[["claim_id", "line_number", "downcode_flag"]].rename(columns={"downcode_flag": "b04_line_downcode"})
    df = df.drop(columns=[c for c in df.columns if c.startswith("b04_")], errors="ignore")
    df_out = df.merge(line_feat, on=["claim_id", "line_number"], how="left")
    df_out["b04_line_downcode"] = df_out["b04_line_downcode"].fillna(0).astype(int)
    feat = (payer_df[["payer_id", "break_month", "b04_flag", "confidence"]]
            .rename(columns={"break_month": "b04_break_month", "confidence": "b04confidence"}))
    df_out = df_out.merge(feat, on="payer_id", how="left")
    claim_month = df_out["service_date"].dt.to_period("M")
    break_month = df_out["b04_break_month"]
    df_out["b04_flag"] = (
        df_out["b04_flag"].fillna(False).astype(bool) &
        break_month.notna() &
        (claim_month >= break_month.where(break_month.notna(), claim_month))
    ).astype(int)
    return df_out, payer_df


def find_payment_shrinkage(df, claim_level=False, claim_id=[], min_months=6, min_n=10,
                           p_thresh=0.05, slope_thresh=-0.005, conf_thresh=0.50):
    """B05 - The Slice Keeps Getting Thinner (payment ratio trend)"""
    if claim_level:
        df = df[df["claim_id"].isin(claim_id)]

    lines = df[["claim_id", "line_number", "payer_id", "service_date",
                "billed_charge", "line_paid", "claim_denial_flag"]].copy()
    lines = lines[
        (lines["claim_denial_flag"] == 0) &
        (lines["billed_charge"] > 0) &
        (lines["line_paid"] > 0)
    ].copy()
    lines["payment_ratio"] = lines["line_paid"] / lines["billed_charge"]
    lines["month"] = lines["service_date"].dt.to_period("M")

    def scan(g):
        monthly = (
            g.groupby("month")
             .agg(n=("payment_ratio", "size"), ratio=("payment_ratio", "mean"))
             .reset_index().sort_values("month")
        )
        monthly = monthly[monthly["n"] >= min_n]
        if len(monthly) < min_months:
            return pd.Series({"n_months": None, "ratio_start": None, "ratio_end": None,
                              "slope_per_month": None, "total_drift": None,
                              "r_squared": None, "p_value": None, "confidence": None, "b05_flag": False})
        x = np.arange(len(monthly))
        slope, _, r, p_value, _ = linregress(x, monthly["ratio"].values)
        total_drift = round(monthly["ratio"].iloc[-1] - monthly["ratio"].iloc[0], 4)
        c1 = min(1 - p_value, 1.0)
        c2 = min(abs(total_drift) / 0.13, 1.0)
        c3 = min(len(monthly) / 12, 1.0)
        c4 = 0.1 if slope < 0 and total_drift < 0 else 0.0
        confidence = round(min(c1*0.4 + c2*0.3 + c3*0.2 + c4, 1.0), 4)
        return pd.Series({
            "n_months": len(monthly), "ratio_start": round(monthly["ratio"].iloc[0], 4),
            "ratio_end": round(monthly["ratio"].iloc[-1], 4), "slope_per_month": round(slope, 6),
            "total_drift": total_drift, "r_squared": round(r ** 2, 4),
            "p_value": round(p_value, 6), "confidence": confidence,
            "b05_flag": bool(p_value < p_thresh and slope <= slope_thresh and confidence >= conf_thresh),
        })

    rows = []
    for payer, g in lines.groupby("payer_id"):
        row = scan(g); row["payer_id"] = payer; rows.append(row)

    if not rows:
        df_out = df.drop(columns=[c for c in df.columns if c.startswith("b05_")], errors="ignore")
        df_out["b05_flag"] = False
        df_out["b05_slope_per_month"] = np.nan
        df_out["b05_total_drift"] = np.nan
        df_out["b05confidence"] = np.nan
        empty_pdf = pd.DataFrame(columns=["payer_id", "n_months", "ratio_start", "ratio_end",
                                           "slope_per_month", "total_drift", "r_squared",
                                           "p_value", "confidence", "b05_flag"])
        return df_out, empty_pdf

    payer_df = pd.DataFrame(rows).sort_values("slope_per_month").reset_index(drop=True)
    feat = (payer_df[["payer_id", "slope_per_month", "total_drift", "b05_flag", "confidence"]]
            .rename(columns={"slope_per_month": "b05_slope_per_month",
                             "total_drift": "b05_total_drift", "confidence": "b05confidence"}))
    df = df.drop(columns=[c for c in df.columns if c.startswith("b05_")], errors="ignore")
    df_out = df.merge(feat, on="payer_id", how="left")
    return df_out, payer_df


def find_qty_shave(df, claim_level=False, claim_id=[], min_n=20, p_thresh=0.01, rr_thresh=1.5, conf_thresh=0.50):
    """B06 - Paying for fewer than you gave (unit quantity shaving)"""
    if claim_level:
        df = df[df["claim_id"].isin(claim_id)]

    lines = df[["claim_id", "line_number", "payer_id", "service_date",
                "units", "line_qty_shave_flag", "line_unit_shortfall", "billed_charge"]].copy()
    lines = lines[lines["units"] > 0].copy()
    lines["b06_line_loss"] = (
        (lines["line_unit_shortfall"] / lines["units"]) * lines["billed_charge"]
    ).clip(lower=0)
    lines["month"] = lines["service_date"].dt.to_period("M")

    def scan(g):
        monthly = (
            g.groupby("month")
             .agg(n=("line_qty_shave_flag", "size"), shaves=("line_qty_shave_flag", "sum"))
             .sort_index().reset_index()
        )
        for i in range(1, len(monthly)):
            before, after = monthly.iloc[:i], monthly.iloc[i:]
            n1, x1 = before["n"].sum(), before["shaves"].sum()
            n2, x2 = after["n"].sum(),  after["shaves"].sum()
            if n1 < min_n or n2 < min_n or x1 == 0:
                continue
            p1, p2 = x1 / n1, x2 / n2
            p_pool = (x1 + x2) / (n1 + n2)
            se     = (p_pool * (1 - p_pool) * (1 / n1 + 1 / n2)) ** 0.5
            z      = (p2 - p1) / se if se > 0 else 0
            p_val  = round(1 - norm.cdf(z), 6)
            rr     = round(p2 / p1, 4) if p1 > 0 else float("nan")
            c1 = min(1 - p_val, 1.0)
            c2 = min((rr - 1) / 4, 1.0) if rr > 1 else 0.0
            c3 = min(n2 / 200, 1.0)
            c4 = 0.1 if z > 0 else 0.0
            confidence = round(min(c1*0.4 + c2*0.3 + c3*0.2 + c4, 1.0), 4)
            if p_val < p_thresh and rr >= rr_thresh and confidence >= conf_thresh:
                return pd.Series({
                    "break_month": monthly.iloc[i]["month"], "rate_before": round(p1, 4),
                    "rate_after": round(p2, 4), "z": round(z, 4),
                    "n_before": int(n1), "n_after": int(n2),
                    "p_value": p_val, "relative_risk": rr, "confidence": confidence, "b06_flag": True,
                })
        return pd.Series({"break_month": None, "rate_before": None, "rate_after": None,
                          "z": None, "n_before": None, "n_after": None,
                          "p_value": None, "relative_risk": None, "confidence": None, "b06_flag": False})

    rows = []
    for payer, g in lines.groupby("payer_id"):
        row = scan(g); row["payer_id"] = payer; rows.append(row)
    payer_df = pd.DataFrame(rows).sort_values("break_month", ascending=True).reset_index(drop=True)

    loss_by_payer = lines.groupby("payer_id")["b06_line_loss"].sum().rename("b06_total_loss").reset_index()
    payer_df = payer_df.merge(loss_by_payer, on="payer_id", how="left")

    line_feat = lines[["claim_id", "line_number", "b06_line_loss"]]
    df = df.drop(columns=[c for c in df.columns if c.startswith("b06_")], errors="ignore")
    df_out = df.merge(line_feat, on=["claim_id", "line_number"], how="left")
    df_out["b06_line_loss"] = df_out["b06_line_loss"].fillna(0)
    feat = (payer_df[["payer_id", "break_month", "b06_flag", "b06_total_loss", "confidence"]]
            .rename(columns={"break_month": "b06_break_month", "confidence": "b06confidence"}))
    df_out = df_out.merge(feat, on="payer_id", how="left")
    claim_month = df_out["service_date"].dt.to_period("M")
    break_month = df_out["b06_break_month"]
    df_out["b06_flag"] = (
        df_out["b06_flag"].fillna(False).astype(bool) &
        break_month.notna() &
        (claim_month >= break_month.where(break_month.notna(), claim_month))
    ).astype(int)
    return df_out, payer_df


def find_auth_contradiction(df, claim_level=False, claim_id=[], min_n=20, p_thresh=0.05, rr_thresh=1.1, conf_thresh=0.80):
    """B07 - Approved it then denied it for not being approved (auth contradiction)"""
    if claim_level:
        df = df[df["claim_id"].isin(claim_id)]

    claims = df.drop_duplicates("claim_id")[[
        "claim_id", "payer_id", "service_date", "post_approved_then_denied", "billed_charge"
    ]].copy()
    claims["month"] = claims["service_date"].dt.to_period("M")
    claims["b07_claim_contradiction"] = claims["post_approved_then_denied"].fillna(0).astype(int)

    def scan(g):
        monthly = (
            g.groupby("month")
             .agg(n=("claim_id", "size"), contradictions=("b07_claim_contradiction", "sum"))
             .sort_index().reset_index()
        )
        for i in range(1, len(monthly)):
            before, after = monthly.iloc[:i], monthly.iloc[i:]
            n1, x1 = before["n"].sum(), before["contradictions"].sum()
            n2, x2 = after["n"].sum(),  after["contradictions"].sum()
            if n1 < min_n or n2 < min_n or x1 == 0:
                continue
            p1, p2 = x1 / n1, x2 / n2
            p_pool = (x1 + x2) / (n1 + n2)
            se     = (p_pool * (1 - p_pool) * (1 / n1 + 1 / n2)) ** 0.5
            z      = (p2 - p1) / se if se > 0 else 0
            p_val  = round(1 - norm.cdf(z), 6)
            rr     = round(p2 / p1, 4) if p1 > 0 else float("nan")
            c1 = min(1 - p_val, 1.0); c2 = min((rr - 1) / 4, 1.0) if rr > 1 else 0.0
            c3 = min(n2 / 200, 1.0); c4 = 0.1 if z > 0 else 0.0
            confidence = round(min(c1*0.4 + c2*0.3 + c3*0.2 + c4, 1.0), 4)
            if p_val < p_thresh and rr >= rr_thresh and confidence >= conf_thresh:
                return pd.Series({
                    "break_month": monthly.iloc[i]["month"], "rate_before": round(p1, 4),
                    "rate_after": round(p2, 4), "z": round(z, 4),
                    "n_before": int(n1), "n_after": int(n2),
                    "p_value": p_val, "relative_risk": rr, "confidence": confidence, "b07_flag": True,
                })
        return pd.Series({"break_month": None, "rate_before": None, "rate_after": None,
                          "z": None, "n_before": None, "n_after": None,
                          "p_value": None, "relative_risk": None, "confidence": None, "b07_flag": False})

    rows = []
    for payer, g in claims.groupby("payer_id"):
        row = scan(g); row["payer_id"] = payer; rows.append(row)
    payer_df = pd.DataFrame(rows).sort_values("break_month", ascending=True).reset_index(drop=True)

    contradiction_count = claims.groupby("payer_id")["b07_claim_contradiction"].sum().rename("b07_contradiction_count").reset_index()
    exposure_by_payer = (claims[claims["b07_claim_contradiction"] == 1]
                         .groupby("payer_id")["billed_charge"].sum().rename("b07_total_exposure").reset_index())
    payer_df = (payer_df.merge(contradiction_count, on="payer_id", how="left")
                        .merge(exposure_by_payer, on="payer_id", how="left"))
    payer_df["b07_total_exposure"] = payer_df["b07_total_exposure"].fillna(0)

    claim_feat = claims[["claim_id", "b07_claim_contradiction"]]
    df = df.drop(columns=[c for c in df.columns if c.startswith("b07_")], errors="ignore")
    df_out = df.merge(claim_feat, on="claim_id", how="left")
    df_out["b07_claim_contradiction"] = df_out["b07_claim_contradiction"].fillna(0).astype(int)
    feat = (payer_df[["payer_id", "break_month", "b07_flag", "b07_contradiction_count", "b07_total_exposure", "confidence"]]
            .rename(columns={"break_month": "b07_break_month", "confidence": "b07confidence"}))
    df_out = df_out.merge(feat, on="payer_id", how="left")
    claim_month = df_out["service_date"].dt.to_period("M")
    break_month = df_out["b07_break_month"]
    df_out["b07_flag"] = (
        df_out["b07_flag"].fillna(False).astype(bool) &
        break_month.notna() &
        (claim_month >= break_month.where(break_month.notna(), claim_month))
    ).astype(int)
    return df_out, payer_df


def find_surprise_pa(df, claim_level=False, claim_id=[], min_n=20, p_thresh=0.01, rr_thresh=1.5, conf_thresh=0.50):
    """B08 - Newly demanding pre-approval (surprise prior-auth)"""
    if claim_level:
        df = df[df["claim_id"].isin(claim_id)]

    claims = df.drop_duplicates("claim_id")[[
        "claim_id", "payer_id", "service_date", "surprise_pa", "billed_charge"
    ]].copy()
    claims["month"] = claims["service_date"].dt.to_period("M")
    claims["b08_claim_surprise_pa"] = claims["surprise_pa"].fillna(0).astype(int)

    def scan(g):
        monthly = (
            g.groupby("month")
             .agg(n=("claim_id", "size"), surprise=("b08_claim_surprise_pa", "sum"))
             .sort_index().reset_index()
        )
        for i in range(1, len(monthly)):
            before, after = monthly.iloc[:i], monthly.iloc[i:]
            n1, x1 = before["n"].sum(), before["surprise"].sum()
            n2, x2 = after["n"].sum(),  after["surprise"].sum()
            if n1 < min_n or n2 < min_n or x1 == 0:
                continue
            p1, p2 = x1 / n1, x2 / n2
            p_pool = (x1 + x2) / (n1 + n2)
            se     = (p_pool * (1 - p_pool) * (1 / n1 + 1 / n2)) ** 0.5
            z      = (p2 - p1) / se if se > 0 else 0
            p_val  = round(1 - norm.cdf(z), 6)
            rr     = round(p2 / p1, 4) if p1 > 0 else float("nan")
            c1 = min(1 - p_val, 1.0); c2 = min((rr - 1) / 4, 1.0) if rr > 1 else 0.0
            c3 = min(n2 / 200, 1.0); c4 = 0.1 if z > 0 else 0.0
            confidence = round(min(c1*0.4 + c2*0.3 + c3*0.2 + c4, 1.0), 4)
            if p_val < p_thresh and rr >= rr_thresh and confidence >= conf_thresh:
                return pd.Series({
                    "break_month": monthly.iloc[i]["month"], "rate_before": round(p1, 4),
                    "rate_after": round(p2, 4), "z": round(z, 4),
                    "n_before": int(n1), "n_after": int(n2),
                    "p_value": p_val, "relative_risk": rr, "confidence": confidence, "b08_flag": True,
                })
        return pd.Series({"break_month": None, "rate_before": None, "rate_after": None,
                          "z": None, "n_before": None, "n_after": None,
                          "p_value": None, "relative_risk": None, "confidence": None, "b08_flag": False})

    rows = []
    for payer, g in claims.groupby("payer_id"):
        row = scan(g); row["payer_id"] = payer; rows.append(row)
    payer_df = pd.DataFrame(rows).sort_values("break_month", ascending=True).reset_index(drop=True)

    surprise_count = claims.groupby("payer_id")["b08_claim_surprise_pa"].sum().rename("b08_surprise_pa_count").reset_index()
    exposure_by_payer = (claims[claims["b08_claim_surprise_pa"] == 1]
                         .groupby("payer_id")["billed_charge"].sum().rename("b08_total_exposure").reset_index())
    payer_df = (payer_df.merge(surprise_count, on="payer_id", how="left")
                        .merge(exposure_by_payer, on="payer_id", how="left"))
    payer_df["b08_total_exposure"] = payer_df["b08_total_exposure"].fillna(0)

    claim_feat = claims[["claim_id", "b08_claim_surprise_pa"]]
    df = df.drop(columns=[c for c in df.columns if c.startswith("b08_")], errors="ignore")
    df_out = df.merge(claim_feat, on="claim_id", how="left")
    df_out["b08_claim_surprise_pa"] = df_out["b08_claim_surprise_pa"].fillna(0).astype(int)
    feat = (payer_df[["payer_id", "break_month", "b08_flag", "b08_surprise_pa_count", "b08_total_exposure", "confidence"]]
            .rename(columns={"break_month": "b08_break_month", "confidence": "b08confidence"}))
    df_out = df_out.merge(feat, on="payer_id", how="left")
    claim_month = df_out["service_date"].dt.to_period("M")
    break_month = df_out["b08_break_month"]
    df_out["b08_flag"] = (
        df_out["b08_flag"].fillna(False).astype(bool) &
        break_month.notna() &
        (claim_month >= break_month.where(break_month.notna(), claim_month))
    ).astype(int)
    return df_out, payer_df


def find_timely_filing_abuse(df, claim_level=False, claim_id=[], min_n=15, p_thresh=0.05,
                             rr_thresh=2.0, wrongful_rate_thresh=0.5, filing_window=90, conf_thresh=0.80):
    """B09 - You filed too late (but you didn't)."""
    if claim_level:
        df = df[df["claim_id"].isin(claim_id)]

    claims = df.drop_duplicates("claim_id")[[
        "claim_id", "payer_id", "service_date", "submission_lag_days", "billed_charge"
    ]].copy()
    timely_flag = df.groupby("claim_id")["carc"].apply(lambda s: s.astype(str).isin(["29"]).any())
    claims["timely_denied"] = claims["claim_id"].map(timely_flag).fillna(False)
    claims["filed_on_time"] = claims["timely_denied"] & (claims["submission_lag_days"] < filing_window)
    claims["month"] = claims["service_date"].dt.to_period("M")

    def scan(g):
        monthly = (
            g.groupby("month")
             .agg(n_claims=("claim_id", "size"), n_timely=("timely_denied", "sum"))
             .reset_index().sort_values("month")
        )
        n_timely   = int(g["timely_denied"].sum())
        n_wrongful = int(g["filed_on_time"].sum())
        wrongful_rate = n_wrongful / n_timely if n_timely > 0 else 0.0
        for i in range(1, len(monthly)):
            before, after = monthly.iloc[:i], monthly.iloc[i:]
            n1, x1 = before["n_claims"].sum(), before["n_timely"].sum()
            n2, x2 = after["n_claims"].sum(),  after["n_timely"].sum()
            if n1 < min_n or n2 < min_n or x1 == 0:
                continue
            p1, p2 = x1 / n1, x2 / n2
            p_pool = (x1 + x2) / (n1 + n2)
            se     = (p_pool * (1 - p_pool) * (1 / n1 + 1 / n2)) ** 0.5
            z      = (p2 - p1) / se if se > 0 else 0
            p_val  = round(1 - norm.cdf(z), 6)
            rr     = round(p2 / p1, 4) if p1 > 0 else float("nan")
            c1 = min(1 - p_val, 1.0); c2 = min((rr - 1) / 4, 1.0) if rr > 1 else 0.0
            c3 = min(n2 / 200, 1.0); c4 = 0.1 if z > 0 else 0.0
            confidence = round(min(c1*0.4 + c2*0.3 + c3*0.2 + c4, 1.0), 4)
            if p_val < p_thresh and rr >= rr_thresh and wrongful_rate >= wrongful_rate_thresh and confidence >= conf_thresh:
                return pd.Series({
                    "break_month": monthly.iloc[i]["month"], "rate_before": round(p1, 4),
                    "rate_after": round(p2, 4), "z": round(z, 4),
                    "n_before": int(n1), "n_after": int(n2),
                    "p_value": p_val, "relative_risk": rr, "confidence": confidence,
                    "n_timely_denied": n_timely, "n_wrongful": n_wrongful,
                    "wrongful_rate": round(wrongful_rate, 4),
                    "mean_submission_lag": g.loc[g["timely_denied"], "submission_lag_days"].mean() if n_timely > 0 else float("nan"),
                    "dollars_at_stake": g.loc[g["filed_on_time"], "billed_charge"].sum(),
                    "b09_flag": True,
                })
        return pd.Series({"break_month": None, "rate_before": None, "rate_after": None,
                          "z": None, "n_before": None, "n_after": None, "p_value": None,
                          "relative_risk": None, "confidence": None, "n_timely_denied": None,
                          "n_wrongful": None, "wrongful_rate": None,
                          "mean_submission_lag": None, "dollars_at_stake": None, "b09_flag": False})

    rows = []
    for payer, g in claims.groupby("payer_id"):
        row = scan(g); row["payer_id"] = payer; rows.append(row)
    payer_df = pd.DataFrame(rows).sort_values("break_month", ascending=True).reset_index(drop=True)

    feat = (payer_df[["payer_id", "break_month", "b09_flag", "confidence"]]
            .rename(columns={"break_month": "b09_break_month", "confidence": "b09confidence"}))
    df = df.drop(columns=[c for c in df.columns if c.startswith("b09_")], errors="ignore")
    df_out = df.merge(feat, on="payer_id", how="left")
    claim_month = df_out["service_date"].dt.to_period("M")
    break_month = df_out["b09_break_month"]
    df_out["b09_flag"] = (
        df_out["b09_flag"].fillna(False).astype(bool) &
        break_month.notna() &
        (claim_month >= break_month.where(break_month.notna(), claim_month))
    ).astype(int)
    return df_out, payer_df


def find_slow_pay(df, claim_level=False, claim_id=[], min_n=20, p_thresh=0.01, ratio_thresh=1.3, conf_thresh=0.80):
    """B10 - The Slow Walk (step-change in payment turnaround time)."""
    if claim_level:
        df = df[df["claim_id"].isin(claim_id)]

    claims = df.drop_duplicates("claim_id")[[
        "claim_id", "payer_id", "submission_date", "time_to_payment_days"
    ]].copy()
    claims = claims.dropna(subset=["time_to_payment_days"])
    claims["submission_date"] = pd.to_datetime(claims["submission_date"], errors="coerce")
    claims["month"] = claims["submission_date"].dt.to_period("M")

    def scan(g):
        months = sorted(g["month"].unique())
        for i in range(1, len(months)):
            before = g.loc[g["month"] < months[i], "time_to_payment_days"]
            after  = g.loc[g["month"] >= months[i], "time_to_payment_days"]
            n1, n2 = len(before), len(after)
            if n1 < min_n or n2 < min_n:
                continue
            m1, m2 = before.mean(), after.mean()
            v1, v2 = before.var(ddof=1), after.var(ddof=1)
            se     = np.sqrt(v1 / n1 + v2 / n2)
            z      = (m2 - m1) / se if se > 0 else 0
            p_val  = round(1 - norm.cdf(z), 6)
            day_ratio = round(m2 / m1, 4) if m1 > 0 else float("nan")
            c1 = min(1 - p_val, 1.0); c2 = min((day_ratio - 1) / 1.0, 1.0) if day_ratio > 1 else 0.0
            c3 = min(n2 / 200, 1.0); c4 = 0.1 if z > 0 else 0.0
            confidence = round(min(c1*0.4 + c2*0.3 + c3*0.2 + c4, 1.0), 4)
            if p_val < p_thresh and day_ratio >= ratio_thresh and confidence >= conf_thresh:
                return pd.Series({
                    "break_month": months[i], "days_before": round(m1, 2),
                    "days_after": round(m2, 2), "z": round(z, 4),
                    "n_before": int(n1), "n_after": int(n2),
                    "p_value": p_val, "day_ratio": day_ratio, "confidence": confidence, "b10_flag": True,
                })
        return pd.Series({"break_month": None, "days_before": None, "days_after": None,
                          "z": None, "n_before": None, "n_after": None,
                          "p_value": None, "day_ratio": None, "confidence": None, "b10_flag": False})

    rows = []
    for payer, g in claims.groupby("payer_id"):
        row = scan(g); row["payer_id"] = payer; rows.append(row)
    payer_df = pd.DataFrame(rows).sort_values("break_month", ascending=True).reset_index(drop=True)

    feat = (payer_df[["payer_id", "break_month", "b10_flag", "confidence"]]
            .rename(columns={"break_month": "b10_break_month", "confidence": "b10confidence"}))
    df = df.drop(columns=[c for c in df.columns if c.startswith("b10_")], errors="ignore")
    df_out = df.merge(feat, on="payer_id", how="left")
    claim_month = df_out["service_date"].dt.to_period("M")
    break_month = df_out["b10_break_month"]
    df_out["b10_flag"] = (
        df_out["b10_flag"].fillna(False).astype(bool) &
        break_month.notna() &
        (claim_month >= break_month.where(break_month.notna(), claim_month))
    ).astype(int)
    return df_out, payer_df


def find_vanishing_claims(df, claim_level=False, claim_id=[], stale_days=45, min_n=20,
                          p_thresh=0.05, rr_thresh=1.1, conf_thresh=0.80):
    """B11 - Claims going into the black hole (sudden pending rate jump)"""
    if claim_level:
        df = df[df["claim_id"].isin(claim_id)]

    _status_date = "claim_status_effective_date" if "claim_status_effective_date" in df.columns else "claim_adjudication_date"
    claims = df.drop_duplicates("claim_id")[[
        "claim_id", "payer_id", "service_date", _status_date, "claim_pend_flag"
    ]].copy().rename(columns={_status_date: "claim_status_effective_date"})

    as_of_date = df["claim_adjudication_date"].dropna().max()
    claims["days_pending"] = (as_of_date - pd.to_datetime(claims["claim_status_effective_date"], errors="coerce")).dt.days
    claims = claims[claims["days_pending"] > stale_days]
    claims["month"] = claims["service_date"].dt.to_period("M")

    def scan(g):
        monthly = (
            g.groupby("month")
             .agg(n_claims=("claim_id", "size"), n_pended=("claim_pend_flag", "sum"))
             .reset_index().sort_values("month")
        )
        for i in range(1, len(monthly)):
            before = monthly.iloc[:i]; after = monthly.iloc[i:]
            n1, x1 = before["n_claims"].sum(), before["n_pended"].sum()
            n2, x2 = after["n_claims"].sum(),  after["n_pended"].sum()
            if n1 < min_n or n2 < min_n:
                continue
            p1, p2 = x1 / n1, x2 / n2
            p_pool = (x1 + x2) / (n1 + n2)
            se     = (p_pool * (1 - p_pool) * (1 / n1 + 1 / n2)) ** 0.5
            z      = (p2 - p1) / se if se > 0 else 0
            p_val  = round(1 - norm.cdf(z), 6)
            rr     = round(p2 / p1, 4) if p1 > 0 else float("nan")
            c1 = min(1 - p_val, 1.0); c2 = min((rr - 1) / 4, 1.0) if rr > 1 else 0.0
            c3 = min(n2 / 200, 1.0); c4 = 0.1 if z > 0 else 0.0
            confidence = round(min(c1*0.4 + c2*0.3 + c3*0.2 + c4, 1.0), 4)
            if p_val < p_thresh and rr >= rr_thresh and confidence >= conf_thresh:
                return pd.Series({
                    "break_month": monthly.iloc[i]["month"], "rate_before": round(p1, 4),
                    "rate_after": round(p2, 4), "z": round(z, 4),
                    "n_before": int(n1), "n_after": int(n2),
                    "p_value": p_val, "relative_risk": rr, "confidence": confidence, "b11_flag": True,
                })
        return pd.Series({"break_month": None, "rate_before": None, "rate_after": None,
                          "z": None, "n_before": None, "n_after": None,
                          "p_value": None, "relative_risk": None, "confidence": None, "b11_flag": False})

    rows = []
    for payer, g in claims.groupby("payer_id"):
        row = scan(g); row["payer_id"] = payer; rows.append(row)
    payer_df = pd.DataFrame(rows).sort_values("break_month", ascending=True).reset_index(drop=True)

    feat = (payer_df[["payer_id", "break_month", "b11_flag", "confidence"]]
            .rename(columns={"break_month": "b11_break_month", "confidence": "b11confidence"}))
    df = df.drop(columns=[c for c in df.columns if c.startswith("b11_")], errors="ignore")
    df_out = df.merge(feat, on="payer_id", how="left")
    claim_month = df_out["service_date"].dt.to_period("M")
    break_month = df_out["b11_break_month"]
    df_out["b11_flag"] = (
        df_out["b11_flag"].fillna(False).astype(bool) &
        break_month.notna() &
        (claim_month >= break_month.where(break_month.notna(), claim_month))
    ).astype(int)
    return df_out, payer_df


def find_provider_targeting(df, claim_level=False, claim_id=[], n_sims=5000, min_n=20,
                            p_thresh=0.01, ratio_thresh=1.5, conf_thresh=0.80, seed=42):
    """B12 - Provider Targeting (HHI permutation test)"""
    if claim_level:
        df = df[df["claim_id"].isin(claim_id)]

    claims = df.drop_duplicates("claim_id")[[
        "claim_id", "payer_id", "provider_id", "claim_denial_flag"
    ]].copy()
    rng = np.random.default_rng(seed)

    def hhi(counts, total):
        return ((counts / total) ** 2).sum() if total > 0 else 0.0

    rows = []
    for payer, g in claims.groupby("payer_id"):
        n, d = len(g), int(g["claim_denial_flag"].sum())
        if n < min_n or d < min_n:
            rows.append({"payer_id": payer, "n_before": n, "n_after": d,
                         "top_provider": None, "rate_before": None, "rate_after": None,
                         "relative_risk": None, "concentration_ratio": None,
                         "p_value": None, "confidence": None, "b12_flag": False})
            continue
        codes, providers = pd.factorize(g["provider_id"].to_numpy())
        denied_mask = g["claim_denial_flag"].to_numpy().astype(bool)
        hhi_obs = hhi(np.bincount(codes[denied_mask], minlength=len(providers)), d)
        idx = np.arange(n)
        null_hhis = np.empty(n_sims)
        for s in range(n_sims):
            sim_idx = rng.choice(idx, size=d, replace=False)
            null_hhis[s] = hhi(np.bincount(codes[sim_idx], minlength=len(providers)), d)
        p_val         = round((np.sum(null_hhis >= hhi_obs) + 1) / (n_sims + 1), 6)
        hhi_null_mean = null_hhis.mean()
        conc_ratio    = round(hhi_obs / hhi_null_mean if hhi_null_mean > 0 else float("inf"), 4)
        claim_share  = g["provider_id"].value_counts(normalize=True)
        denial_share = g.loc[denied_mask, "provider_id"].value_counts(normalize=True)
        lift = (denial_share / claim_share.reindex(denial_share.index)).sort_values(ascending=False)
        top_prov    = lift.index[0]
        rate_before = round(float(claim_share[top_prov]), 4)
        rate_after  = round(float(denial_share[top_prov]), 4)
        rr          = round(float(lift.iloc[0]), 4)
        c1 = min(1 - p_val, 1.0); c2 = min((conc_ratio - 1) / 4, 1.0) if conc_ratio > 1 else 0.0
        c3 = min(d / 200, 1.0); c4 = 0.1 if conc_ratio > 1 else 0.0
        confidence = round(min(c1*0.4 + c2*0.3 + c3*0.2 + c4, 1.0), 4)
        rows.append({
            "payer_id": payer, "n_before": n, "n_after": d,
            "top_provider": top_prov, "rate_before": rate_before, "rate_after": rate_after,
            "relative_risk": rr, "concentration_ratio": conc_ratio,
            "p_value": p_val, "confidence": confidence,
            "b12_flag": bool(p_val < p_thresh and rr >= ratio_thresh and confidence >= conf_thresh),
        })

    payer_df = (pd.DataFrame(rows).sort_values("concentration_ratio", ascending=False).reset_index(drop=True))
    feat = (payer_df[["payer_id", "top_provider", "b12_flag", "confidence"]]
            .rename(columns={"top_provider": "b12_targeted_provider", "confidence": "b12confidence"}))
    df_out = df.drop(columns=[c for c in df.columns if c.startswith("b12_")], errors="ignore")
    df_out = df_out.merge(feat, on="payer_id", how="left")
    return df_out, payer_df


# =============================================================================
# WRAPPER — add_payer_behaviour_features
# =============================================================================

def add_payer_behaviour_features(train_df, test_df):
    """
    Step 13 — Payer Behaviour Features (B01-B12).
    Computed on TRAINING split only; applied to test via payer_id LEFT JOIN.
    """
    PAYER_ID = config.PAYER_ID_COL

    rename_in = {
        config.CLAIM_CONTROL_NUMBER_COL: "claim_id",
        "denial_flag_beh":               "claim_denial_flag",
        config.CARC_COL:                 "carc",
        config.PROCEDURE_CODE_COL:       "billed_cpt",
        config.TOTAL_CLAIM_CHARGE_COL:   "billed_charge",
        "line_paid_amount":              "line_paid",
        config.FINAL_STATUS_DATE_COL:    "claim_adjudication_date",
        config.PAYMENT_DATE_COL:         "payment_date",
        config.SUBMISSION_DATE_COL:      "submission_date",
        "pend_flag_beh":                 "claim_pend_flag",
        config.BILLING_PROVIDER_COL:     "provider_id",
    }
    rename_in = {k: v for k, v in rename_in.items() if k in train_df.columns}
    work = train_df.rename(columns=rename_in)

    if "time_to_payment_days" not in work.columns:
        if "payment_date" in work.columns and "submission_date" in work.columns:
            work["time_to_payment_days"] = (
                pd.to_datetime(work["payment_date"],   errors="coerce")
                - pd.to_datetime(work["submission_date"], errors="coerce")
            ).dt.days

    if "billed_cpt" in work.columns and "paid_cpt" not in work.columns:
        work["paid_cpt"] = work["billed_cpt"]

    print("\nStep 13: Payer behavior features (train — computing B01-B12)")

    work, p01 = find_break(work)
    work, p02 = find_excuse_shift(work)
    work, p03 = find_coverage_shrinkage(work)
    work, p04 = find_downcoding(work)
    work, p05 = find_payment_shrinkage(work)
    work, p06 = find_qty_shave(work)
    work, p07 = find_auth_contradiction(work)
    work, p08 = find_surprise_pa(work)
    work, p09 = find_timely_filing_abuse(work)
    work, p10 = find_slow_pay(work)
    work, p11 = find_vanishing_claims(work)
    work, p12 = find_provider_targeting(work)

    work = work[~work.index.duplicated(keep="first")]

    new_cols = [
        "b01_flag", "b01_break_month", "b01confidence",
        "b02_flag", "b02_break_month", "b02_top_reason", "b02confidence",
        "b03_flag", "b03_break_month", "b03confidence",
        "b04_flag", "b04_break_month", "b04confidence",
        "b05_flag", "b05_slope_per_month", "b05_total_drift", "b05confidence",
        "b06_flag", "b06_break_month", "b06confidence", "b06_total_loss",
        "b07_flag", "b07_break_month", "b07confidence",
        "b07_contradiction_count", "b07_total_exposure",
        "b08_flag", "b08_break_month", "b08confidence",
        "b08_surprise_pa_count", "b08_total_exposure",
        "b09_flag", "b09_break_month", "b09confidence",
        "b10_flag", "b10_break_month", "b10confidence",
        "b11_flag", "b11_break_month", "b11confidence",
        "b12_flag", "b12_targeted_provider", "b12confidence",
    ]
    for col in new_cols:
        if col in work.columns:
            train_df[col] = work[col].reindex(train_df.index).values

    beh_count = sum(1 for c in new_cols if c in train_df.columns)
    print(f"  {beh_count} payer behavior columns added to train.")
    logger.info("B01-B12 computed on train — %d feature columns added.", beh_count)

    print("\nStep 13: Payer behavior features (test — applying train payer tables)")

    def _plookup(pdf, renames):
        src_cols = [k for k in renames if k in pdf.columns]
        if not src_cols:
            return pd.DataFrame(columns=[PAYER_ID])
        lkp = pdf[[PAYER_ID] + src_cols].drop_duplicates(PAYER_ID)
        return lkp.rename(columns=renames)

    payer_lookups = [
        (_plookup(p01, {"break_month": "b01_break_month", "b01_flag": "b01_flag", "confidence": "b01confidence"}),
         ["b01_flag", "b01_break_month", "b01confidence"]),
        (_plookup(p02, {"break_month": "b02_break_month", "b02_flag": "b02_flag", "top_reason": "b02_top_reason", "confidence": "b02confidence"}),
         ["b02_flag", "b02_break_month", "b02_top_reason", "b02confidence"]),
        (_plookup(p03, {"break_month": "b03_break_month", "b03_flag": "b03_flag", "confidence": "b03confidence"}),
         ["b03_flag", "b03_break_month", "b03confidence"]),
        (_plookup(p04, {"break_month": "b04_break_month", "b04_flag": "b04_flag", "confidence": "b04confidence"}),
         ["b04_flag", "b04_break_month", "b04confidence"]),
        (_plookup(p05, {"slope_per_month": "b05_slope_per_month", "total_drift": "b05_total_drift", "b05_flag": "b05_flag", "confidence": "b05confidence"}),
         ["b05_flag", "b05_slope_per_month", "b05_total_drift", "b05confidence"]),
        (_plookup(p06, {"break_month": "b06_break_month", "b06_flag": "b06_flag", "b06_total_loss": "b06_total_loss", "confidence": "b06confidence"}),
         ["b06_flag", "b06_break_month", "b06confidence", "b06_total_loss"]),
        (_plookup(p07, {"break_month": "b07_break_month", "b07_flag": "b07_flag", "b07_contradiction_count": "b07_contradiction_count", "b07_total_exposure": "b07_total_exposure", "confidence": "b07confidence"}),
         ["b07_flag", "b07_break_month", "b07confidence", "b07_contradiction_count", "b07_total_exposure"]),
        (_plookup(p08, {"break_month": "b08_break_month", "b08_flag": "b08_flag", "b08_surprise_pa_count": "b08_surprise_pa_count", "b08_total_exposure": "b08_total_exposure", "confidence": "b08confidence"}),
         ["b08_flag", "b08_break_month", "b08confidence", "b08_surprise_pa_count", "b08_total_exposure"]),
        (_plookup(p09, {"break_month": "b09_break_month", "b09_flag": "b09_flag", "confidence": "b09confidence"}),
         ["b09_flag", "b09_break_month", "b09confidence"]),
        (_plookup(p10, {"break_month": "b10_break_month", "b10_flag": "b10_flag", "confidence": "b10confidence"}),
         ["b10_flag", "b10_break_month", "b10confidence"]),
        (_plookup(p11, {"break_month": "b11_break_month", "b11_flag": "b11_flag", "confidence": "b11confidence"}),
         ["b11_flag", "b11_break_month", "b11confidence"]),
        (_plookup(p12, {"top_provider": "b12_targeted_provider", "b12_flag": "b12_flag", "confidence": "b12confidence"}),
         ["b12_flag", "b12_targeted_provider", "b12confidence"]),
    ]

    for payer_df_lookup, cols in payer_lookups:
        if payer_df_lookup is None or payer_df_lookup.empty:
            continue
        available = [c for c in cols if c in payer_df_lookup.columns]
        if not available:
            continue
        lookup  = payer_df_lookup[[PAYER_ID] + available].drop_duplicates(PAYER_ID)
        test_df = test_df.merge(lookup, on=PAYER_ID, how="left")
        for c in available:
            if c.endswith("_flag"):
                test_df[c] = test_df[c].fillna(False)
            else:
                fill = lookup[c].median()
                test_df[c] = test_df[c].fillna(fill if pd.notna(fill) else 0.0)

    svc_col = "service_date"
    if svc_col in test_df.columns:
        claim_m = pd.to_datetime(test_df[svc_col], errors="coerce").dt.to_period("M")
        for bk, _fl in [
            ("b01_break_month", "b01_flag"), ("b02_break_month", "b02_flag"),
            ("b03_break_month", "b03_flag"), ("b04_break_month", "b04_flag"),
            ("b06_break_month", "b06_flag"), ("b07_break_month", "b07_flag"),
            ("b08_break_month", "b08_flag"), ("b09_break_month", "b09_flag"),
            ("b10_break_month", "b10_flag"), ("b11_break_month", "b11_flag"),
        ]:
            if bk not in test_df.columns or _fl not in test_df.columns:
                continue
            bm = test_df[bk].apply(lambda v: v if isinstance(v, pd.Period) else pd.NaT)
            has_break = bm.notna()
            after_break = pd.Series(False, index=test_df.index, dtype=bool)
            if has_break.any():
                after_break[has_break] = (claim_m[has_break] >= bm[has_break])
            test_df[_fl] = (has_break & after_break).astype(int)

    beh_test = sum(1 for c in new_cols if c in test_df.columns)
    print(f"  {beh_test} payer behavior columns applied to test.")
    logger.info("B01-B12 applied to test — %d feature columns present.", beh_test)

    B_SIGNAL_DEFAULTS = {
        "b01_flag": 0, "b01_break_month": None, "b01confidence": 0.0,
        "b02_flag": 0, "b02_break_month": None, "b02_top_reason": None, "b02confidence": 0.0,
        "b03_flag": 0, "b03_break_month": None, "b03confidence": 0.0,
        "b04_flag": 0, "b04_break_month": None, "b04confidence": 0.0,
        "b05_flag": 0, "b05_slope_per_month": 0.0, "b05_total_drift": 0.0, "b05confidence": 0.0,
        "b06_flag": 0, "b06_break_month": None, "b06confidence": 0.0, "b06_total_loss": 0.0,
        "b07_flag": 0, "b07_break_month": None, "b07confidence": 0.0,
        "b07_contradiction_count": 0, "b07_total_exposure": 0.0,
        "b08_flag": 0, "b08_break_month": None, "b08confidence": 0.0,
        "b08_surprise_pa_count": 0, "b08_total_exposure": 0.0,
        "b09_flag": 0, "b09_break_month": None, "b09confidence": 0.0,
        "b10_flag": 0, "b10_break_month": None, "b10confidence": 0.0,
        "b11_flag": 0, "b11_break_month": None, "b11confidence": 0.0,
        "b12_flag": 0, "b12_targeted_provider": None, "b12confidence": 0.0,
    }
    for col, default in B_SIGNAL_DEFAULTS.items():
        if col not in train_df.columns:
            train_df[col] = default
        if col not in test_df.columns:
            test_df[col] = default

    try:
        import config.paths_config as _pc
        behbundle = {"payer_behaviour_lookups": payer_lookups, "payer_id_col": PAYER_ID}
        os.makedirs(str(_pc.PKL_DIR), exist_ok=True)
        joblib.dump(behbundle, str(_pc.PAYER_LOOKUP_BUNDLE_PKL))
        logger.info("Payer behaviour lookup bundle saved → %s", _pc.PAYER_LOOKUP_BUNDLE_PKL)
    except Exception as _e:
        logger.warning("Could not save payer behaviour lookup bundle: %s", _e)

    print("  [DONE] add_payer_behaviour_features — B01-B12 complete.")
    logger.info("add_payer_behaviour_features complete — train %s | test %s.",
                train_df.shape, test_df.shape)
    return train_df, test_df


# =============================================================================
# EARLY SIGNAL FUNCTIONS (E01-E03)
# =============================================================================


def find_edv(df, claim_level=False, claim_id=[], p_thresh=0.05, conf_thresh=0.80, denial_ceiling=0.70):
    """E01 - Embedding Drift Velocity (EDV)."""
    if claim_level:
        df = df[df["claim_id"].isin(claim_id)]

    lines = df.copy()
    BUNDLING_CARCS = {"97", "234"}
    lines["line_denied"] = (
        (lines["line_paid"] == 0) &
        (lines["billed_charge"] > 0) &
        (~lines["carc"].astype(str).isin(BUNDLING_CARCS))
    )
    lines["_adj_date"] = pd.to_datetime(lines["claim_adjudication_date"], errors="coerce")
    lines["_month"]    = lines["_adj_date"].dt.to_period("M")

    monthly = (
        lines.dropna(subset=["_month"])
        .groupby(["payer_id", "billed_cpt", "_month"])
        .agg(total=("billed_charge", "count"), denied=("line_denied", "sum"))
        .reset_index()
    )
    monthly = monthly[monthly["total"] >= 5]
    monthly["dr"]          = monthly["denied"] / monthly["total"]
    monthly["penetration"] = monthly["dr"] / denial_ceiling
    monthly["_t"] = (
        monthly.groupby(["payer_id", "billed_cpt"])["_month"]
        .transform(lambda s: (s - s.min()).apply(lambda p: p.n))
    )

    code_df = (
        monthly.sort_values("_month")
        .groupby(["payer_id", "billed_cpt"])
        .agg(_n_months=("_month", "nunique"), _latest_pen=("penetration", "last"),
             _t=("_t", list), _penetration=("penetration", list))
        .reset_index()
    )

    def regress(row):
        if row["_n_months"] < 2:
            return 0.0, 1.0
        res = linregress(row["_t"], row["_penetration"])
        one_tail_p = res.pvalue / 2 if res.slope > 0 else 1.0
        return res.slope, one_tail_p

    reg = code_df.apply(regress, axis=1, result_type="expand")
    code_df["_slope"] = reg[0]
    code_df["_pval"]  = reg[1]

    drifting = code_df[
        (code_df["_slope"] > 0) &
        (code_df["_latest_pen"] > 0) &
        (code_df["_latest_pen"] < 1.0)
    ].copy()

    payer_rows   = []
    at_risk_sets = {}

    for payer, g in code_df.groupby("payer_id"):
        n_codes    = len(g)
        drift_g    = drifting[drifting["payer_id"] == payer]
        n_drifting = len(drift_g)

        if n_drifting == 0:
            payer_rows.append({"payer_id": payer, "e01_edv": 0.0, "e01_at_risk_codes": None,
                                "e01_lowest_risk_code": None, "p_value": 1.0, "confidence": 0.0, "e01_flag": False})
            at_risk_sets[payer] = set()
            continue

        edv      = drift_g["_slope"].mean()
        avg_pval = drift_g["_pval"].mean()
        at_risk  = dict(zip(drift_g["billed_cpt"].tolist(), drift_g["_latest_pen"].tolist()))
        at_risk_sets[payer] = set(at_risk.keys())

        codes_str = ", ".join(f"{c} ({round(p * 100)}%)" for c, p in sorted(at_risk.items(), key=lambda x: -x[1]))
        lowest_code = min(at_risk.items(), key=lambda x: x[1])
        lowest_str  = f"{lowest_code[0]} ({round(lowest_code[1] * 100)}%)"

        c1 = min(1 - avg_pval, 1.0); c2 = min(edv / 0.05, 1.0)
        c3 = min(n_drifting / max(n_codes, 1), 1.0); c4 = 0.1
        confidence = round(min(c1*0.4 + c2*0.3 + c3*0.2 + c4, 1.0), 4)

        payer_rows.append({"payer_id": payer, "e01_edv": round(edv, 4),
                            "e01_at_risk_codes": codes_str, "e01_lowest_risk_code": lowest_str,
                            "p_value": round(avg_pval, 6), "confidence": confidence,
                            "e01_flag": bool(edv > 0 and avg_pval < p_thresh and confidence >= conf_thresh)})

    payer_df = pd.DataFrame(payer_rows).sort_values("e01_edv", ascending=False).reset_index(drop=True)

    df_out = df.copy()
    df_out = df_out.drop(columns=[c for c in df_out.columns if c.startswith("e01_")], errors="ignore")
    df_out["e01_line_drift"] = df_out.apply(
        lambda r: 1 if r["billed_cpt"] in at_risk_sets.get(r["payer_id"], set()) else 0, axis=1)

    cpt_drift_rows = [{"payer_id": payer, "billed_cpt": cpt, "e01_line_drift": 1}
                      for payer, codes in at_risk_sets.items() for cpt in codes]
    cpt_drift = pd.DataFrame(cpt_drift_rows) if cpt_drift_rows else pd.DataFrame(
        columns=["payer_id", "billed_cpt", "e01_line_drift"])

    return df_out, payer_df, cpt_drift


def find_pdp(df, claim_level=False, claim_id=[], prob_thresh=0.70, conf_thresh=0.80):
    """E02 - Predicted-Denial Pressure (PDP)."""
    if claim_level:
        df = df[df["claim_id"].isin(claim_id)]

    lines = df.copy()
    BUNDLING_CARCS = {"97", "234"}
    lines["line_denied"] = (
        (lines["line_paid"] == 0) &
        (lines["billed_charge"] > 0) &
        (~lines["carc"].astype(str).isin(BUNDLING_CARCS))
    )
    lines["cpt_family"] = lines["billed_cpt"].astype(str).str[:2]

    denied_lines    = lines[lines["line_denied"]]
    denied_codes    = denied_lines.groupby("payer_id")["billed_cpt"].apply(set)
    denied_families = denied_lines.groupby("payer_id")["cpt_family"].apply(set)
    billed_codes    = lines.groupby("payer_id")["billed_cpt"].apply(set)
    total_lines_map = lines.groupby("payer_id").size()

    family_dr = (
        lines.groupby(["payer_id", "cpt_family"])
        .agg(total=("line_denied", "count"), denied=("line_denied", "sum"))
        .assign(dr=lambda x: x["denied"] / x["total"]).reset_index()
    )
    fdr_map = family_dr.set_index(["payer_id", "cpt_family"])["dr"].to_dict()

    at_risk_map = {}
    rows        = []

    for payer in lines["payer_id"].unique():
        denied      = denied_codes.get(payer, set())
        families    = denied_families.get(payer, set())
        billed      = billed_codes.get(payer, set())
        total_lines = total_lines_map.get(payer, 1)

        code_probs = {}
        for code in (billed - denied):
            fam = str(code)[:2]
            if fam in families:
                code_probs[code] = fdr_map.get((payer, fam), 0.0)

        above = {c: p for c, p in code_probs.items() if p >= prob_thresh}
        at_risk_map[payer] = set(above.keys())

        n_above = len(above); n_billed = len(billed); n_families = len(families)
        max_prob = max(above.values()) if above else 0.0
        n_at_risk_lines = lines[(lines["payer_id"] == payer) & (lines["billed_cpt"].isin(above))].shape[0]

        c1 = min(max_prob, 1.0); c2 = min(n_above / max(n_billed, 1), 1.0)
        c3 = min(n_at_risk_lines / max(total_lines, 1), 1.0); c4 = 0.1 if n_families > 1 else 0.0
        confidence = round(min(c1*0.4 + c2*0.3 + c3*0.2 + c4, 1.0), 4)

        codes_str = ", ".join(f"{c} ({round(p*100)}%)" for c, p in sorted(above.items(), key=lambda x: -x[1])) if above else None
        rows.append({"payer_id": payer, "e02_pdp": n_above, "e02_at_risk_codes": codes_str,
                     "e02_max_prob": round(max_prob, 4),
                     "e02confidence": confidence if n_above > 0 else 0.0,
                     "e02_flag": bool(n_above > 0 and confidence >= conf_thresh)})

    payer_df = pd.DataFrame(rows).sort_values("e02_pdp", ascending=False).reset_index(drop=True)

    df_out = df.copy()
    df_out = df_out.drop(columns=[c for c in df_out.columns if c.startswith("e02_")], errors="ignore")
    df_out["e02_line_at_risk"] = df_out.apply(
        lambda r: 1 if r["billed_cpt"] in at_risk_map.get(r["payer_id"], set()) else 0, axis=1)

    at_risk_rows = [{"payer_id": payer, "billed_cpt": cpt}
                    for payer, cpts in at_risk_map.items() for cpt in cpts]
    at_risk_df = pd.DataFrame(at_risk_rows) if at_risk_rows else pd.DataFrame(columns=["payer_id", "billed_cpt"])

    return df_out, payer_df, at_risk_df


def find_sas(df, claim_level=False, claim_id=[], flag_thresh=3.0, conf_thresh=0.80, stale_days=45):
    """E03 - Structural Anomaly Score (SAS)."""
    if claim_level:
        df = df[df["claim_id"].isin(claim_id)]

    lines = df.copy()
    BUNDLING_CARCS = {"97", "234"}
    lines["line_denied"] = (
        (lines["line_paid"] == 0) &
        (lines["billed_charge"] > 0) &
        (~lines["carc"].astype(str).isin(BUNDLING_CARCS))
    )
    lines["cpt_family"] = lines["billed_cpt"].astype(str).str[:2]

    family = (
        lines.groupby(["payer_id", "cpt_family"])
        .agg(total=("billed_charge", "count"), denied=("line_denied", "sum"))
        .reset_index()
    )
    family["dr"] = family["denied"] / family["total"]

    claims = lines.drop_duplicates("claim_id").copy()
    status_col = ("claim_status_effective_date" if "claim_status_effective_date" in claims.columns
                  else "claim_adjudication_date")
    claims[status_col] = pd.to_datetime(claims[status_col], errors="coerce")
    claims["claim_adjudication_date"] = pd.to_datetime(claims["claim_adjudication_date"], errors="coerce")
    as_of_date = claims["claim_adjudication_date"].dropna().max()
    claims["_days_pending"] = (as_of_date - claims[status_col]).dt.days
    claims["_stale"] = ((claims["claim_pend_flag"] == 1) & (claims["_days_pending"] > stale_days)).astype(int)

    silent_drop = (
        claims.groupby("payer_id")
        .agg(n_claims=("claim_id", "size"), n_stale=("_stale", "sum")).reset_index()
    )
    silent_drop["silent_drop_rate"] = silent_drop["n_stale"] / silent_drop["n_claims"]
    sdr_map = silent_drop.set_index("payer_id")["silent_drop_rate"].to_dict()

    strangeness_rows = []
    for payer, g in family.groupby("payer_id"):
        mean_dr   = g["dr"].mean()
        denial_cv = g["dr"].std() / mean_dr if mean_dr > 0 else 0.0
        sdr       = sdr_map.get(payer, 0.0)
        strangeness = round(0.6 * denial_cv + 0.4 * sdr, 6)
        strangeness_rows.append({"payer_id": payer, "denial_cv": round(denial_cv, 4),
                                  "silent_drop_rate": round(sdr, 4), "strangeness": strangeness})

    payer_df = pd.DataFrame(strangeness_rows)
    mu, sigma = payer_df["strangeness"].mean(), payer_df["strangeness"].std()
    payer_df["e03_sas"] = 0.0 if sigma == 0 else ((payer_df["strangeness"] - mu) / sigma).round(4)

    def confidence(row):
        c1 = min(max(row["e03_sas"], 0) / 5.0, 1.0)
        c2 = min(row["silent_drop_rate"] / 0.5, 1.0)
        c3 = min(row["denial_cv"] / 1.0, 1.0)
        c4 = 0.1 if row["e03_sas"] > 0 else 0.0
        return round(min(c1*0.4 + c2*0.3 + c3*0.2 + c4, 1.0), 4)

    payer_df["confidence"] = payer_df.apply(confidence, axis=1)
    payer_df["e03_flag"]   = (payer_df["e03_sas"] > flag_thresh) & (payer_df["confidence"] >= conf_thresh)
    payer_df = payer_df.sort_values("e03_sas", ascending=False).reset_index(drop=True)

    flagged_payers = payer_df.loc[payer_df["e03_flag"], "payer_id"]
    top_family = (
        family[family["payer_id"].isin(flagged_payers)]
        .sort_values("dr", ascending=False)
        .drop_duplicates("payer_id")[["payer_id", "cpt_family"]]
        .rename(columns={"cpt_family": "_top_family"})
    )

    df_out = df.copy()
    df_out = df_out.drop(columns=[c for c in df_out.columns if c.startswith("e03_")], errors="ignore")
    df_out = df_out.merge(top_family, on="payer_id", how="left")
    df_out["e03_line_anomalous"] = (
        df_out["billed_cpt"].astype(str).str[:2] == df_out["_top_family"].fillna("")
    ).astype(int)
    df_out = df_out.drop(columns=["_top_family"])

    return df_out, payer_df, top_family


# =============================================================================
# WRAPPER — add_early_signal_features
# =============================================================================

def add_early_signal_features(train_df, test_df):
    """
    Step 8 -- Early Signal Features (E01-E03).
    Computed on TRAINING split only; applied to test via payer_id / (payer, CPT) join.
    """
    PAYER_ID = config.PAYER_ID_COL

    rename_in = {
        config.CLAIM_CONTROL_NUMBER_COL: "claim_id",
        config.CARC_COL:                 "carc",
        config.PROCEDURE_CODE_COL:       "billed_cpt",
        config.TOTAL_CLAIM_CHARGE_COL:   "billed_charge",
        "line_paid_amount":              "line_paid",
        config.SUBMISSION_DATE_COL:      "submission_date",
        config.FINAL_STATUS_DATE_COL:    "claim_adjudication_date",
        "pend_flag_beh":                 "claim_pend_flag",
    }
    rename_in = {k: v for k, v in rename_in.items() if k in train_df.columns}
    work = train_df.rename(columns=rename_in)

    print("\nStep 8: Early signal features (train — computing E01-E03)")

    work, p_e01, cpt_drift  = find_edv(work)
    work, p_e02, at_risk    = find_pdp(work)
    work, p_e03, top_family = find_sas(work)

    new_cols = ["e01_line_drift", "e02_line_at_risk", "e03_line_anomalous"]
    for col in new_cols:
        if col in work.columns:
            train_df[col] = work[col].values

    n_added = sum(1 for c in new_cols if c in train_df.columns)
    print(f"  {n_added} line-level early signal columns added to train.")
    logger.info("E01-E03 computed on train — %d line-level columns added.", n_added)

    payer_lookups = [
        (p_e01, ["e01_edv", "e01_flag"]),
        (p_e02, ["e02_pdp", "e02confidence", "e02_flag", "e02_max_prob"]),
        (p_e03, ["e03_sas", "e03_flag"]),
    ]

    print("Step 8: Early signal features (train — applying payer-level signals)")
    for payer_df_lookup, cols in payer_lookups:
        if payer_df_lookup is None or payer_df_lookup.empty:
            continue
        available = [c for c in cols if c in payer_df_lookup.columns]
        if not available:
            continue
        lookup   = payer_df_lookup[[PAYER_ID] + available].drop_duplicates(PAYER_ID)
        train_df = train_df.merge(lookup, on=PAYER_ID, how="left")
        for c in available:
            if c.endswith("_flag"):
                train_df[c] = train_df[c].fillna(False)
            else:
                fill = lookup[c].median()
                train_df[c] = train_df[c].fillna(fill if pd.notna(fill) else 0.0)

    n_payer = sum(1 for _, cols in payer_lookups for c in cols if c in train_df.columns)
    print(f"  {n_payer} payer-level early signal columns added to train.")
    logger.info("E01-E03 payer-level signals applied to train — %d columns.", n_payer)

    print("Step 8: Early signal features (test — applying train tables)")
    for payer_df_lookup, cols in payer_lookups:
        if payer_df_lookup is None or payer_df_lookup.empty:
            continue
        available = [c for c in cols if c in payer_df_lookup.columns]
        if not available:
            continue
        lookup  = payer_df_lookup[[PAYER_ID] + available].drop_duplicates(PAYER_ID)
        test_df = test_df.merge(lookup, on=PAYER_ID, how="left")
        for c in available:
            if c.endswith("_flag"):
                test_df[c] = test_df[c].fillna(False)
            else:
                fill = lookup[c].median()
                test_df[c] = test_df[c].fillna(fill if pd.notna(fill) else 0.0)

    cpt_col = config.PROCEDURE_CODE_COL

    if cpt_drift is not None and not cpt_drift.empty:
        lookup_e01 = cpt_drift.rename(columns={"billed_cpt": cpt_col})
        test_df = test_df.merge(lookup_e01[[PAYER_ID, cpt_col, "e01_line_drift"]], on=[PAYER_ID, cpt_col], how="left")
        test_df["e01_line_drift"] = test_df["e01_line_drift"].fillna(0).astype(int)

    if at_risk is not None and not at_risk.empty:
        lookup_e02 = at_risk.rename(columns={"billed_cpt": cpt_col})
        lookup_e02["e02_line_at_risk"] = 1
        test_df = test_df.merge(lookup_e02[[PAYER_ID, cpt_col, "e02_line_at_risk"]], on=[PAYER_ID, cpt_col], how="left")
        test_df["e02_line_at_risk"] = test_df["e02_line_at_risk"].fillna(0).astype(int)

    if top_family is not None and not top_family.empty:
        test_df = test_df.merge(top_family[[PAYER_ID, "_top_family"]], on=PAYER_ID, how="left")
        test_cpt_family = test_df[cpt_col].astype(str).str[:2]
        test_df["e03_line_anomalous"] = (test_cpt_family == test_df["_top_family"].fillna("")).astype(int)
        test_df = test_df.drop(columns=["_top_family"])

    n_test = sum(1 for c in new_cols if c in test_df.columns)
    print(f"  {n_test} line-level early signal columns applied to test.")
    logger.info("E01-E03 applied to test — %d line-level columns present.", n_test)

    E_SIGNAL_DEFAULTS = {
        "e01_edv": 0.0, "e01_flag": False, "e01_line_drift": 0,
        "e02_pdp": 0, "e02confidence": 0.0, "e02_flag": False,
        "e02_max_prob": 0.0, "e02_line_at_risk": 0,
        "e03_sas": 0.0, "e03_flag": False, "e03_line_anomalous": 0,
    }
    for col, default in E_SIGNAL_DEFAULTS.items():
        if col not in train_df.columns:
            train_df[col] = default
        if col not in test_df.columns:
            test_df[col] = default

    try:
        import config.paths_config as _pc
        try:
            bundle = joblib.load(str(_pc.PAYER_LOOKUP_BUNDLE_PKL))
        except Exception:
            bundle = {"payer_behaviour_lookups": [], "payer_id_col": PAYER_ID}
        bundle.update({
            "early_signal_payer_lookups": payer_lookups,
            "cpt_drift":  cpt_drift,
            "at_risk":    at_risk,
            "top_family": top_family,
            "cpt_col":    config.PROCEDURE_CODE_COL,
        })
        joblib.dump(bundle, str(_pc.PAYER_LOOKUP_BUNDLE_PKL))
        logger.info("Payer lookup bundle updated with early signal data → %s", _pc.PAYER_LOOKUP_BUNDLE_PKL)
    except Exception as _e:
        logger.warning("Could not update payer lookup bundle with early signals: %s", _e)

    print("  [DONE] add_early_signal_features — E01-E03 complete.")
    logger.info("add_early_signal_features complete — train %s | test %s.",
                train_df.shape, test_df.shape)
    return train_df, test_df
