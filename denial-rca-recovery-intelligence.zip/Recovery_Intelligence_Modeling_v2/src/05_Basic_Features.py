# 05- Basic_Features.py

"""
Basic_Features.py / Core Feature Engineering (Steps 0-9)

Handles:
  0.  Load data
  1.  Temporal features
  2.  Lifecycle count features
  3.  Financial features
  4.  Field presence flags
  5.  Denial code features
  6.  Clinical features
  7.  Claim status flags
  8.  Auth and prior-auth flags
  9.  Line-level detail flags
  14. Save ADS

Called by feature_engineering.py (orchestrator).
"""

import os
import sys

import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import config.feature_engineering_config as config

import logging
logger = logging.getLogger(__name__)


# =============================================================================
# STEP 0 — LOAD DATA
# =============================================================================

def load_data(input_file, label=""):
    """
    Read a cleaned Excel file and return a pandas DataFrame.

    Excel sometimes reads date columns as plain text.
    We re-parse those back to proper datetime objects here.
    """
    print(f"\nStep 0: Load data ({label})")
    print(f"  File : {input_file}")

    if not os.path.exists(input_file):
        raise FileNotFoundError(
            f"File not found: {input_file}\n"
            "Run data_cleaning.py first."
        )

    df = pd.read_excel(input_file)
    print(f"  Loaded {df.shape[0]:,} rows x {df.shape[1]} columns")
    logger.info("INPUT  (%s): %s | %d rows x %d cols", label, input_file, df.shape[0], df.shape[1])
    logger.info("Columns (%d): %s", len(df.columns), ", ".join(df.columns.tolist()))

    # Excel can store dates as text strings — parse them back to date type
    date_columns = [
        config.SUBMISSION_DATE_COL,
        config.FINAL_STATUS_DATE_COL,
        config.PAYMENT_DATE_COL,
    ]
    for col in date_columns:
        if col in df.columns:
            df[col] = pd.to_datetime(df[col], errors="coerce")

    print(f"  [DONE] load_data ({label}) — {df.shape[0]:,} rows x {df.shape[1]} cols")
    logger.info("load_data (%s) complete — %d rows x %d cols.", label, df.shape[0], df.shape[1])
    return df


# =============================================================================
# STEP 1 — TEMPORAL FEATURES
# Measure how many days things took.
# =============================================================================

def add_temporal_features(df):
    """
    Add two features that measure time elapsed between key claim events.

    days_to_adjudication : days from claim submission to the final status decision.
    submission_lag_days  : days from service date to when the payer received the claim.

    Negative values are clipped to 0 — they indicate data entry errors.
    """
    print("\nStep 1: Temporal features")

    sub_col    = config.SUBMISSION_DATE_COL    # bht_date
    status_col = config.FINAL_STATUS_DATE_COL  # claim_final_status_date

    # How many days from submission to final decision?
    if sub_col in df.columns and status_col in df.columns:
        raw_days = (df[status_col] - df[sub_col]).dt.days
        df["days_to_adjudication"] = raw_days.clip(lower=0)
        print("  days_to_adjudication     : OK")

    # How many days from service date to claim receipt?
    if "claim_received_date" in df.columns and "service_date" in df.columns:
        received = pd.to_datetime(df["claim_received_date"], errors="coerce")
        service  = pd.to_datetime(df["service_date"],        errors="coerce")
        df["submission_lag_days"] = (received - service).dt.days.clip(lower=0)
        print("  submission_lag_days      : OK")
    else:
        df["submission_lag_days"] = np.nan
        print("  submission_lag_days      : NaN (claim_received_date or service_date not found)")

    print("  [DONE] Step 1 — Temporal features complete.")
    logger.info("Step 1 complete — temporal features added.")
    return df


# =============================================================================
# STEP 2 — LIFECYCLE COUNT FEATURES
# Count how many times key events happened to a claim.
# =============================================================================

def add_lifecycle_count_features(df):
    """
    Add three features that count claim lifecycle events.

    resubmission_indicator       : 1 if this claim was ever resubmitted, else 0.
    resubmission_count_per_claim : total resubmission rows for the same claim.
    denial_count                 : number of denial GROUP events for the claim.
    """
    print("\nStep 2: Lifecycle count features")

    ccn_col = config.CLAIM_CONTROL_NUMBER_COL  # unique claim ID

    # A claim counts as resubmitted if ANY of these three signals fires:
    #   Signal 1 — is_resubmitted flag is set
    #   Signal 2 — claim_frequency_code is 7 (corrected claim)
    #   Signal 3 — original_reference_number links back to a prior claim
    is_resub = pd.Series(False, index=df.index)

    if "is_resubmitted" in df.columns:
        is_resub = is_resub | df["is_resubmitted"].astype(str).isin(["1", "True", "true"])

    if "claim_frequency_code" in df.columns:
        is_resub = is_resub | (df["claim_frequency_code"] == config.CORRECTED_SUBMISSION_CODE)

    if "original_reference_number" in df.columns:
        ref_clean = df["original_reference_number"].astype(str).str.strip()
        has_ref   = df["original_reference_number"].notna() & ref_clean.ne("") & ref_clean.ne("nan")
        is_resub  = is_resub | has_ref

    df["resubmission_indicator"] = is_resub.astype(int)
    print(f"  resubmission_indicator       : OK  ({df['resubmission_indicator'].sum():,} claims flagged)")

    # Sum of resubmission rows per claim (broadcast to every row of that claim)
    if ccn_col in df.columns:
        df["resubmission_count_per_claim"] = (
            df.groupby(ccn_col)["resubmission_indicator"].transform("sum")
        )
        print("  resubmission_count_per_claim : OK")

    # Count how many denial GROUP code events occurred for each claim
    if config.GROUP_COL in df.columns and ccn_col in df.columns:
        df["denial_count"] = (
            df.groupby(ccn_col)[config.GROUP_COL]
              .transform(lambda x: x.isin(config.DENIAL_GROUP_CODES).sum())
        )
        print("  denial_count                 : OK")

    print("  [DONE] Step 2 — Lifecycle count features complete.")
    logger.info("Step 2 complete — lifecycle count features added.")
    return df


# =============================================================================
# STEP 3 — FINANCIAL FEATURES
# Measure the dollar impact of the denial.
# =============================================================================

def add_financial_features(df):
    """
    Add one financial feature: the total amount the payer did NOT pay.

    denied_amount = total_claim_charge - total_paid_amount (floored at 0).
    """
    print("\nStep 3: Financial features")

    if "total_claim_charge" in df.columns and "total_paid_amount" in df.columns:
        billed = df["total_claim_charge"].fillna(0)
        paid   = df["total_paid_amount"].fillna(0)
        df["denied_amount"] = (billed - paid).clip(lower=0)
        print("  denied_amount                : OK")
    else:
        print("  denied_amount                : skipped (columns not found)")

    print("  [DONE] Step 3 — Financial features complete.")
    logger.info("Step 3 complete — financial features added.")
    return df


# =============================================================================
# STEP 4 — FIELD PRESENCE FLAGS
# Check whether key claim fields were actually filled in.
# =============================================================================

def add_field_presence_flags(df):
    """
    Add a binary flag for each important claim field.

    Flag = 1 means the field has a real value.
    Flag = 0 means the field is missing or contains a known placeholder (e.g. "NO_AUTH").

    The list of fields and their placeholders is in config.MISSING_FLAG_FEATURES.
    """
    print("\nStep 4: Field presence flags")

    for flag_name, (source_col, absent_value) in config.MISSING_FLAG_FEATURES.items():

        if source_col not in df.columns:
            df[flag_name] = 0
            print(f"  {flag_name:40s}: 0  (column '{source_col}' not found)")
            continue

        if absent_value is None:
            # No placeholder defined — field is present when value is not null
            df[flag_name] = df[source_col].notna().astype(int)
        else:
            # Field is present when value is not the known absent placeholder
            df[flag_name] = (df[source_col] != absent_value).astype(int)

        n_filled = df[flag_name].sum()
        print(f"  {flag_name:40s}: OK  ({n_filled:,} rows filled)")

    print("  [DONE] Step 4 — Field presence flags complete.")
    logger.info("Step 4 complete — %d field presence flags added.", len(config.MISSING_FLAG_FEATURES))
    return df


# =============================================================================
# STEP 5 — DENIAL CODE FEATURES
# Categorise how the claim was denied using payer GROUP and RARC codes.
# =============================================================================

def add_denial_code_features(df):
    """
    Add denial category flags based on the X12 835 GROUP and RARC codes.

    GROUP codes (from config.DENIAL_GROUP_FLAGS):
      OA = Other Adjustment
      PI = Payer Initiated Reduction

    has_rarc = 1 if the payer attached a Remittance Advice Remark Code (extra detail).
    """
    print("\nStep 5: Denial code features")

    # Create one binary flag per GROUP code we care about (defined in config)
    if config.GROUP_COL in df.columns:
        for flag_name, group_code in config.DENIAL_GROUP_FLAGS.items():
            df[flag_name] = (df[config.GROUP_COL] == group_code).astype(int)
            print(f"  {flag_name:40s}: OK")

    # Did the payer include an RARC remark code?
    if config.RARC_COL in df.columns:
        rarc_str = df[config.RARC_COL].astype(str).str.strip()
        df["has_rarc"] = (
            df[config.RARC_COL].notna()
            & rarc_str.ne("")
            & rarc_str.ne(config.RARC_ABSENT_VALUE)
            & rarc_str.ne("nan")
        ).astype(int)
        print(f"  has_rarc : OK  ({df['has_rarc'].sum():,} rows with RARC)")

    print("  [DONE] Step 5 — Denial code features complete.")
    logger.info("Step 5 complete — denial code features added.")
    return df


# =============================================================================
# STEP 6 — CLINICAL FEATURES
# Describe the clinical content of the claim.
# =============================================================================

def add_clinical_features(df):
    """
    Add one feature: how many ICD diagnosis codes were submitted.

    num_diagnoses counts the filled slots across:
      principal_diagnosis, diagnosis_2, diagnosis_3, diagnosis_4.
    A slot counts only if it is not null and not the absent placeholder "NONE".
    """
    print("\nStep 6: Clinical features")

    diag_cols = [col for col in config.DIAGNOSIS_COLUMNS if col in df.columns]

    if diag_cols:
        def count_filled_diagnoses(row):
            count = 0
            for value in row:
                if pd.notna(value) and value != config.DIAGNOSIS_ABSENT_VALUE:
                    count += 1
            return count

        df["num_diagnoses"] = df[diag_cols].apply(count_filled_diagnoses, axis=1)
        print(f"  num_diagnoses                : OK  ({len(diag_cols)} diagnosis columns used)")

    print("  [DONE] Step 6 — Clinical features complete.")
    logger.info("Step 6 complete — clinical features added.")
    return df


# =============================================================================
# STEP 7 — CLAIM STATUS FLAGS
# Two binary flags needed by the payer behaviour B01-B12 functions.
# =============================================================================

def add_claim_status_flags(df):
    """
    Add two binary flags that describe the adjudication status of each claim.

    denial_flag_beh : 1 if the claim was denied on the first adjudication pass.
                      Derived from initial_outcome == "Denied".

    pend_flag_beh   : 1 if the claim is still pending / unresolved by the payer.
                      Derived from claim_final_status == "P1" (277 status code).
    """
    print("\nStep 7: Claim status flags")

    # Was the claim denied on the very first time the payer processed it?
    if config.INITIAL_OUTCOME_COL in df.columns:
        df["denial_flag_beh"] = (df[config.INITIAL_OUTCOME_COL] == config.CLAIM_DENIED_LABEL).astype(int)
        print(f"  denial_flag_beh              : OK  ({df['denial_flag_beh'].sum():,} denied)")
    else:
        df["denial_flag_beh"] = 0
        print("  denial_flag_beh              : 0   (initial_outcome not found)")

    # Is the claim still sitting in a pended / unresolved state?
    if "claim_final_status" in df.columns:
        df["pend_flag_beh"] = (
            df["claim_final_status"].astype(str).str.strip() == config.PEND_STATUS_CODE
        ).astype(int)
        print(f"  pend_flag_beh                : OK  ({df['pend_flag_beh'].sum():,} pended)")
    else:
        df["pend_flag_beh"] = 0
        print("  pend_flag_beh                : 0   (claim_final_status not found)")

    print("  [DONE] Step 7 — Claim status flags complete.")
    logger.info("Step 7 complete — claim status flags added.")
    return df


# =============================================================================
# STEP 8 — AUTH AND PRIOR-AUTHORISATION FLAGS
# Derives the columns that B07 (auth contradiction) and B08 (surprise PA) need.
# These are row-level: applied identically to both train and test.
# =============================================================================

def add_auth_and_pa_flags(df):
    """
    Derive six row-level columns that describe prior authorisation status.

    denial_flag               : 1 if the line was denied.
    carc_code                 : cleaned string version of the CARC field.
    auth_token_present        : 1 if the provider submitted a real prior-auth number.
    carc197_flag              : 1 if the denial reason is CARC 197.
    post_approved_then_denied : auth token present + denied + CARC 197 (feeds B07).
    surprise_pa               : no auth token + denied + CARC 197 (feeds B08).
    """
    print("\nStep 8: Auth and prior-auth flags")

    # --- Step 1: denial_flag ---
    denial = pd.Series(False, index=df.index)
    if "is_denied" in df.columns:
        denial = denial | (df["is_denied"] == 1)
    if "line_paid_amount" in df.columns:
        paid_zero = df["line_paid_amount"].notna() & (df["line_paid_amount"] <= 0)
        denial = denial | paid_zero
    df["denial_flag"] = denial.astype(int)
    print(f"  denial_flag                  : OK  ({df['denial_flag'].sum():,} denied lines)")

    # --- Step 2: carc_code ---
    if config.CARC_COL in df.columns:
        carc = df[config.CARC_COL].astype(str).str.strip()
        carc = carc.replace({"nan": "NONE", "None": "NONE", "": "NONE", "0": "NONE"})
        df["carc_code"] = carc
    else:
        df["carc_code"] = "NONE"
    print("  carc_code                    : OK")

    # --- Step 3: auth_token_present ---
    if "prior_authorization_number" in df.columns:
        token = df["prior_authorization_number"].astype(str).str.strip()
        df["auth_token_present"] = (~token.isin({"", "nan", "None", "0"})).astype(int)
    else:
        df["auth_token_present"] = 0
    print(f"  auth_token_present           : OK  ({df['auth_token_present'].sum():,} with auth)")

    # --- Step 4: carc197_flag ---
    df["carc197_flag"] = (df["carc_code"] == "197").astype(int)
    print(f"  carc197_flag                 : OK  ({df['carc197_flag'].sum():,} CARC-197 lines)")

    # --- Step 5: post_approved_then_denied (input to B07) ---
    df["post_approved_then_denied"] = (
        (df["auth_token_present"] == 1) &
        (df["denial_flag"]        == 1) &
        (df["carc197_flag"]       == 1)
    ).astype(int)
    print(f"  post_approved_then_denied    : OK  ({df['post_approved_then_denied'].sum():,} contradictions)")

    # --- Step 6: surprise_pa (input to B08) ---
    df["surprise_pa"] = (
        (df["auth_token_present"] == 0) &
        (df["denial_flag"]        == 1) &
        (df["carc197_flag"]       == 1)
    ).astype(int)
    print(f"  surprise_pa                  : OK  ({df['surprise_pa'].sum():,} surprise-PA denials)")

    print("  [DONE] Step 8 — Auth and prior-auth flags complete.")
    logger.info("Step 8 complete — auth and PA flags added.")
    return df


# =============================================================================
# STEP 9 — LINE-LEVEL DETAIL FLAGS
# Derives line-level quantity and CARC flags needed by B06.
# Applied identically to both train and test.
# =============================================================================

def add_line_detail_flags(df):
    """
    Derive five line-level flags about payment adjustments.

    line_qty_shave_flag     : 1 if the payer paid for fewer units than were billed.
    line_unit_shortfall     : how many units were short (billed minus paid, floor 0).
    linebundled_any_flag   : 1 if the CARC code indicates bundling (97 or 236).
    line_downcode_any_flag  : always 0 — 835 has no separate paid CPT field.
    line_downcode_amount_sum: always 0 — same reason.
    """
    print("\nStep 9: Line-level detail flags")

    # --- Quantity shaving ---
    if "units" in df.columns and "units_paid" in df.columns:
        billed_units = df["units"].fillna(0)
        paid_units   = df["units_paid"].fillna(0)
        shortfall    = (billed_units - paid_units).clip(lower=0)
        df["line_qty_shave_flag"] = (shortfall > 0).astype(int)
        df["line_unit_shortfall"] = shortfall
        print(f"  line_qty_shave_flag          : OK  ({df['line_qty_shave_flag'].sum():,} shaved lines)")
        print(f"  line_unit_shortfall          : OK")
    else:
        df["line_qty_shave_flag"] = 0
        df["line_unit_shortfall"] = 0.0
        print("  line_qty_shave_flag          : 0   (units or units_paid not found)")
        print("  line_unit_shortfall          : 0.0 (units or units_paid not found)")

    # --- Bundling flag ---
    if config.CARC_COL in df.columns:
        carc_str       = df[config.CARC_COL].astype(str).str.strip()
        bundling_codes = [str(c) for c in config.BUNDLING_CARCS]
        df["linebundled_any_flag"] = carc_str.isin(bundling_codes).astype(int)
        print(f"  linebundled_any_flag        : OK  ({df['linebundled_any_flag'].sum():,} bundled lines)")
    else:
        df["linebundled_any_flag"] = 0
        print("  linebundled_any_flag        : 0   (CARC column not found)")

    # --- Downcoding --- always 0 in this dataset ---
    df["line_downcode_any_flag"]   = 0
    df["line_downcode_amount_sum"] = 0.0
    print("  line_downcode_any_flag       : 0   (835 has no separate paid CPT field)")
    print("  line_downcode_amount_sum     : 0.0 (835 has no separate paid CPT field)")

    print("  [DONE] Step 9 — Line-level detail flags complete.")
    logger.info("Step 9 complete — line-level detail flags added.")
    return df


# =============================================================================
# STEP 14 — SAVE THE FINAL ADS
# =============================================================================

def save_ads(df, output_file, label=""):
    """
    Print a feature count summary and save the final ADS to an Excel file.
    """
    print(f"\nSave ADS ({label})")
    print(f"  Shape : {df.shape[0]:,} rows x {df.shape[1]} columns")

    all_new = [
        # Step 1 — Temporal
        "days_to_adjudication",
        "submission_lag_days",
        # Step 2 — Lifecycle counts
        "resubmission_indicator",
        "resubmission_count_per_claim",
        "denial_count",
        # Step 3 — Financial
        "denied_amount",
        # Step 4 — Field presence flags (list comes from config)
        *list(config.MISSING_FLAG_FEATURES.keys()),
        # Step 5 — Denial codes (list comes from config) + RARC
        *list(config.DENIAL_GROUP_FLAGS.keys()),
        "has_rarc",
        # Step 6 — Clinical
        "num_diagnoses",
        # Step 7 — Claim status flags
        "denial_flag_beh", "pend_flag_beh",
        # Step 8 — Auth and prior-auth flags (inputs to B07 and B08)
        "denial_flag", "carc_code", "auth_token_present",
        "carc197_flag", "post_approved_then_denied", "surprise_pa",
        # Step 9 — Line-level detail flags (inputs to B04 and B06)
        "line_qty_shave_flag", "line_unit_shortfall",
        "linebundled_any_flag",
        "line_downcode_any_flag", "line_downcode_amount_sum",
        # Step 10 — Payer behavior B01-B12 (list comes from config)
        *config.PAYER_BEHAVIOR_FEATURES,
        # Step 8 — Early signal features E01-E03 (list comes from config)
        *config.EARLY_SIGNAL_FEATURES,
        # Step 15 — KRI features KRI-1 to KRI-4 (list comes from config)
        *config.KRI_FEATURES,
        # Step 15 — KPI features KPI-01 to KPI-05 (list comes from config)
        *config.KPI_FEATURES,
    ]

    present = [f for f in all_new if f in df.columns]
    print(f"  Features present : {len(present)} of {len(all_new)} expected")

    os.makedirs(os.path.dirname(output_file), exist_ok=True)
    df.to_excel(output_file, index=False, engine="openpyxl")

    print(f"  Saved : {output_file}")
    print(f"  [DONE] save_ads ({label}) — {df.shape[0]:,} rows x {df.shape[1]} cols saved.")
    logger.info("OUTPUT (%s): %s | %d rows x %d cols", label, output_file, df.shape[0], df.shape[1])
    logger.info("Columns (%d): %s", len(df.columns), ", ".join(df.columns.tolist()))
