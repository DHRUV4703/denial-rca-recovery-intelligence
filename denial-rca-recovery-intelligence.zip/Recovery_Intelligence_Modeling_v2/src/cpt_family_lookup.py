"""
cpt_family_lookup.py - CPT / HCPCS medical code family lookup

Converted from Notebooks/07_CPT_Family.ipynb. Maps a billed procedure code
(CPT or HCPCS Level II) to its AAPC "family" name, e.g. "99214" ->
"Office or Other Outpatient Services". Used by feature_engineering.py for
KRI-2 (Family Capture Ratio).

All scraper settings (URLs, CSS selectors, page size, depth cap, wait time)
are read from config.feature_engineering_config — nothing is hardcoded here.

Two use cases:
  1. Normal use (feature_engineering.py) - scrape in-memory, no file I/O:
         from cpt_family_lookup import get_lookup_func, scrape_in_memory
         range_df = scrape_in_memory()
         lookup   = get_lookup_func(range_df=range_df)
         family   = lookup("99214")

  2. One-time setup - build medical_code_ranges.csv from AAPC's site
     (requires Chrome + selenium, opens a real browser window):
         from cpt_family_lookup import scrape_and_save
         scrape_and_save("medical_code_ranges.csv")

If neither a range_df nor a CSV path is supplied, get_lookup_func() falls
back to a 2-character code-prefix grouping so the pipeline still runs end
to end.
"""

import bisect
import os
import re
import sys
import time

import pandas as pd

# Suppress the harmless OSError raised by undetected_chromedriver's __del__
# on Windows when the Chrome handle is already closed at process exit.
try:
    import undetected_chromedriver as _uc
    _uc.Chrome.__del__ = lambda self: None
except Exception:
    pass

# Pull scraper settings from config (no hardcoded values here)
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from config.feature_engineering_config import (
    CPT_CODE_SYSTEMS,
    CPT_SYSTEM_PRIORITY,
    CPT_ROW_SELECTORS,
    CPT_SCRAPER_PAGE_SIZE,
    CPT_SCRAPER_MAX_DEPTH,
    CPT_SCRAPER_WAIT_SECONDS,
    CPT_NORMALISE_THRESHOLD,
)

# One medical-code token: optional leading letter, 1-5 digits, optional
# decimal, optional trailing letter (CPT Category II/III/PLA suffixes).
CODE_TOKEN_RE = re.compile(r"^([A-Z]*)(\d{1,5})(?:\.(\d+))?([A-Z]?)$")


# =============================================================================
# CODE PARSING & OVERLAP DETECTION
# =============================================================================

class RangeRow:
    """One (range, family-name, href) entry from an AAPC listing page."""
    __slots__ = ("range_text", "family", "href", "depth")

    def __init__(self, range_text, family, href, depth=0):
        self.range_text = range_text
        self.family = family
        self.href = href
        self.depth = depth


def parse_code_token(token):
    """Normalize one code token into (letter, int, frac, suffix), or None if unparseable."""
    token = token.strip()
    if len(token) == 1 and token.isalnum():
        return ("", int(token), 0.0, "") if token.isdigit() else (token, -1, 0.0, "")
    m = CODE_TOKEN_RE.match(token)
    if not m:
        return None
    letter, digits, decimals, suffix = m.groups()
    if letter and suffix:
        return None
    frac = float(f"0.{decimals}") if decimals else 0.0
    return (letter or "", int(digits), frac, suffix or "")


def parse_range(range_text):
    """Return (start_key, end_key, group) for a range string like '99201-99215', or None."""
    text = range_text.replace("®", "").strip()
    if "-" not in text:
        code = parse_code_token(text)
        if code is None:
            return None
        letter, integer, frac, suffix = code
        return (letter, integer, frac), (letter, integer, frac), suffix

    left, _, right = text.partition("-")
    c1, c2 = parse_code_token(left), parse_code_token(right)
    if c1 is None or c2 is None or c1[3] != c2[3]:
        return None
    return (c1[0], c1[1], c1[2]), (c2[0], c2[1], c2[2]), c1[3]


def overlaps(row_a, row_b):
    """True when two RangeRows have numerically overlapping code ranges."""
    pa, pb = parse_range(row_a.range_text), parse_range(row_b.range_text)
    if pa is None or pb is None:
        return False
    s1, e1, g1 = pa
    s2, e2, g2 = pb
    if g1 != g2:
        return False
    return s1 <= e2 and s2 <= e1


# =============================================================================
# WEB SCRAPER (Selenium)
# =============================================================================

def _detect_chrome_major():
    """Read installed Chrome major version from the Windows registry."""
    import re
    import subprocess
    registry_paths = [
        r"HKLM\SOFTWARE\Google\Chrome\BLBeacon",
        r"HKCU\SOFTWARE\Google\Chrome\BLBeacon",
        r"HKLM\SOFTWARE\Wow6432Node\Google\Chrome\BLBeacon",
    ]
    for path in registry_paths:
        try:
            out = subprocess.check_output(
                ["reg", "query", path, "/v", "version"],
                text=True, stderr=subprocess.DEVNULL,
            )
            m = re.search(r"(\d+)\.\d+\.\d+", out)
            if m:
                return int(m.group(1))
        except Exception:
            continue
    return None


def make_driver():
    """Launch headless Chrome via undetected-chromedriver to avoid AAPC bot detection.

    Detects the installed Chrome major version from the Windows registry and
    passes it as version_main so uc downloads the matching ChromeDriver binary
    instead of defaulting to the latest release, which may not match the
    installed browser.
    """
    import undetected_chromedriver as uc

    options = uc.ChromeOptions()
    options.add_argument("--window-size=1400,1000")
    options.add_argument("--disable-gpu")
    options.add_argument("--headless=new")

    chrome_major = _detect_chrome_major()
    if chrome_major:
        return uc.Chrome(options=options, version_main=chrome_major)
    return uc.Chrome(options=options)


def _extract_row(card):
    from selenium.webdriver.common.by import By

    links = card.find_elements(By.TAG_NAME, "a")
    if not links:
        return None
    range_text = links[0].text.strip()
    href = links[0].get_attribute("href")
    family = links[1].text.strip() if len(links) > 1 else ""
    if not range_text or not family:
        return None
    return RangeRow(range_text, family, href)


def fetch_rows(driver, url):
    """Fetch every (range, family, href) row from a listing page, walking pagination."""
    from selenium.webdriver.common.by import By

    rows, prev_texts, offset = [], None, 0
    base = url.rstrip("/")

    while True:
        page_url = f"{base}/" if offset == 0 else f"{base}/{offset}"
        driver.get(page_url)

        deadline, cards = time.time() + CPT_SCRAPER_WAIT_SECONDS, []
        while time.time() < deadline:
            for selector in CPT_ROW_SELECTORS:
                cards = driver.find_elements(By.CSS_SELECTOR, selector)
                if cards:
                    break
            if cards or driver.execute_script("return document.readyState") == "complete":
                break
            time.sleep(0.2)
        time.sleep(0.8)

        for selector in CPT_ROW_SELECTORS:
            cards = driver.find_elements(By.CSS_SELECTOR, selector)
            if cards:
                break
        if not cards:
            break

        page_rows = [r for r in (_extract_row(c) for c in cards) if r is not None]
        if not page_rows:
            break

        cur_texts = tuple(r.range_text for r in page_rows)
        if cur_texts == prev_texts:
            break

        rows.extend(page_rows)
        prev_texts = cur_texts
        if len(page_rows) < CPT_SCRAPER_PAGE_SIZE:
            break
        offset += CPT_SCRAPER_PAGE_SIZE

    return rows


def expand_to_children(driver, rows):
    """Follow every family href and replace the parent with its sub-ranges."""
    expanded = []
    for row in rows:
        if not row.href:
            expanded.append(row)
            continue
        children = fetch_rows(driver, row.href)
        if children:
            for c in children:
                c.depth = row.depth + 1
            expanded.extend(children)
        else:
            expanded.append(row)
    return expanded


def resolve_overlaps(driver, rows):
    """Iteratively expand overlapping sibling ranges into sub-ranges until disjoint."""
    finalized, frontier, depth = [], rows, 0

    while frontier and depth < CPT_SCRAPER_MAX_DEPTH:
        depth += 1
        overlapping_idx = set()
        for i in range(len(frontier)):
            for j in range(i + 1, len(frontier)):
                if overlaps(frontier[i], frontier[j]):
                    overlapping_idx.add(i)
                    overlapping_idx.add(j)

        if not overlapping_idx:
            finalized.extend(frontier)
            frontier = []
            break

        clean = [r for i, r in enumerate(frontier) if i not in overlapping_idx]
        to_expand = [r for i, r in enumerate(frontier) if i in overlapping_idx]
        finalized.extend(clean)

        next_frontier = []
        for row in to_expand:
            children = fetch_rows(driver, row.href)
            if not children:
                finalized.append(row)
            else:
                for c in children:
                    c.depth = row.depth + 1
                next_frontier.extend(children)
        frontier = next_frontier

    finalized.extend(frontier)
    return finalized


def dedupe(rows):
    """Remove duplicate (range_text, family) pairs, preserving order."""
    seen, out = set(), []
    for r in rows:
        key = (r.range_text, r.family)
        if key not in seen:
            seen.add(key)
            out.append(r)
    return out


def scrape_code_system(driver, system):
    """Fetch, expand into sub-ranges, and de-overlap all ranges for one code system."""
    top_rows = fetch_rows(driver, system["url"])
    expanded = expand_to_children(driver, top_rows)
    return dedupe(resolve_overlaps(driver, expanded))


def _normalise_family_names(family_series):
    """Merge near-duplicate family names using fuzzy matching (rapidfuzz optional)."""
    try:
        from rapidfuzz import fuzz
    except ImportError:
        return family_series

    unique_names = family_series.dropna().unique().tolist()
    canonical_map = {}
    for name in unique_names:
        if name in canonical_map:
            continue
        canonical_map[name] = name
        for other in unique_names:
            if other == name or other in canonical_map:
                continue
            if fuzz.token_sort_ratio(name, other) >= CPT_NORMALISE_THRESHOLD:
                canonical_map[other] = name

    return family_series.map(lambda n: canonical_map.get(n, n) if isinstance(n, str) else n)


def _build_result_df(frames, normalise=True):
    """Sort and optionally normalise the concatenated scrape result."""
    result_df = pd.concat(frames, ignore_index=True)
    sys_order = {s["name"]: i for i, s in enumerate(CPT_CODE_SYSTEMS)}
    result_df["_sys_order"] = result_df["Code System"].map(sys_order)
    result_df = (
        result_df.sort_values(["_sys_order", "Code Range"])
        .drop(columns="_sys_order")
        .reset_index(drop=True)
    )
    if normalise:
        result_df["Family Name"] = _normalise_family_names(result_df["Family Name"])
    return result_df


def _run_scraper():
    """Run Selenium scraper across all configured code systems and return raw frames."""
    driver = make_driver()
    try:
        frames = []
        for system in CPT_CODE_SYSTEMS:
            resolved = scrape_code_system(driver, system)
            frames.append(pd.DataFrame(
                [(system["name"], r.range_text, r.family) for r in resolved],
                columns=["Code System", "Code Range", "Family Name"],
            ))
    finally:
        driver.quit()
    return frames


def scrape_and_save(output_csv, normalise_family_names=True):
    """
    Run the full AAPC scraper and save the disjoint code-range table to output_csv.

    Opens a real Chrome window (headed mode is intentional - it avoids AAPC's
    bot detection). Run this once when the code-range reference needs refreshing.
    """
    result_df = _build_result_df(_run_scraper(), normalise_family_names)
    os.makedirs(os.path.dirname(str(output_csv)) or ".", exist_ok=True)
    result_df.to_csv(output_csv, index=False)
    return result_df


def scrape_in_memory(normalise_family_names=True):
    """
    Run the full AAPC scraper and return the code-range DataFrame without
    writing any file to disk.

    Opens a real Chrome window (headed mode is intentional - avoids AAPC's
    bot detection). Called by feature_engineering.py at pipeline start so
    KRI-2 Family Capture Ratio uses live AAPC family names without CSV I/O.
    """
    return _build_result_df(_run_scraper(), normalise_family_names)


# =============================================================================
# BISECT LOOKUP
# =============================================================================

def _build_system_lookup(range_df, system_name):
    """Parse all ranges for one code system into a bisect-ready sorted list."""
    parsed = []
    for _, row in range_df[range_df["Code System"] == system_name].iterrows():
        parsed_range = parse_range(row["Code Range"])
        if parsed_range is None:
            continue
        start_key, end_key, _ = parsed_range
        parsed.append({"family": row["Family Name"], "start_key": start_key, "end_key": end_key})
    parsed.sort(key=lambda r: r["start_key"])
    return parsed, [r["start_key"] for r in parsed]


def _lookup_in_system(code_key, rows, starts):
    """Binary search for code_key in one code system's sorted interval list."""
    idx = bisect.bisect_right(starts, code_key) - 1
    if idx < 0:
        return None
    row = rows[idx]
    return row["family"] if row["start_key"] <= code_key <= row["end_key"] else None


def build_family_lookup(range_df):
    """Build {code_system: (rows, starts)} bisect tables from a code-range DataFrame."""
    return {name: _build_system_lookup(range_df, name) for name in CPT_SYSTEM_PRIORITY}


def get_lookup_func(ranges_csv_path=None, range_df=None):
    """
    Return lookup(code_str) -> family_name for CPT / HCPCS / ICD-10 codes.

    Priority order:
      1. range_df         - in-memory DataFrame from scrape_in_memory()
      2. ranges_csv_path  - path to a previously saved medical_code_ranges.csv
      3. fallback         - 2-character code-prefix grouping (no I/O needed)
    """
    system_lookups = None
    if range_df is not None:
        system_lookups = build_family_lookup(range_df)
    elif ranges_csv_path and os.path.exists(ranges_csv_path):
        system_lookups = build_family_lookup(pd.read_csv(ranges_csv_path))
    else:
        msg = (
            f"  cpt_family_lookup: '{ranges_csv_path}' not found - "
            if ranges_csv_path else
            "  cpt_family_lookup: no range data provided - "
        )
        print(msg + "using 2-character code-prefix fallback.")

    def lookup(code_str):
        code_str = "" if code_str is None else str(code_str).strip().upper()
        if not code_str:
            return code_str
        fallback = code_str[:2] if len(code_str) >= 2 else code_str

        if system_lookups is None:
            return fallback

        parsed = parse_code_token(code_str)
        if parsed is None:
            return fallback
        code_key = (parsed[0], parsed[1], parsed[2])

        for system_name in CPT_SYSTEM_PRIORITY:
            rows, starts = system_lookups[system_name]
            family = _lookup_in_system(code_key, rows, starts)
            if family is not None:
                return family
        return fallback

    return lookup
