# 10- Modeling.py
"""
Stage 1 modelling module — Binary Denial Prediction.

Provides an inheritance-based class hierarchy for training, evaluating, and
persisting denial-prediction models, plus a full pipeline orchestration function.

Class hierarchy:
    DenialModelBase
        XGBoostDenialModel
        LightGBMDenialModel
        RandomForestDenialModel
        LogisticRegressionDenialModel        (overrides predict, _get_cv_estimator — scales inside CV)
        GradientBoostingDenialModel
        ExtraTreesDenialModel
        AdaBoostDenialModel
        DecisionTreeDenialModel
        SVMDenialModel                       (overrides predict, _get_cv_estimator — scales inside CV)
        KNearestNeighborsDenialModel         (overrides predict, _get_cv_estimator — scales inside CV)
        NaiveBayesDenialModel
        CatBoostDenialModel
        HistGradientBoostingDenialModel
        BaggingDenialModel
        MLPDenialModel                       (overrides predict, _get_cv_estimator — scales inside CV)
        LinearDiscriminantAnalysisDenialModel
        QuadraticDiscriminantAnalysisDenialModel
        SGDDenialModel                       (overrides predict, _get_cv_estimator — scales inside CV)
        BernoulliNBDenialModel
        ComplementNBDenialModel              (overrides predict, _get_cv_estimator — clips features ≥ 0)

    Ensemble models (boosting + stacking):
        BoostingEnsembleDenialModel          (soft vote across all boosting learners)
        VotingSoftDenialModel                (soft vote — averages probabilities)
        VotingHardDenialModel                (hard vote — majority class; pseudo-proba for AUC/threshold)
        StackingDenialModel                  (LR meta-learner on base-model probabilities)

    Deep learning (optional):
        FastAITabularModel                   (tabular neural net; LR Finder, 1-cycle
                                              scheduler, Early Stopping, Best-Model
                                              Saving). Enabled via cfg.FASTAI_ENABLED;
                                              requires fastai + torch.

    Explainability (standalone — NOT in the inheritance chain):
        ModelExplainer                       (SHAP, permutation importance, native
                                              importance, partial dependence (PDP),
                                              per-prediction explanation, and a
                                              plain-language business summary table)
        Construct with any trained model: ModelExplainer(model).full_report(...).
        Kept separate from DenialModelBase so models stay focused on
        train/predict/evaluate and all interpretability lives in one place.

    Business logic (fixed, not configurable):
        Catch Rate is a hard gate — every model must pass cfg.CATCH_RATE_THRESHOLD.
        Among survivors, the highest F1 Score becomes champion. Champion is saved
        automatically along with a Youden-J threshold and an explainability report
        (JSON + business-summary CSV).

    Hyperparameter tuning:
        _auto_search() automatically chooses GridSearchCV (small search space,
        ≤ cfg.GRID_SEARCH_MAX_COMBINATIONS) or RandomizedSearchCV (large space).

Usage::

    from modelling import run_modelling_pipeline
    champion_name, champion_obj, threshold = run_modelling_pipeline()
"""

from __future__ import annotations

# Standard library
import os
import sys

# Ensure the project root (one level above src/) is on the path so that
# `import config as cfg` resolves to the project's config package.
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

import pickle
import json
import logging
from pathlib import Path
from typing import Any

# Third-party
import joblib
import numpy as np
import pandas as pd
from catboost import CatBoostClassifier
from lightgbm import LGBMClassifier
from sklearn.base import clone
from sklearn.calibration import CalibratedClassifierCV
from sklearn.ensemble import (
    AdaBoostClassifier,
    ExtraTreesClassifier,
    GradientBoostingClassifier,
    RandomForestClassifier,
    StackingClassifier,
    VotingClassifier,
)
from sklearn.frozen import FrozenEstimator
from sklearn.inspection import permutation_importance
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    classification_report,
    confusion_matrix,
    f1_score,
    precision_score,
    recall_score,
    roc_auc_score,
    roc_curve,
)
from sklearn.model_selection import (
    GridSearchCV,
    RandomizedSearchCV,
    StratifiedKFold,
    cross_val_score,
    train_test_split,
)
from sklearn.discriminant_analysis import (
    LinearDiscriminantAnalysis,
    QuadraticDiscriminantAnalysis,
)
from sklearn.ensemble import BaggingClassifier, HistGradientBoostingClassifier
from sklearn.linear_model import SGDClassifier
from sklearn.naive_bayes import BernoulliNB, ComplementNB, GaussianNB
from sklearn.neighbors import KNeighborsClassifier
from sklearn.neural_network import MLPClassifier
from sklearn.pipeline import Pipeline
from sklearn.preprocessing import FunctionTransformer, StandardScaler
from sklearn.svm import SVC
from sklearn.tree import DecisionTreeClassifier
from xgboost import XGBClassifier

# Local
import config as cfg

logger = logging.getLogger(__name__)


def _nonneg_clip(X: np.ndarray) -> np.ndarray:
    """Clip feature values to [0, ∞).

    Used by ComplementNBDenialModel which requires non-negative input.
    Defined at module level so it is picklable for parallel cross-validation.
    """
    return np.clip(X, 0, None)


# ---------------------------------------------------------------------------
# Base class
# ---------------------------------------------------------------------------


class DenialModelBase:
    """Base class shared by all four denial-prediction models.

    Subclasses must implement :meth:`train` and :meth:`tune`. All evaluation,
    calibration, and comparison methods are inherited. ``LogisticRegressionDenialModel``
    overrides :meth:`predict` and :meth:`_get_cv_estimator` to apply
    ``StandardScaler`` inside each CV fold.

    Attributes:
        model: The underlying sklearn estimator; set after :meth:`train`.
        name: Display name used in logging and comparison tables.
        calibrated_model: ``CalibratedClassifierCV`` instance; set after :meth:`calibrate`.
        calibration_threshold: Youden-J optimal threshold; updated by :meth:`calibrate`.
    """

    def __init__(self) -> None:
        self.model: Any = None
        self.name: str = "Base"
        self.calibrated_model: Any = None
        self.calibration_threshold: float = 0.50
        self.calibration_method: str | None = None
        self.threshold_sweep_table: pd.DataFrame | None = None
        self.random_state: int = cfg.RANDOM_SEED

    # ------------------------------------------------------------------
    # Prediction
    # ------------------------------------------------------------------

    def predict(
        self,
        X: pd.DataFrame,
    ) -> tuple[np.ndarray, np.ndarray]:
        """Return class labels and denial probabilities.

        Overridden by :class:`LogisticRegressionDenialModel` to apply scaling.

        Args:
            X: Feature DataFrame aligned to the training feature set.

        Returns:
            Tuple of ``(class_labels, probabilities)`` as numpy arrays.
        """
        y_pred = self.model.predict(X)
        y_proba = self.model.predict_proba(X)[:, 1]
        return y_pred, y_proba

    def predict_calibrated(
        self,
        X: pd.DataFrame,
        threshold: float | None = None,
    ) -> tuple[np.ndarray, np.ndarray]:
        """Predict using the calibrated model and the Youden-J threshold.

        Args:
            X: Feature DataFrame.
            threshold: Override the stored Youden-J threshold when provided.

        Returns:
            Tuple of ``(class_labels, probabilities)`` as numpy arrays.
        """
        thr = self.calibration_threshold if threshold is None else threshold
        y_proba = self.calibrated_model.predict_proba(X)[:, 1]
        y_pred = (y_proba >= thr).astype(int)
        return y_pred, y_proba

    # ------------------------------------------------------------------
    # Evaluation
    # ------------------------------------------------------------------

    def evaluate(
        self,
        X_test: pd.DataFrame,
        y_test: pd.Series,
    ) -> dict[str, float]:
        """Compute all classification metrics on a labelled split.

        Args:
            X_test: Feature DataFrame.
            y_test: True labels.

        Returns:
            Dict with keys: ``model``, ``accuracy``, ``precision``, ``recall``,
            ``f1``, ``auc``.
        """
        y_pred, y_proba = self.predict(X_test)

        acc = accuracy_score(y_test, y_pred)
        prec = precision_score(y_test, y_pred, zero_division=0)
        rec = recall_score(y_test, y_pred, zero_division=0)
        f1 = f1_score(y_test, y_pred, zero_division=0)
        auc = roc_auc_score(y_test, y_proba) if len(y_test.unique()) > 1 else 0.0

        logger.info(
            "%s — Accuracy: %.4f | Precision: %.4f | Recall: %.4f | F1: %.4f | AUC: %.4f",
            self.name,
            acc,
            prec,
            rec,
            f1,
            auc,
        )
        logger.debug(
            "%s classification report:\n%s",
            self.name,
            classification_report(
                y_test,
                y_pred,
                target_names=["Not Denied", "Denied"],
                zero_division=0,
            ),
        )

        return {
            "model": self.name,
            "accuracy": acc,
            "precision": prec,
            "recall": rec,
            "f1": f1,
            "auc": auc,
        }

    def plot_evaluation(
        self,
        X_test: pd.DataFrame,
        y_test: pd.Series,
    ) -> tuple:
        """Build a confusion-matrix figure and an ROC-curve figure.

        Args:
            X_test: Feature DataFrame.
            y_test: True labels.

        Returns:
            Tuple of ``(confusion_matrix_fig, roc_curve_fig)``. ``roc_curve_fig``
            is ``None`` when ``y_test`` contains only one class.
        """
        import matplotlib.pyplot as plt
        import seaborn as sns

        y_pred, y_proba = self.predict(X_test)

        cm = confusion_matrix(y_test, y_pred)
        cm_fig, ax = plt.subplots(figsize=(5, 4))
        sns.heatmap(
            cm,
            annot=True,
            fmt="d",
            cmap="Blues",
            xticklabels=["Not Denied", "Denied"],
            yticklabels=["Not Denied", "Denied"],
            linewidths=0.5,
            ax=ax,
        )
        ax.set_title(f"{self.name} — Confusion Matrix")
        ax.set_ylabel("Actual")
        ax.set_xlabel("Predicted")
        cm_fig.tight_layout()

        roc_fig = None
        if len(y_test.unique()) > 1:
            auc = roc_auc_score(y_test, y_proba)
            fpr, tpr, _ = roc_curve(y_test, y_proba)
            roc_fig, ax2 = plt.subplots(figsize=(6, 4))
            ax2.plot(fpr, tpr, linewidth=2, label=f"{self.name} AUC = {auc:.3f}")
            ax2.plot([0, 1], [0, 1], "k--", label="Random")
            ax2.set_xlabel("False Positive Rate")
            ax2.set_ylabel("True Positive Rate")
            ax2.set_title(f"{self.name} — ROC Curve")
            ax2.legend()
            roc_fig.tight_layout()

        return cm_fig, roc_fig

    # ------------------------------------------------------------------
    # Cross-validation
    # ------------------------------------------------------------------

    def _get_cv_estimator(self) -> Any:
        """Return the estimator to use inside ``cross_val_score``.

        The base implementation returns ``self.model`` directly. Overridden by
        :class:`LogisticRegressionDenialModel` to return a ``Pipeline`` that
        applies ``StandardScaler`` inside each fold, preventing data leakage.

        Returns:
            An unfitted or fitted sklearn estimator / pipeline.
        """
        return self.model

    def cross_validate(
        self,
        X: pd.DataFrame,
        y: pd.Series,
        cv: int = cfg.CV_FOLDS,
        scoring: str = "f1",
    ) -> np.ndarray:
        """Run stratified k-fold CV and return per-fold scores.

        Uses :meth:`_get_cv_estimator` so that ``LogisticRegressionDenialModel``
        automatically wraps its estimator in a scaling pipeline.

        Args:
            X: Feature DataFrame.
            y: Labels.
            cv: Number of folds.
            scoring: sklearn scoring string.

        Returns:
            Array of per-fold scores with length ``cv``.
        """
        kf = StratifiedKFold(n_splits=cv, shuffle=True, random_state=cfg.RANDOM_SEED)
        estimator = self._get_cv_estimator()
        scores = cross_val_score(estimator, X, y, cv=kf, scoring=scoring)
        logger.info(
            "%s CV (%d-fold %s) — mean: %.4f ± %.4f",
            self.name,
            cv,
            scoring,
            scores.mean(),
            scores.std(),
        )
        return scores

    # ------------------------------------------------------------------
    # Feature importance
    # ------------------------------------------------------------------

    def _score(
        self,
        X: pd.DataFrame,
        y: pd.Series,
        scoring: str = "f1",
    ) -> float:
        """Compute a single score via :meth:`predict` so LR scaling is applied.

        Args:
            X: Feature DataFrame.
            y: True labels.
            scoring: One of ``'f1'``, ``'roc_auc'``, ``'accuracy'``,
                ``'recall'``, ``'precision'``.

        Returns:
            Scalar metric value.
        """
        y_pred, y_proba = self.predict(X)
        if scoring == "roc_auc":
            return roc_auc_score(y, y_proba)
        if scoring == "accuracy":
            return accuracy_score(y, y_pred)
        if scoring == "recall":
            return recall_score(y, y_pred, zero_division=0)
        if scoring == "precision":
            return precision_score(y, y_pred, zero_division=0)
        return f1_score(y, y_pred, zero_division=0)

    def feature_selection(
        self,
        X: pd.DataFrame,
        y: pd.Series,
        method: str = "permutation",
        scoring: str = "f1",
        n_repeats: int = 10,
        top_n: int = 15,
        random_state: int = cfg.RANDOM_SEED,
    ) -> pd.DataFrame:
        """Rank features by importance.

        Args:
            X: Feature DataFrame.
            y: Labels.
            method: ``'model'`` uses built-in importances (trees) or ``|coef|``
                (LR). ``'permutation'`` measures average score drop per feature.
            scoring: Metric for permutation drops; ignored when ``method='model'``.
            n_repeats: Shuffle repeats per feature (permutation only).
            top_n: Number of features to include in the debug log.
            random_state: Seed for permutation shuffling.

        Returns:
            DataFrame with columns ``feature`` and ``importance``, sorted
            descending by importance.
        """
        features = list(X.columns)

        if method == "model":
            if hasattr(self.model, "feature_importances_"):
                scores = self.model.feature_importances_
            else:
                scores = np.abs(self.model.coef_[0])
        else:
            rng = np.random.RandomState(random_state)
            baseline = self._score(X, y, scoring)
            scores = []
            for col in features:
                drop = 0.0
                for _ in range(n_repeats):
                    X_shuffled = X.copy()
                    X_shuffled[col] = rng.permutation(X_shuffled[col].values)
                    drop += baseline - self._score(X_shuffled, y, scoring)
                scores.append(drop / n_repeats)

        imp = (
            pd.DataFrame(
                {"feature": list(features), "importance": np.asarray(scores).ravel()}
            )
            .sort_values("importance", ascending=False)
            .reset_index(drop=True)
        )
        logger.debug(
            "%s feature_selection top-%d:\n%s",
            self.name,
            top_n,
            imp.head(top_n).to_string(),
        )
        return imp

    # ------------------------------------------------------------------
    # Calibration
    # ------------------------------------------------------------------

    def calibrate(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
        X_test: pd.DataFrame | None = None,
        y_test: pd.Series | None = None,
        cal_size: float = cfg.CALIBRATION_SIZE,
        random_state: int = cfg.CALIBRATION_SEED,
    ) -> Any:
        """Calibrate predicted probabilities and derive the Youden-J optimal threshold.

        Holds out ``cal_size`` of training data for the calibration layer so the
        test set remains a clean hold-out for evaluation. ``FrozenEstimator``
        (sklearn >= 1.6) prevents re-fitting the base model weights during
        calibration CV — only the isotonic or Platt layer is fitted.

        Method selection:
            - Logistic Regression (``self.scaler`` is set): Platt scaling (sigmoid).
            - Tree-based models: isotonic regression.

        Args:
            X_train: Training features.
            y_train: Training labels.
            X_test: Optional test features; used to derive the Youden-J threshold.
            y_test: Optional test labels; used to derive the Youden-J threshold.
            cal_size: Fraction of training data reserved for the calibration layer.
            random_state: Seed for the calibration split.

        Returns:
            Fitted ``CalibratedClassifierCV`` stored in ``self.calibrated_model``.
        """
        X_tr, X_cal, y_tr, y_cal = train_test_split(
            X_train,
            y_train,
            test_size=cal_size,
            random_state=random_state,
            stratify=y_train,
        )

        cv_folds = max(2, min(5, int(np.min(np.bincount(y_cal)))))

        # When the sweep is enabled and we have a test set, try BOTH calibration
        # methods, sweep thresholds, and pick the best (method, threshold) combo.
        if (
            getattr(cfg, "THRESHOLD_SWEEP_ENABLED", False)
            and X_test is not None
            and y_test is not None
        ):
            self._calibrate_with_sweep(
                X_tr, y_tr, X_cal, y_cal, X_test, y_test, cv_folds
            )
            return self.calibrated_model

        if getattr(self, "scaler", None) is not None:
            base = Pipeline([("scaler", StandardScaler()), ("clf", clone(self.model))])
            cal_method = "sigmoid"
        else:
            base = clone(self.model)
            cal_method = "isotonic"

        base.fit(X_tr, y_tr)
        self.calibrated_model = CalibratedClassifierCV(
            FrozenEstimator(base), method=cal_method, cv=cv_folds
        )
        self.calibrated_model.fit(X_cal, y_cal)
        logger.info(
            "%s calibrated — method: %s, cv_folds: %d", self.name, cal_method, cv_folds
        )

        if X_test is not None and y_test is not None:
            proba = self.calibrated_model.predict_proba(X_test)[:, 1]
            fpr, tpr, thr = roc_curve(y_test, proba)
            # Drop the leading inf sentinel point sklearn prepends to the ROC arrays.
            fpr, tpr, thr = fpr[1:], tpr[1:], thr[1:]
            j = tpr - fpr
            opt_thr = float(thr[j.argmax()])

            if (
                opt_thr >= cfg.THRESHOLD_GUARD_UPPER
                or opt_thr <= cfg.THRESHOLD_GUARD_LOWER
            ):
                logger.warning(
                    "%s Youden-J threshold %.4f is extreme; falling back to %.2f",
                    self.name,
                    opt_thr,
                    cfg.THRESHOLD_FALLBACK,
                )
                opt_thr = cfg.THRESHOLD_FALLBACK

            self.calibration_threshold = opt_thr
            logger.info(
                "%s Youden-J threshold: %.4f", self.name, self.calibration_threshold
            )

        return self.calibrated_model

    def _calibrate_with_sweep(
        self,
        X_tr: pd.DataFrame,
        y_tr: pd.Series,
        X_cal: pd.DataFrame,
        y_cal: pd.Series,
        X_test: pd.DataFrame,
        y_test: pd.Series,
        cv_folds: int,
    ) -> None:
        """Try both calibration methods, sweep thresholds, and keep the best combo.

        Steps:
            1. For each calibration method (isotonic, sigmoid), fit a calibrated model.
            2. Sweep thresholds from 0.10 to 1.00 in 0.01 steps.
            3. Score accuracy / precision / recall / F1 at each threshold.
            4. Keep the (method, threshold) combo that scores highest on the chosen
               metric (``cfg.THRESHOLD_SELECT_METRIC``).

        The full sweep table is stored on ``self.threshold_sweep_table``; the winning
        method and threshold on ``self.calibration_method`` / ``self.calibration_threshold``.
        """
        # Build the list of thresholds to try, e.g. 0.10, 0.11, 0.12, ... 1.00
        thresholds = np.arange(
            cfg.THRESHOLD_SWEEP_START,
            cfg.THRESHOLD_SWEEP_STOP + 1e-9,
            cfg.THRESHOLD_SWEEP_STEP,
        )
        uses_scaler = getattr(self, "scaler", None) is not None

        results = []  # one row per (method, threshold)
        models = {}  # keep each fitted calibrated model

        # Step 1 + 2 + 3: for each calibration method, fit and score every threshold.
        for method in cfg.CALIBRATION_METHODS:
            if uses_scaler:
                base = Pipeline(
                    [("scaler", StandardScaler()), ("clf", clone(self.model))]
                )
            else:
                base = clone(self.model)
            base.fit(X_tr, y_tr)

            try:
                calibrated = CalibratedClassifierCV(
                    FrozenEstimator(base), method=method, cv=cv_folds
                )
                calibrated.fit(X_cal, y_cal)
            except Exception as exc:  # a method can fail on very small data
                logger.warning(
                    "%s: '%s' calibration failed (%s), skipping", self.name, method, exc
                )
                continue

            models[method] = calibrated
            probs = calibrated.predict_proba(X_test)[:, 1]

            for t in thresholds:
                predictions = (probs >= t).astype(int)
                results.append(
                    {
                        "calibration": method,
                        "threshold": round(float(t), 2),
                        "accuracy": round(accuracy_score(y_test, predictions), 4),
                        "precision": round(
                            precision_score(y_test, predictions, zero_division=0), 4
                        ),
                        "recall": round(
                            recall_score(y_test, predictions, zero_division=0), 4
                        ),
                        "f1": round(f1_score(y_test, predictions, zero_division=0), 4),
                    }
                )

        sweep_table = pd.DataFrame(results)
        self.threshold_sweep_table = sweep_table

        if sweep_table.empty:
            logger.warning(
                "%s: sweep produced no results, using fallback threshold", self.name
            )
            self.calibration_threshold = cfg.THRESHOLD_FALLBACK
            self.calibrated_model = next(iter(models.values()), None)
            return

        # Step 4: pick the row with the highest score on the chosen metric.
        metric = getattr(cfg, "THRESHOLD_SELECT_METRIC", "f1")
        best_row = sweep_table.sort_values(metric, ascending=False).iloc[0]

        self.calibration_method = best_row["calibration"]
        self.calibration_threshold = float(best_row["threshold"])
        self.calibrated_model = models[best_row["calibration"]]

        logger.info(
            "%s: best combo → calibration=%s, threshold=%.2f (%s=%.4f)",
            self.name,
            self.calibration_method,
            self.calibration_threshold,
            metric,
            best_row[metric],
        )

    # ------------------------------------------------------------------
    # Comparison
    # ------------------------------------------------------------------

    @staticmethod
    def compare(
        models_list: list[DenialModelBase],
        X_test: pd.DataFrame,
        y_test: pd.Series,
    ) -> pd.DataFrame:
        """Build a side-by-side metrics table for a list of trained models.

        Args:
            models_list: Trained model instances.
            X_test: Test features.
            y_test: Test labels.

        Returns:
            DataFrame indexed by model name with metric columns.
        """
        rows = []
        for m in models_list:
            y_pred, y_proba = m.predict(X_test)
            rows.append(
                {
                    "Model": m.name,
                    "Accuracy": round(accuracy_score(y_test, y_pred), 4),
                    "Precision": round(
                        precision_score(y_test, y_pred, zero_division=0), 4
                    ),
                    "Recall": round(recall_score(y_test, y_pred, zero_division=0), 4),
                    "F1 Score": round(f1_score(y_test, y_pred, zero_division=0), 4),
                    "AUC-ROC": round(
                        roc_auc_score(y_test, y_proba)
                        if len(y_test.unique()) > 1
                        else 0.0,
                        4,
                    ),
                }
            )
        df = pd.DataFrame(rows).set_index("Model")
        logger.info("Model comparison:\n%s", df.to_string())
        return df

    # ------------------------------------------------------------------
    # Abstract interface
    # ------------------------------------------------------------------

    def train(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
    ) -> DenialModelBase:
        """Fit the model to training data.

        Args:
            X_train: Training features.
            y_train: Training labels.

        Returns:
            Self, for method chaining.

        Raises:
            NotImplementedError: When called on the base class directly.
        """
        raise NotImplementedError("Subclass must implement train()")

    def tune(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
    ) -> dict[str, Any]:
        """Run hyperparameter search and update instance attributes.

        Args:
            X_train: Training features.
            y_train: Training labels.

        Returns:
            Best hyperparameter dict from the search.

        Raises:
            NotImplementedError: When called on the base class directly.
        """
        raise NotImplementedError("Subclass must implement tune()")


# ---------------------------------------------------------------------------
# XGBoost subclass
# ---------------------------------------------------------------------------


class XGBoostDenialModel(DenialModelBase):
    """XGBoost denial-prediction model.

    Inherits: ``predict``, ``evaluate``, ``cross_validate``, ``calibrate``,
    ``compare``, ``feature_selection``.
    Adds: ``train`` (with ``RandomizedSearchCV`` tuning), ``feature_importance``
    (gain-based).

    Attributes:
        n_estimators: Number of boosting rounds.
        max_depth: Maximum tree depth.
        learning_rate: Step size shrinkage.
        subsample: Row subsampling ratio.
        colsample_bytree: Column subsampling ratio per tree.
        min_child_weight: Minimum sum of instance weight in a leaf.
        random_state: Random seed for reproducibility.
    """

    def __init__(self) -> None:
        super().__init__()
        self.name = "XGBoost"
        self.n_estimators: int = cfg.XGBOOST_DEFAULTS["n_estimators"]
        self.max_depth: int = cfg.XGBOOST_DEFAULTS["max_depth"]
        self.learning_rate: float = cfg.XGBOOST_DEFAULTS["learning_rate"]
        self.subsample: float = cfg.XGBOOST_DEFAULTS["subsample"]
        self.colsample_bytree: float = cfg.XGBOOST_DEFAULTS["colsample_bytree"]
        self.min_child_weight: int = 1
        self.random_state: int = cfg.RANDOM_SEED

    def train(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
    ) -> XGBoostDenialModel:
        """Fit ``XGBClassifier`` with current hyperparameters.

        Args:
            X_train: Training features.
            y_train: Training labels.

        Returns:
            Self, for method chaining.
        """
        logger.info(
            "Training %s (n_est=%d, depth=%d, lr=%.3f)",
            self.name,
            self.n_estimators,
            self.max_depth,
            self.learning_rate,
        )
        self.model = XGBClassifier(
            n_estimators=self.n_estimators,
            max_depth=self.max_depth,
            learning_rate=self.learning_rate,
            subsample=self.subsample,
            colsample_bytree=self.colsample_bytree,
            min_child_weight=self.min_child_weight,
            random_state=self.random_state,
            eval_metric="logloss",
            n_jobs=-1,
        )
        self.model.fit(X_train, y_train)
        logger.info("%s trained", self.name)
        return self

    def tune(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
        n_iter: int = cfg.XGBOOST_N_ITER,
    ) -> dict[str, Any]:
        """Run ``RandomizedSearchCV`` over the XGBoost hyperparameter grid.

        Updates instance attributes with the best found parameters.

        Args:
            X_train: Training features.
            y_train: Training labels.
            n_iter: Number of random parameter combinations to try.

        Returns:
            Dict of best hyperparameters.
        """
        logger.info("Tuning %s (n_iter=%d)...", self.name, n_iter)
        param_grid = {
            "n_estimators": [50, 100, 200, 300],
            "max_depth": [3, 4, 6, 8],
            "learning_rate": [0.01, 0.05, 0.1, 0.2],
            "subsample": [0.7, 0.8, 1.0],
            "colsample_bytree": [0.7, 0.8, 1.0],
            "min_child_weight": [1, 3, 5],
        }
        base = XGBClassifier(eval_metric="logloss", random_state=self.random_state)
        search = _auto_search(
            base,
            param_grid,
            X_train,
            y_train,
            n_iter=n_iter,
            random_state=self.random_state,
        )

        self.n_estimators = search.best_params_["n_estimators"]
        self.max_depth = search.best_params_["max_depth"]
        self.learning_rate = search.best_params_["learning_rate"]
        self.subsample = search.best_params_["subsample"]
        self.colsample_bytree = search.best_params_["colsample_bytree"]
        self.min_child_weight = search.best_params_["min_child_weight"]

        logger.info(
            "%s best params: %s | best F1: %.4f",
            self.name,
            search.best_params_,
            search.best_score_,
        )
        return search.best_params_

    def feature_importance(
        self,
        feature_cols: list[str],
        top_n: int = 15,
    ) -> pd.DataFrame:
        """Return XGBoost gain-based feature importances.

        Args:
            feature_cols: Ordered list of feature names matching the training columns.
            top_n: Number of top features to include in the returned DataFrame.

        Returns:
            DataFrame with columns ``feature`` and ``importance``, sorted descending,
            limited to ``top_n`` rows.
        """
        imp = (
            pd.DataFrame(
                {
                    "feature": feature_cols,
                    "importance": np.asarray(self.model.feature_importances_).ravel(),
                }
            )
            .sort_values("importance", ascending=False)
            .head(top_n)
            .reset_index(drop=True)
        )
        logger.debug(
            "%s top-%d feature importance:\n%s", self.name, top_n, imp.to_string()
        )
        return imp


# ---------------------------------------------------------------------------
# LightGBM subclass
# ---------------------------------------------------------------------------


class LightGBMDenialModel(DenialModelBase):
    """LightGBM denial-prediction model.

    Inherits: ``predict``, ``evaluate``, ``cross_validate``, ``calibrate``,
    ``compare``, ``feature_selection``.
    Adds: ``train`` (with ``GridSearchCV`` tuning), ``feature_importance``
    (split-count-based).

    ``num_leaves`` is the primary complexity parameter. ``class_weight='balanced'``
    corrects for the denied/paid class imbalance.

    Attributes:
        n_estimators: Number of boosting rounds.
        max_depth: Maximum tree depth (``-1`` = unlimited; complexity governed by ``num_leaves``).
        learning_rate: Step size shrinkage.
        num_leaves: Maximum number of leaves per tree.
        min_child_samples: Minimum samples required in a leaf.
        random_state: Random seed for reproducibility.
    """

    def __init__(self) -> None:
        super().__init__()
        self.name = "LightGBM"
        self.n_estimators: int = cfg.LIGHTGBM_DEFAULTS["n_estimators"]
        self.max_depth: int = -1
        self.learning_rate: float = cfg.LIGHTGBM_DEFAULTS["learning_rate"]
        self.num_leaves: int = cfg.LIGHTGBM_DEFAULTS["num_leaves"]
        self.min_child_samples: int = 20
        self.random_state: int = cfg.RANDOM_SEED

    def train(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
    ) -> LightGBMDenialModel:
        """Fit ``LGBMClassifier`` with current hyperparameters.

        Args:
            X_train: Training features.
            y_train: Training labels.

        Returns:
            Self, for method chaining.
        """
        logger.info(
            "Training %s (n_est=%d, num_leaves=%d, lr=%.3f)",
            self.name,
            self.n_estimators,
            self.num_leaves,
            self.learning_rate,
        )
        self.model = LGBMClassifier(
            n_estimators=self.n_estimators,
            max_depth=self.max_depth,
            learning_rate=self.learning_rate,
            num_leaves=self.num_leaves,
            min_child_samples=self.min_child_samples,
            random_state=self.random_state,
            class_weight="balanced",
            verbose=-1,
            n_jobs=-1,
        )
        self.model.fit(X_train, y_train)
        logger.info("%s trained", self.name)
        return self

    def tune(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
        n_iter: int = cfg.LIGHTGBM_N_ITER,
    ) -> dict[str, Any]:
        """Tune LightGBM hyperparameters via :func:`_auto_search`.

        Updates instance attributes with the best found parameters.

        Args:
            X_train: Training features.
            y_train: Training labels.
            n_iter: Random-search budget (used when combinations exceed threshold).

        Returns:
            Dict of best hyperparameters.
        """
        logger.info("Tuning %s (n_iter=%d)...", self.name, n_iter)
        param_grid = {
            "n_estimators": [50, 100, 200],
            "max_depth": [-1, 5, 10],
            "learning_rate": [0.05, 0.1, 0.2],
            "num_leaves": [20, 31, 50],
        }
        base = LGBMClassifier(
            random_state=self.random_state, class_weight="balanced", verbose=-1
        )
        search = _auto_search(
            base,
            param_grid,
            X_train,
            y_train,
            n_iter=n_iter,
            random_state=self.random_state,
        )

        self.n_estimators = search.best_params_["n_estimators"]
        self.max_depth = search.best_params_["max_depth"]
        self.learning_rate = search.best_params_["learning_rate"]
        self.num_leaves = search.best_params_["num_leaves"]

        logger.info(
            "%s best params: %s | best F1: %.4f",
            self.name,
            search.best_params_,
            search.best_score_,
        )
        return search.best_params_

    def feature_importance(
        self,
        feature_cols: list[str],
        top_n: int = 15,
    ) -> pd.DataFrame:
        """Return LightGBM split-count-based feature importances.

        Args:
            feature_cols: Ordered list of feature names matching the training columns.
            top_n: Number of top features to include in the returned DataFrame.

        Returns:
            DataFrame with columns ``feature`` and ``importance``, sorted descending,
            limited to ``top_n`` rows.
        """
        imp = (
            pd.DataFrame(
                {
                    "feature": feature_cols,
                    "importance": np.asarray(self.model.feature_importances_).ravel(),
                }
            )
            .sort_values("importance", ascending=False)
            .head(top_n)
            .reset_index(drop=True)
        )
        logger.debug(
            "%s top-%d feature importance:\n%s", self.name, top_n, imp.to_string()
        )
        return imp


# ---------------------------------------------------------------------------
# Random Forest subclass
# ---------------------------------------------------------------------------


class RandomForestDenialModel(DenialModelBase):
    """Random Forest denial-prediction model.

    Inherits: ``predict``, ``evaluate``, ``cross_validate``, ``calibrate``,
    ``compare``, ``feature_selection``.
    Adds: ``train`` (with ``GridSearchCV`` tuning), ``feature_importance``
    (mean decrease in Gini impurity).

    ``class_weight='balanced'`` corrects for the denied/paid class imbalance.

    Attributes:
        n_estimators: Number of trees in the forest.
        max_depth: Maximum tree depth (``None`` grows until all leaves are pure).
        min_samples_split: Minimum samples required to split an internal node.
        random_state: Random seed for reproducibility.
    """

    def __init__(self) -> None:
        super().__init__()
        self.name = "Random Forest"
        self.n_estimators: int = cfg.RANDOM_FOREST_DEFAULTS["n_estimators"]
        self.max_depth: int | None = cfg.RANDOM_FOREST_DEFAULTS["max_depth"]
        self.min_samples_split: int = cfg.RANDOM_FOREST_DEFAULTS["min_samples_split"]
        self.random_state: int = cfg.RANDOM_SEED

    def train(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
    ) -> RandomForestDenialModel:
        """Fit ``RandomForestClassifier`` with current hyperparameters.

        Args:
            X_train: Training features.
            y_train: Training labels.

        Returns:
            Self, for method chaining.
        """
        logger.info(
            "Training %s (n_est=%d, depth=%s)",
            self.name,
            self.n_estimators,
            self.max_depth,
        )
        self.model = RandomForestClassifier(
            n_estimators=self.n_estimators,
            max_depth=self.max_depth,
            min_samples_split=self.min_samples_split,
            random_state=self.random_state,
            class_weight="balanced",
            n_jobs=-1,
        )
        self.model.fit(X_train, y_train)
        logger.info("%s trained", self.name)
        return self

    def tune(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
        n_iter: int = cfg.RF_N_ITER,
    ) -> dict[str, Any]:
        """Tune Random Forest hyperparameters via :func:`_auto_search`.

        Updates instance attributes with the best found parameters.

        Args:
            X_train: Training features.
            y_train: Training labels.
            n_iter: Random-search budget (used when combinations exceed threshold).

        Returns:
            Dict of best hyperparameters.
        """
        logger.info("Tuning %s (n_iter=%d)...", self.name, n_iter)
        param_grid = {
            "n_estimators": [50, 100, 200, 300],
            "max_depth": [None, 5, 10, 20],
            "min_samples_split": [2, 5, 10, 15],
        }
        base = RandomForestClassifier(
            random_state=self.random_state, class_weight="balanced"
        )
        search = _auto_search(
            base,
            param_grid,
            X_train,
            y_train,
            n_iter=n_iter,
            random_state=self.random_state,
        )

        self.n_estimators = search.best_params_["n_estimators"]
        self.max_depth = search.best_params_["max_depth"]
        self.min_samples_split = search.best_params_["min_samples_split"]

        logger.info(
            "%s best params: %s | best F1: %.4f",
            self.name,
            search.best_params_,
            search.best_score_,
        )
        return search.best_params_

    def feature_importance(
        self,
        feature_cols: list[str],
        top_n: int = 15,
    ) -> pd.DataFrame:
        """Return Random Forest Gini-based feature importances.

        Args:
            feature_cols: Ordered list of feature names matching the training columns.
            top_n: Number of top features to include in the returned DataFrame.

        Returns:
            DataFrame with columns ``feature`` and ``importance``, sorted descending,
            limited to ``top_n`` rows.
        """
        imp = (
            pd.DataFrame(
                {
                    "feature": feature_cols,
                    "importance": np.asarray(self.model.feature_importances_).ravel(),
                }
            )
            .sort_values("importance", ascending=False)
            .head(top_n)
            .reset_index(drop=True)
        )
        logger.debug(
            "%s top-%d feature importance:\n%s", self.name, top_n, imp.to_string()
        )
        return imp


# ---------------------------------------------------------------------------
# Logistic Regression subclass
# ---------------------------------------------------------------------------


class LogisticRegressionDenialModel(DenialModelBase):
    """Logistic Regression denial-prediction model.

    Inherits: ``evaluate``, ``calibrate``, ``compare``, ``feature_selection``.
    Overrides: :meth:`predict` (applies the training-fitted scaler before inference),
               :meth:`_get_cv_estimator` (returns a ``Pipeline`` so scaling is inside
               each fold, preventing data leakage).
    Adds: ``train``, ``tune`` (``GridSearchCV``), ``coefficients``.

    Attributes:
        C: Inverse regularisation strength.
        max_iter: Maximum solver iterations.
        solver: Optimisation algorithm.
        random_state: Random seed for reproducibility.
        scaler: ``StandardScaler`` fitted during :meth:`train`; used by :meth:`predict`
            and detected by :meth:`calibrate` to select Platt scaling.
    """

    def __init__(self) -> None:
        super().__init__()
        self.name = "Logistic Regression"
        self.C: float = cfg.LOGISTIC_REGRESSION_DEFAULTS["C"]
        self.max_iter: int = cfg.LOGISTIC_REGRESSION_DEFAULTS["max_iter"]
        self.solver: str = cfg.LOGISTIC_REGRESSION_DEFAULTS["solver"]
        self.random_state: int = cfg.RANDOM_SEED
        self.scaler: StandardScaler | None = None

    def train(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
    ) -> LogisticRegressionDenialModel:
        """Fit ``StandardScaler`` and ``LogisticRegression`` on the training data.

        The scaler is stored as ``self.scaler`` so :meth:`predict` can apply it
        at inference time without re-fitting.

        Args:
            X_train: Training features.
            y_train: Training labels.

        Returns:
            Self, for method chaining.
        """
        logger.info("Training %s (C=%.3f, solver=%s)", self.name, self.C, self.solver)
        self.scaler = StandardScaler()
        X_scaled = self.scaler.fit_transform(X_train)
        self.model = LogisticRegression(
            C=self.C,
            max_iter=self.max_iter,
            solver=self.solver,
            random_state=self.random_state,
            class_weight="balanced",
            n_jobs=-1,
        )
        self.model.fit(X_scaled, y_train)
        logger.info("%s trained", self.name)
        return self

    def predict(
        self,
        X: pd.DataFrame,
    ) -> tuple[np.ndarray, np.ndarray]:
        """Override: apply the training-fitted scaler before prediction.

        Args:
            X: Feature DataFrame (unscaled).

        Returns:
            Tuple of ``(class_labels, probabilities)``.
        """
        X_scaled = self.scaler.transform(X)
        y_pred = self.model.predict(X_scaled)
        y_proba = self.model.predict_proba(X_scaled)[:, 1]
        return y_pred, y_proba

    def _get_cv_estimator(self) -> Pipeline:
        """Return a Pipeline that scales inside each CV fold.

        Overrides the base implementation to prevent the scaler from being fit
        on the full training set before CV, which would leak validation-fold
        statistics into each fold's training distribution.

        Returns:
            ``Pipeline([('scaler', StandardScaler()), ('lr', LogisticRegression(...))])``.
        """
        return Pipeline(
            [
                ("scaler", StandardScaler()),
                (
                    "lr",
                    LogisticRegression(
                        C=self.C,
                        max_iter=self.max_iter,
                        solver=self.solver,
                        random_state=self.random_state,
                        class_weight="balanced",
                        n_jobs=-1,
                    ),
                ),
            ]
        )

    def tune(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
        n_iter: int = cfg.TUNE_N_ITER,
    ) -> dict[str, Any]:
        """Tune LR hyperparameters via :func:`_auto_search` with a scaler+LR Pipeline.

        Wrapping the scaler inside the Pipeline means ``StandardScaler`` is fit
        only on each fold's training portion — validation-fold statistics never
        contaminate the scaler, eliminating preprocessing leakage during tuning.

        Args:
            X_train: Training features (unscaled).
            y_train: Training labels.
            n_iter: Random-search budget (used when combinations exceed threshold).

        Returns:
            Dict of best hyperparameters (keys: ``lr__C``, ``lr__solver``).
        """
        logger.info("Tuning %s (Pipeline — scaler inside each fold)...", self.name)
        pipe = Pipeline(
            [
                ("scaler", StandardScaler()),
                (
                    "lr",
                    LogisticRegression(
                        max_iter=self.max_iter,
                        random_state=self.random_state,
                        class_weight="balanced",
                        n_jobs=-1,
                    ),
                ),
            ]
        )
        param_grid = {
            "lr__C": [0.01, 0.1, 1.0, 10.0, 100.0],
            "lr__solver": ["lbfgs", "saga"],
        }
        search = _auto_search(
            pipe,
            param_grid,
            X_train,
            y_train,
            n_iter=n_iter,
            random_state=self.random_state,
        )

        self.C = search.best_params_["lr__C"]
        self.solver = search.best_params_["lr__solver"]

        logger.info(
            "%s best params: %s | best F1: %.4f",
            self.name,
            search.best_params_,
            search.best_score_,
        )
        return search.best_params_

    def coefficients(
        self,
        feature_cols: list[str],
        top_n: int = 15,
    ) -> pd.DataFrame:
        """Return signed LR coefficients sorted by absolute magnitude.

        Positive coefficients raise denial probability; negative ones lower it.

        Args:
            feature_cols: Ordered list of feature names matching the training columns.
            top_n: Number of features to include in the returned DataFrame.

        Returns:
            DataFrame with columns ``feature``, ``coefficient``, and ``abs_coef``,
            sorted descending by ``abs_coef``, limited to ``top_n`` rows.
        """
        coef_df = (
            pd.DataFrame(
                {
                    "feature": feature_cols,
                    "coefficient": self.model.coef_[0],
                }
            )
            .assign(abs_coef=lambda d: d["coefficient"].abs())
            .sort_values("abs_coef", ascending=False)
            .head(top_n)
            .reset_index(drop=True)
        )
        logger.debug(
            "%s top-%d coefficients:\n%s", self.name, top_n, coef_df.to_string()
        )
        return coef_df


# ---------------------------------------------------------------------------
# Gradient Boosting subclass
# ---------------------------------------------------------------------------


class GradientBoostingDenialModel(DenialModelBase):
    """sklearn GradientBoostingClassifier denial-prediction model.

    Stage-wise additive modelling with decision trees. Slower than XGBoost or
    LightGBM but a useful independent comparison point. No class_weight support —
    imbalance is handled via the NearMiss-resampled training set.
    RandomizedSearchCV tuning.

    Attributes:
        n_estimators: Number of boosting stages.
        max_depth: Maximum depth of individual trees.
        learning_rate: Shrinkage applied to each tree contribution.
        subsample: Fraction of samples used per tree (stochastic GBM).
        min_samples_split: Minimum samples to split an internal node.
    """

    def __init__(self) -> None:
        super().__init__()
        self.name = "Gradient Boosting"
        self.n_estimators: int = cfg.GRADIENT_BOOSTING_DEFAULTS["n_estimators"]
        self.max_depth: int = cfg.GRADIENT_BOOSTING_DEFAULTS["max_depth"]
        self.learning_rate: float = cfg.GRADIENT_BOOSTING_DEFAULTS["learning_rate"]
        self.subsample: float = cfg.GRADIENT_BOOSTING_DEFAULTS["subsample"]
        self.min_samples_split: int = cfg.GRADIENT_BOOSTING_DEFAULTS[
            "min_samples_split"
        ]
        self.random_state: int = cfg.RANDOM_SEED

    def train(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
    ) -> GradientBoostingDenialModel:
        logger.info(
            "Training %s (n_est=%d, depth=%d, lr=%.3f)",
            self.name,
            self.n_estimators,
            self.max_depth,
            self.learning_rate,
        )
        self.model = GradientBoostingClassifier(
            n_estimators=self.n_estimators,
            max_depth=self.max_depth,
            learning_rate=self.learning_rate,
            subsample=self.subsample,
            min_samples_split=self.min_samples_split,
            random_state=self.random_state,
        )
        self.model.fit(X_train, y_train)
        logger.info("%s trained", self.name)
        return self

    def tune(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
        n_iter: int = cfg.GRADIENT_BOOSTING_N_ITER,
    ) -> dict[str, Any]:
        logger.info("Tuning %s (n_iter=%d)...", self.name, n_iter)
        param_grid = {
            "n_estimators": [50, 100, 200, 300],
            "max_depth": [2, 3, 4, 5],
            "learning_rate": [0.01, 0.05, 0.1, 0.2],
            "subsample": [0.7, 0.8, 1.0],
            "min_samples_split": [2, 5, 10],
        }
        base = GradientBoostingClassifier(random_state=self.random_state)
        search = _auto_search(
            base,
            param_grid,
            X_train,
            y_train,
            n_iter=n_iter,
            random_state=self.random_state,
        )
        self.n_estimators = search.best_params_["n_estimators"]
        self.max_depth = search.best_params_["max_depth"]
        self.learning_rate = search.best_params_["learning_rate"]
        self.subsample = search.best_params_["subsample"]
        self.min_samples_split = search.best_params_["min_samples_split"]
        logger.info(
            "%s best params: %s | best F1: %.4f",
            self.name,
            search.best_params_,
            search.best_score_,
        )
        return search.best_params_

    def feature_importance(
        self,
        feature_cols: list[str],
        top_n: int = 15,
    ) -> pd.DataFrame:
        imp = (
            pd.DataFrame(
                {
                    "feature": list(feature_cols),
                    "importance": np.asarray(self.model.feature_importances_).ravel(),
                }
            )
            .sort_values("importance", ascending=False)
            .head(top_n)
            .reset_index(drop=True)
        )
        logger.debug(
            "%s top-%d feature importance:\n%s", self.name, top_n, imp.to_string()
        )
        return imp


# ---------------------------------------------------------------------------
# Extra Trees subclass
# ---------------------------------------------------------------------------


class ExtraTreesDenialModel(DenialModelBase):
    """Extra-Randomized Trees denial-prediction model.

    Each split threshold is drawn randomly (not optimised per feature), reducing
    variance at the cost of some bias. Faster than Random Forest at inference.
    class_weight='balanced'. GridSearchCV tuning.

    Attributes:
        n_estimators: Number of trees in the ensemble.
        max_depth: Maximum tree depth (None = unlimited).
        min_samples_split: Minimum samples required to split an internal node.
    """

    def __init__(self) -> None:
        super().__init__()
        self.name = "Extra Trees"
        self.n_estimators: int = cfg.EXTRA_TREES_DEFAULTS["n_estimators"]
        self.max_depth: int | None = cfg.EXTRA_TREES_DEFAULTS["max_depth"]
        self.min_samples_split: int = cfg.EXTRA_TREES_DEFAULTS["min_samples_split"]
        self.random_state: int = cfg.RANDOM_SEED

    def train(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
    ) -> ExtraTreesDenialModel:
        logger.info(
            "Training %s (n_est=%d, depth=%s)",
            self.name,
            self.n_estimators,
            self.max_depth,
        )
        self.model = ExtraTreesClassifier(
            n_estimators=self.n_estimators,
            max_depth=self.max_depth,
            min_samples_split=self.min_samples_split,
            random_state=self.random_state,
            class_weight="balanced",
        )
        self.model.fit(X_train, y_train)
        logger.info("%s trained", self.name)
        return self

    def tune(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
        n_iter: int = cfg.TUNE_N_ITER,
    ) -> dict[str, Any]:
        logger.info("Tuning %s (n_iter=%d)...", self.name, n_iter)
        param_grid = {
            "n_estimators": [50, 100, 200],
            "max_depth": [None, 5, 10, 20],
            "min_samples_split": [2, 5, 10],
        }
        base = ExtraTreesClassifier(
            random_state=self.random_state, class_weight="balanced"
        )
        search = _auto_search(
            base,
            param_grid,
            X_train,
            y_train,
            n_iter=n_iter,
            random_state=self.random_state,
        )
        self.n_estimators = search.best_params_["n_estimators"]
        self.max_depth = search.best_params_["max_depth"]
        self.min_samples_split = search.best_params_["min_samples_split"]
        logger.info(
            "%s best params: %s | best F1: %.4f",
            self.name,
            search.best_params_,
            search.best_score_,
        )
        return search.best_params_

    def feature_importance(
        self,
        feature_cols: list[str],
        top_n: int = 15,
    ) -> pd.DataFrame:
        imp = (
            pd.DataFrame(
                {
                    "feature": list(feature_cols),
                    "importance": np.asarray(self.model.feature_importances_).ravel(),
                }
            )
            .sort_values("importance", ascending=False)
            .head(top_n)
            .reset_index(drop=True)
        )
        logger.debug(
            "%s top-%d feature importance:\n%s", self.name, top_n, imp.to_string()
        )
        return imp


# ---------------------------------------------------------------------------
# AdaBoost subclass
# ---------------------------------------------------------------------------


class AdaBoostDenialModel(DenialModelBase):
    """AdaBoost denial-prediction model.

    Sequential ensemble of decision stumps weighted by classification difficulty.
    Sensitive to outliers; useful as a comparison point against deeper ensembles.
    GridSearchCV tuning.

    Attributes:
        n_estimators: Number of boosting rounds.
        learning_rate: Weight applied to each classifier at each boosting step.
    """

    def __init__(self) -> None:
        super().__init__()
        self.name = "AdaBoost"
        self.n_estimators: int = cfg.ADA_BOOST_DEFAULTS["n_estimators"]
        self.learning_rate: float = cfg.ADA_BOOST_DEFAULTS["learning_rate"]
        self.random_state: int = cfg.RANDOM_SEED

    def train(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
    ) -> AdaBoostDenialModel:
        logger.info(
            "Training %s (n_est=%d, lr=%.3f)",
            self.name,
            self.n_estimators,
            self.learning_rate,
        )
        self.model = AdaBoostClassifier(
            n_estimators=self.n_estimators,
            learning_rate=self.learning_rate,
            random_state=self.random_state,
        )
        self.model.fit(X_train, y_train)
        logger.info("%s trained", self.name)
        return self

    def tune(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
        n_iter: int = cfg.TUNE_N_ITER,
    ) -> dict[str, Any]:
        logger.info("Tuning %s (n_iter=%d)...", self.name, n_iter)
        param_grid = {
            "n_estimators": [50, 100, 200],
            "learning_rate": [0.01, 0.1, 0.5, 1.0],
        }
        base = AdaBoostClassifier(random_state=self.random_state)
        search = _auto_search(
            base,
            param_grid,
            X_train,
            y_train,
            n_iter=n_iter,
            random_state=self.random_state,
        )
        self.n_estimators = search.best_params_["n_estimators"]
        self.learning_rate = search.best_params_["learning_rate"]
        logger.info(
            "%s best params: %s | best F1: %.4f",
            self.name,
            search.best_params_,
            search.best_score_,
        )
        return search.best_params_

    def feature_importance(
        self,
        feature_cols: list[str],
        top_n: int = 15,
    ) -> pd.DataFrame:
        imp = (
            pd.DataFrame(
                {
                    "feature": list(feature_cols),
                    "importance": np.asarray(self.model.feature_importances_).ravel(),
                }
            )
            .sort_values("importance", ascending=False)
            .head(top_n)
            .reset_index(drop=True)
        )
        logger.debug(
            "%s top-%d feature importance:\n%s", self.name, top_n, imp.to_string()
        )
        return imp


# ---------------------------------------------------------------------------
# Decision Tree subclass
# ---------------------------------------------------------------------------


class DecisionTreeDenialModel(DenialModelBase):
    """Single decision tree denial-prediction model.

    Interpretable baseline; useful for rule extraction and explainability audits.
    class_weight='balanced'. GridSearchCV tuning over depth, split threshold,
    and impurity criterion.

    Attributes:
        max_depth: Maximum tree depth (None = unlimited, prone to overfit).
        min_samples_split: Minimum samples required to split an internal node.
        criterion: Impurity measure — ``'gini'`` or ``'entropy'``.
    """

    def __init__(self) -> None:
        super().__init__()
        self.name = "Decision Tree"
        self.max_depth: int | None = cfg.DECISION_TREE_DEFAULTS["max_depth"]
        self.min_samples_split: int = cfg.DECISION_TREE_DEFAULTS["min_samples_split"]
        self.criterion: str = cfg.DECISION_TREE_DEFAULTS["criterion"]
        self.random_state: int = cfg.RANDOM_SEED

    def train(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
    ) -> DecisionTreeDenialModel:
        logger.info(
            "Training %s (depth=%s, criterion=%s)",
            self.name,
            self.max_depth,
            self.criterion,
        )
        self.model = DecisionTreeClassifier(
            max_depth=self.max_depth,
            min_samples_split=self.min_samples_split,
            criterion=self.criterion,
            random_state=self.random_state,
            class_weight="balanced",
        )
        self.model.fit(X_train, y_train)
        logger.info("%s trained", self.name)
        return self

    def tune(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
        n_iter: int = cfg.TUNE_N_ITER,
    ) -> dict[str, Any]:
        logger.info("Tuning %s (n_iter=%d)...", self.name, n_iter)
        param_grid = {
            "max_depth": [3, 5, 7, 10, None],
            "min_samples_split": [2, 5, 10, 20],
            "criterion": ["gini", "entropy"],
        }
        base = DecisionTreeClassifier(
            random_state=self.random_state, class_weight="balanced"
        )
        search = _auto_search(
            base,
            param_grid,
            X_train,
            y_train,
            n_iter=n_iter,
            random_state=self.random_state,
        )
        self.max_depth = search.best_params_["max_depth"]
        self.min_samples_split = search.best_params_["min_samples_split"]
        self.criterion = search.best_params_["criterion"]
        logger.info(
            "%s best params: %s | best F1: %.4f",
            self.name,
            search.best_params_,
            search.best_score_,
        )
        return search.best_params_

    def feature_importance(
        self,
        feature_cols: list[str],
        top_n: int = 15,
    ) -> pd.DataFrame:
        imp = (
            pd.DataFrame(
                {
                    "feature": list(feature_cols),
                    "importance": np.asarray(self.model.feature_importances_).ravel(),
                }
            )
            .sort_values("importance", ascending=False)
            .head(top_n)
            .reset_index(drop=True)
        )
        logger.debug(
            "%s top-%d feature importance:\n%s", self.name, top_n, imp.to_string()
        )
        return imp


# ---------------------------------------------------------------------------
# SVM subclass
# ---------------------------------------------------------------------------


class SVMDenialModel(DenialModelBase):
    """Support Vector Machine denial-prediction model (SVC with probability estimates).

    Requires feature scaling — ``StandardScaler`` is fitted in :meth:`train` and
    applied inside each CV fold via a ``Pipeline``, mirroring the pattern used by
    :class:`LogisticRegressionDenialModel`.

    Overrides :meth:`predict` and :meth:`_get_cv_estimator` for consistent scaling.
    RandomizedSearchCV tuning over C, kernel, and gamma.

    Attributes:
        C: Regularisation parameter (smaller = stronger regularisation).
        kernel: Kernel function — ``'rbf'``, ``'linear'``, etc.
        gamma: Kernel coefficient; ``'scale'`` = 1 / (n_features × X.var()).
        scaler: ``StandardScaler`` fitted during :meth:`train`.
    """

    def __init__(self) -> None:
        super().__init__()
        self.name = "SVM"
        self.C: float = cfg.SVM_DEFAULTS["C"]
        self.kernel: str = cfg.SVM_DEFAULTS["kernel"]
        self.gamma: str = cfg.SVM_DEFAULTS["gamma"]
        self.random_state: int = cfg.RANDOM_SEED
        self.scaler: StandardScaler | None = None

    def train(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
    ) -> SVMDenialModel:
        logger.info("Training %s (C=%.3f, kernel=%s)", self.name, self.C, self.kernel)
        self.scaler = StandardScaler()
        X_scaled = self.scaler.fit_transform(X_train)
        self.model = SVC(
            C=self.C,
            kernel=self.kernel,
            gamma=self.gamma,
            probability=True,
            random_state=self.random_state,
            class_weight="balanced",
        )
        self.model.fit(X_scaled, y_train)
        logger.info("%s trained", self.name)
        return self

    def predict(
        self,
        X: pd.DataFrame,
    ) -> tuple[np.ndarray, np.ndarray]:
        X_scaled = self.scaler.transform(X)
        return self.model.predict(X_scaled), self.model.predict_proba(X_scaled)[:, 1]

    def _get_cv_estimator(self) -> Pipeline:
        return Pipeline(
            [
                ("scaler", StandardScaler()),
                (
                    "svm",
                    SVC(
                        C=self.C,
                        kernel=self.kernel,
                        gamma=self.gamma,
                        probability=True,
                        random_state=self.random_state,
                        class_weight="balanced",
                    ),
                ),
            ]
        )

    def tune(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
        n_iter: int = cfg.SVM_N_ITER,
    ) -> dict[str, Any]:
        logger.info(
            "Tuning %s with Pipeline — scaler inside each fold (n_iter=%d)...",
            self.name,
            n_iter,
        )
        pipe = Pipeline(
            [
                ("scaler", StandardScaler()),
                (
                    "svm",
                    SVC(
                        probability=True,
                        random_state=self.random_state,
                        class_weight="balanced",
                    ),
                ),
            ]
        )
        param_grid = {
            "svm__C": [0.1, 1.0, 10.0, 100.0],
            "svm__kernel": ["linear", "rbf"],
            "svm__gamma": ["scale", "auto"],
        }
        search = _auto_search(
            pipe,
            param_grid,
            X_train,
            y_train,
            n_iter=n_iter,
            random_state=self.random_state,
        )
        self.C = search.best_params_["svm__C"]
        self.kernel = search.best_params_["svm__kernel"]
        self.gamma = search.best_params_["svm__gamma"]
        logger.info(
            "%s best params: %s | best F1: %.4f",
            self.name,
            search.best_params_,
            search.best_score_,
        )
        return search.best_params_


# ---------------------------------------------------------------------------
# KNN subclass
# ---------------------------------------------------------------------------


class KNearestNeighborsDenialModel(DenialModelBase):
    """K-Nearest Neighbors denial-prediction model.

    Distance-based; requires feature scaling for meaningful distances.
    ``StandardScaler`` is fitted in :meth:`train` and applied inside each CV
    fold via a ``Pipeline``, mirroring :class:`LogisticRegressionDenialModel`.

    Overrides :meth:`predict` and :meth:`_get_cv_estimator`.
    GridSearchCV tuning over k, weighting scheme, and distance metric.

    Attributes:
        n_neighbors: Number of nearest neighbours to consider.
        weights: ``'uniform'`` (equal vote) or ``'distance'`` (inverse-distance).
        metric: Distance function — ``'minkowski'`` (p=2 == Euclidean), etc.
        scaler: ``StandardScaler`` fitted during :meth:`train`.
    """

    def __init__(self) -> None:
        super().__init__()
        self.name = "KNN"
        self.n_neighbors: int = cfg.KNN_DEFAULTS["n_neighbors"]
        self.weights: str = cfg.KNN_DEFAULTS["weights"]
        self.metric: str = cfg.KNN_DEFAULTS["metric"]
        self.scaler: StandardScaler | None = None

    def train(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
    ) -> KNearestNeighborsDenialModel:
        logger.info(
            "Training %s (k=%d, weights=%s, metric=%s)",
            self.name,
            self.n_neighbors,
            self.weights,
            self.metric,
        )
        self.scaler = StandardScaler()
        X_scaled = self.scaler.fit_transform(X_train)
        self.model = KNeighborsClassifier(
            n_neighbors=self.n_neighbors,
            weights=self.weights,
            metric=self.metric,
        )
        self.model.fit(X_scaled, y_train)
        logger.info("%s trained", self.name)
        return self

    def predict(
        self,
        X: pd.DataFrame,
    ) -> tuple[np.ndarray, np.ndarray]:
        X_scaled = self.scaler.transform(X)
        return self.model.predict(X_scaled), self.model.predict_proba(X_scaled)[:, 1]

    def _get_cv_estimator(self) -> Pipeline:
        return Pipeline(
            [
                ("scaler", StandardScaler()),
                (
                    "knn",
                    KNeighborsClassifier(
                        n_neighbors=self.n_neighbors,
                        weights=self.weights,
                        metric=self.metric,
                    ),
                ),
            ]
        )

    def tune(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
        n_iter: int = cfg.TUNE_N_ITER,
    ) -> dict[str, Any]:
        logger.info(
            "Tuning %s with Pipeline — scaler inside each fold (n_iter=%d)...",
            self.name,
            n_iter,
        )
        pipe = Pipeline(
            [
                ("scaler", StandardScaler()),
                ("knn", KNeighborsClassifier()),
            ]
        )
        param_grid = {
            "knn__n_neighbors": [3, 5, 7, 11, 15],
            "knn__weights": ["uniform", "distance"],
            "knn__metric": ["minkowski", "euclidean", "manhattan"],
        }
        search = _auto_search(
            pipe,
            param_grid,
            X_train,
            y_train,
            n_iter=n_iter,
            random_state=self.random_state,
        )
        self.n_neighbors = search.best_params_["knn__n_neighbors"]
        self.weights = search.best_params_["knn__weights"]
        self.metric = search.best_params_["knn__metric"]
        logger.info(
            "%s best params: %s | best F1: %.4f",
            self.name,
            search.best_params_,
            search.best_score_,
        )
        return search.best_params_


# ---------------------------------------------------------------------------
# Naive Bayes subclass
# ---------------------------------------------------------------------------


class NaiveBayesDenialModel(DenialModelBase):
    """Gaussian Naive Bayes denial-prediction model.

    Probabilistic baseline that assumes feature independence per class.
    Very fast to train; useful as a lower-bound comparison point.
    No scaling required. GridSearchCV tuning over var_smoothing.

    Attributes:
        var_smoothing: Portion of the largest variance added to all variances
            for numerical stability (acts as a regulariser).
    """

    def __init__(self) -> None:
        super().__init__()
        self.name = "Naive Bayes"
        self.var_smoothing: float = cfg.NAIVE_BAYES_DEFAULTS["var_smoothing"]

    def train(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
    ) -> NaiveBayesDenialModel:
        logger.info("Training %s (var_smoothing=%.2e)", self.name, self.var_smoothing)
        self.model = GaussianNB(var_smoothing=self.var_smoothing)
        self.model.fit(X_train, y_train)
        logger.info("%s trained", self.name)
        return self

    def tune(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
        n_iter: int = cfg.TUNE_N_ITER,
    ) -> dict[str, Any]:
        logger.info("Tuning %s (n_iter=%d)...", self.name, n_iter)
        param_grid = {
            "var_smoothing": [1e-10, 1e-9, 1e-8, 1e-7, 1e-6],
        }
        base = GaussianNB()
        search = _auto_search(
            base,
            param_grid,
            X_train,
            y_train,
            n_iter=n_iter,
            random_state=self.random_state,
        )
        self.var_smoothing = search.best_params_["var_smoothing"]
        logger.info(
            "%s best params: %s | best F1: %.4f",
            self.name,
            search.best_params_,
            search.best_score_,
        )
        return search.best_params_


# ---------------------------------------------------------------------------
# CatBoost subclass
# ---------------------------------------------------------------------------


class CatBoostDenialModel(DenialModelBase):
    """CatBoost denial-prediction model.

    Gradient boosting on ordered (target) statistics; handles categorical
    features natively and applies symmetric trees for fast inference.
    auto_class_weights='Balanced' corrects for the denied/paid imbalance.
    verbose=0 suppresses per-iteration logging.

    Attributes:
        iterations: Number of boosting rounds.
        depth: Maximum tree depth.
        learning_rate: Shrinkage applied to each tree contribution.
        l2_leaf_reg: L2 regularisation coefficient on leaf weights.
    """

    def __init__(self) -> None:
        super().__init__()
        self.name = "CatBoost"
        self.iterations: int = cfg.CATBOOST_DEFAULTS["iterations"]
        self.depth: int = cfg.CATBOOST_DEFAULTS["depth"]
        self.learning_rate: float = cfg.CATBOOST_DEFAULTS["learning_rate"]
        self.l2_leaf_reg: int = cfg.CATBOOST_DEFAULTS["l2_leaf_reg"]
        self.random_state: int = cfg.RANDOM_SEED

    def train(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
    ) -> CatBoostDenialModel:
        logger.info(
            "Training %s (iter=%d, depth=%d, lr=%.3f, l2=%.0f)",
            self.name,
            self.iterations,
            self.depth,
            self.learning_rate,
            self.l2_leaf_reg,
        )
        self.model = CatBoostClassifier(
            iterations=self.iterations,
            depth=self.depth,
            learning_rate=self.learning_rate,
            l2_leaf_reg=self.l2_leaf_reg,
            random_seed=self.random_state,
            auto_class_weights="Balanced",
            verbose=0,
        )
        self.model.fit(X_train, y_train)
        logger.info("%s trained", self.name)
        return self

    def tune(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
        n_iter: int = cfg.CATBOOST_N_ITER,
    ) -> dict[str, Any]:
        logger.info("Tuning %s (n_iter=%d)...", self.name, n_iter)
        param_grid = {
            "iterations": [50, 100],
            "depth": [4, 6],
            "learning_rate": [0.05, 0.1],
            "l2_leaf_reg": [1, 3],
        }
        base = CatBoostClassifier(
            random_seed=self.random_state, auto_class_weights="Balanced", verbose=0
        )
        search = _auto_search(
            base,
            param_grid,
            X_train,
            y_train,
            n_iter=n_iter,
            random_state=self.random_state,
        )
        self.iterations = search.best_params_["iterations"]
        self.depth = search.best_params_["depth"]
        self.learning_rate = search.best_params_["learning_rate"]
        self.l2_leaf_reg = search.best_params_["l2_leaf_reg"]
        logger.info(
            "%s best params: %s | best F1: %.4f",
            self.name,
            search.best_params_,
            search.best_score_,
        )
        return search.best_params_

    def feature_importance(
        self,
        feature_cols: list[str],
        top_n: int = 15,
    ) -> pd.DataFrame:
        imp = (
            pd.DataFrame(
                {
                    "feature": feature_cols,
                    "importance": np.asarray(self.model.feature_importances_).ravel(),
                }
            )
            .sort_values("importance", ascending=False)
            .head(top_n)
            .reset_index(drop=True)
        )
        logger.debug(
            "%s top-%d feature importance:\n%s", self.name, top_n, imp.to_string()
        )
        return imp


# ---------------------------------------------------------------------------
# HistGradientBoosting subclass
# ---------------------------------------------------------------------------


class HistGradientBoostingDenialModel(DenialModelBase):
    """Histogram-based Gradient Boosting denial-prediction model.

    sklearn's native fast GBM implementation. Bins features into histograms
    before fitting, giving O(n_bins × n_features) split-finding instead of
    O(n_samples × n_features). Handles missing values natively.
    class_weight='balanced' addresses denied/paid imbalance.

    Attributes:
        max_iter: Number of boosting iterations.
        max_depth: Maximum depth of each tree (None = unlimited).
        learning_rate: Shrinkage per iteration.
        min_samples_leaf: Minimum samples per leaf node.
    """

    def __init__(self) -> None:
        super().__init__()
        self.name = "HistGradientBoosting"
        self.max_iter: int = cfg.HIST_GRADIENT_BOOSTING_DEFAULTS["max_iter"]
        self.max_depth: int | None = cfg.HIST_GRADIENT_BOOSTING_DEFAULTS["max_depth"]
        self.learning_rate: float = cfg.HIST_GRADIENT_BOOSTING_DEFAULTS["learning_rate"]
        self.min_samples_leaf: int = cfg.HIST_GRADIENT_BOOSTING_DEFAULTS[
            "min_samples_leaf"
        ]

    def train(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
    ) -> HistGradientBoostingDenialModel:
        logger.info(
            "Training %s (iter=%d, depth=%s, lr=%.3f)",
            self.name,
            self.max_iter,
            self.max_depth,
            self.learning_rate,
        )
        self.model = HistGradientBoostingClassifier(
            max_iter=self.max_iter,
            max_depth=self.max_depth,
            learning_rate=self.learning_rate,
            min_samples_leaf=self.min_samples_leaf,
            random_state=self.random_state,
            class_weight="balanced",
        )
        self.model.fit(X_train, y_train)
        logger.info("%s trained", self.name)
        return self

    def tune(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
        n_iter: int = cfg.HIST_GRADIENT_BOOSTING_N_ITER,
    ) -> dict[str, Any]:
        logger.info("Tuning %s (n_iter=%d)...", self.name, n_iter)
        param_grid = {
            "max_iter": [50, 100, 200, 300],
            "max_depth": [None, 3, 5, 7],
            "learning_rate": [0.01, 0.05, 0.1, 0.2],
            "min_samples_leaf": [10, 20, 30],
            "l2_regularization": [0.0, 0.1, 1.0],
        }
        base = HistGradientBoostingClassifier(
            random_state=self.random_state, class_weight="balanced"
        )
        search = _auto_search(
            base,
            param_grid,
            X_train,
            y_train,
            n_iter=n_iter,
            random_state=self.random_state,
        )
        self.max_iter = search.best_params_["max_iter"]
        self.max_depth = search.best_params_["max_depth"]
        self.learning_rate = search.best_params_["learning_rate"]
        self.min_samples_leaf = search.best_params_["min_samples_leaf"]
        logger.info(
            "%s best params: %s | best F1: %.4f",
            self.name,
            search.best_params_,
            search.best_score_,
        )
        return search.best_params_


# ---------------------------------------------------------------------------
# Bagging subclass
# ---------------------------------------------------------------------------


class BaggingDenialModel(DenialModelBase):
    """Bagging ensemble denial-prediction model.

    Trains multiple decision-tree classifiers on bootstrap samples of the
    training data (sampling both rows and features). Reduces variance relative
    to a single tree; complementary to boosting ensembles already in the pool.
    Imbalance handled by the NearMiss-resampled training set.

    Attributes:
        n_estimators: Number of base estimators in the ensemble.
        max_samples: Fraction of training samples drawn per estimator.
        max_features: Fraction of features drawn per estimator.
    """

    def __init__(self) -> None:
        super().__init__()
        self.name = "Bagging"
        self.n_estimators: int = cfg.BAGGING_DEFAULTS["n_estimators"]
        self.max_samples: float = cfg.BAGGING_DEFAULTS["max_samples"]
        self.max_features: float = cfg.BAGGING_DEFAULTS["max_features"]

    def train(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
    ) -> BaggingDenialModel:
        logger.info(
            "Training %s (n_est=%d, samples=%.1f, features=%.1f)",
            self.name,
            self.n_estimators,
            self.max_samples,
            self.max_features,
        )
        self.model = BaggingClassifier(
            n_estimators=self.n_estimators,
            max_samples=self.max_samples,
            max_features=self.max_features,
            random_state=self.random_state,
            n_jobs=-1,
        )
        self.model.fit(X_train, y_train)
        logger.info("%s trained", self.name)
        return self

    def tune(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
        n_iter: int = cfg.TUNE_N_ITER,
    ) -> dict[str, Any]:
        logger.info("Tuning %s (n_iter=%d)...", self.name, n_iter)
        param_grid = {
            "n_estimators": [10, 20, 50],
            "max_samples": [0.5, 0.8, 1.0],
            "max_features": [0.5, 0.8, 1.0],
        }
        base = BaggingClassifier(random_state=self.random_state, n_jobs=-1)
        search = _auto_search(
            base,
            param_grid,
            X_train,
            y_train,
            n_iter=n_iter,
            random_state=self.random_state,
        )
        self.n_estimators = search.best_params_["n_estimators"]
        self.max_samples = search.best_params_["max_samples"]
        self.max_features = search.best_params_["max_features"]
        logger.info(
            "%s best params: %s | best F1: %.4f",
            self.name,
            search.best_params_,
            search.best_score_,
        )
        return search.best_params_


# ---------------------------------------------------------------------------
# MLP subclass
# ---------------------------------------------------------------------------


class MLPDenialModel(DenialModelBase):
    """Multi-Layer Perceptron denial-prediction model (shallow neural network).

    Requires feature scaling — ``StandardScaler`` is fitted in :meth:`train`
    and applied inside each CV fold via a ``Pipeline``, mirroring the pattern
    used by :class:`LogisticRegressionDenialModel`.

    Overrides :meth:`predict` and :meth:`_get_cv_estimator` for consistent scaling.

    Attributes:
        hidden_layer_sizes: Tuple defining the number of neurons per hidden layer.
        activation: Activation function — ``'relu'`` or ``'tanh'``.
        alpha: L2 regularisation penalty on the weights.
        max_iter: Maximum number of optimisation iterations.
        scaler: ``StandardScaler`` fitted during :meth:`train`.
    """

    def __init__(self) -> None:
        super().__init__()
        self.name = "MLP"
        self.hidden_layer_sizes: tuple = cfg.MLP_DEFAULTS["hidden_layer_sizes"]
        self.activation: str = cfg.MLP_DEFAULTS["activation"]
        self.alpha: float = cfg.MLP_DEFAULTS["alpha"]
        self.max_iter: int = cfg.MLP_DEFAULTS["max_iter"]
        self.scaler: StandardScaler | None = None

    def train(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
    ) -> MLPDenialModel:
        logger.info(
            "Training %s (layers=%s, activation=%s, alpha=%.5f)",
            self.name,
            self.hidden_layer_sizes,
            self.activation,
            self.alpha,
        )
        self.scaler = StandardScaler()
        X_scaled = self.scaler.fit_transform(X_train)
        self.model = MLPClassifier(
            hidden_layer_sizes=self.hidden_layer_sizes,
            activation=self.activation,
            alpha=self.alpha,
            max_iter=self.max_iter,
            random_state=self.random_state,
        )
        self.model.fit(X_scaled, y_train)
        logger.info("%s trained", self.name)
        return self

    def predict(
        self,
        X: pd.DataFrame,
    ) -> tuple[np.ndarray, np.ndarray]:
        X_scaled = self.scaler.transform(X)
        return self.model.predict(X_scaled), self.model.predict_proba(X_scaled)[:, 1]

    def _get_cv_estimator(self) -> Pipeline:
        return Pipeline(
            [
                ("scaler", StandardScaler()),
                (
                    "mlp",
                    MLPClassifier(
                        hidden_layer_sizes=self.hidden_layer_sizes,
                        activation=self.activation,
                        alpha=self.alpha,
                        max_iter=self.max_iter,
                        random_state=self.random_state,
                    ),
                ),
            ]
        )

    def tune(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
        n_iter: int = cfg.MLP_N_ITER,
    ) -> dict[str, Any]:
        logger.info(
            "Tuning %s with Pipeline — scaler inside each fold (n_iter=%d)...",
            self.name,
            n_iter,
        )
        pipe = Pipeline(
            [
                ("scaler", StandardScaler()),
                (
                    "mlp",
                    MLPClassifier(
                        max_iter=self.max_iter, random_state=self.random_state
                    ),
                ),
            ]
        )
        param_grid = {
            "mlp__hidden_layer_sizes": [(50,), (100,), (100, 50), (100, 100), (200,)],
            "mlp__activation": ["relu", "tanh"],
            "mlp__alpha": [0.0001, 0.001, 0.01],
            "mlp__learning_rate_init": [0.001, 0.01],
        }
        search = _auto_search(
            pipe,
            param_grid,
            X_train,
            y_train,
            n_iter=n_iter,
            random_state=self.random_state,
        )
        self.hidden_layer_sizes = search.best_params_["mlp__hidden_layer_sizes"]
        self.activation = search.best_params_["mlp__activation"]
        self.alpha = search.best_params_["mlp__alpha"]
        logger.info(
            "%s best params: %s | best F1: %.4f",
            self.name,
            search.best_params_,
            search.best_score_,
        )
        return search.best_params_


# ---------------------------------------------------------------------------
# Linear Discriminant Analysis subclass
# ---------------------------------------------------------------------------


class LinearDiscriminantAnalysisDenialModel(DenialModelBase):
    """Linear Discriminant Analysis denial-prediction model.

    Finds a linear projection of features that maximises class separation.
    Assumes Gaussian class-conditional distributions with equal covariance.
    Useful as an interpretable probabilistic linear baseline and as a
    comparison point against Logistic Regression.

    Attributes:
        solver: Algorithm used — ``'lsqr'`` (regularised) or ``'eigen'``.
        shrinkage: Regularisation coefficient; ``'auto'`` applies Ledoit-Wolf.
    """

    def __init__(self) -> None:
        super().__init__()
        self.name = "LDA"
        self.solver: str = cfg.LDA_DEFAULTS["solver"]
        self.shrinkage: str | float | None = cfg.LDA_DEFAULTS["shrinkage"]

    def train(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
    ) -> LinearDiscriminantAnalysisDenialModel:
        logger.info(
            "Training %s (solver=%s, shrinkage=%s)",
            self.name,
            self.solver,
            self.shrinkage,
        )
        self.model = LinearDiscriminantAnalysis(
            solver=self.solver,
            shrinkage=self.shrinkage,
        )
        self.model.fit(X_train, y_train)
        logger.info("%s trained", self.name)
        return self

    def tune(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
        n_iter: int = cfg.TUNE_N_ITER,
    ) -> dict[str, Any]:
        logger.info("Tuning %s (n_iter=%d)...", self.name, n_iter)
        param_grid = {
            "solver": ["lsqr", "eigen"],
            "shrinkage": ["auto", 0.0, 0.1, 0.5, 1.0],
        }
        base = LinearDiscriminantAnalysis()
        search = _auto_search(
            base,
            param_grid,
            X_train,
            y_train,
            n_iter=n_iter,
            random_state=self.random_state,
        )
        self.solver = search.best_params_["solver"]
        self.shrinkage = search.best_params_["shrinkage"]
        logger.info(
            "%s best params: %s | best F1: %.4f",
            self.name,
            search.best_params_,
            search.best_score_,
        )
        return search.best_params_


# ---------------------------------------------------------------------------
# Quadratic Discriminant Analysis subclass
# ---------------------------------------------------------------------------


class QuadraticDiscriminantAnalysisDenialModel(DenialModelBase):
    """Quadratic Discriminant Analysis denial-prediction model.

    Extends LDA by allowing each class its own covariance matrix, enabling
    non-linear (quadratic) decision boundaries. More flexible than LDA at the
    cost of requiring more data per class to estimate per-class covariances.

    Attributes:
        reg_param: Regularisation parameter in [0, 1]; 0 = no regularisation.
    """

    def __init__(self) -> None:
        super().__init__()
        self.name = "QDA"
        self.reg_param: float = cfg.QDA_DEFAULTS["reg_param"]

    def train(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
    ) -> QuadraticDiscriminantAnalysisDenialModel:
        # QDA estimates a per-class covariance matrix; with collinear features and a
        # low reg_param this matrix is singular and sklearn raises LinAlgError
        # ("covariance matrix of class X is not full rank"). Retry with progressively
        # stronger regularisation so one numerically-hard model never kills the run.
        from numpy.linalg import LinAlgError

        candidate_regs = [self.reg_param] + [
            r for r in (0.1, 0.3, 0.5, 0.7, 1.0) if r > self.reg_param
        ]
        last_err: Exception | None = None
        for reg in candidate_regs:
            try:
                logger.info("Training %s (reg_param=%.3f)", self.name, reg)
                model = QuadraticDiscriminantAnalysis(reg_param=reg)
                model.fit(X_train, y_train)
                self.reg_param = reg
                self.model = model
                logger.info("%s trained", self.name)
                return self
            except (LinAlgError, ValueError) as exc:
                last_err = exc
                logger.warning(
                    "%s failed at reg_param=%.3f (%s) — retrying with more regularisation",
                    self.name,
                    reg,
                    exc,
                )
        # Exhausted all candidates — re-raise the last error with context.
        raise RuntimeError(
            f"{self.name} could not fit even at reg_param=1.0. "
            f"Features are severely collinear. Last error: {last_err}"
        )

    def tune(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
        n_iter: int = cfg.TUNE_N_ITER,
    ) -> dict[str, Any]:
        logger.info("Tuning %s (n_iter=%d)...", self.name, n_iter)
        # Drop reg_param=0.0 from the grid — it fails on collinear features.
        param_grid = {
            "reg_param": [0.1, 0.3, 0.5, 0.7, 1.0],
            "tol": [1e-4, 1e-3],
        }
        base = QuadraticDiscriminantAnalysis()
        search = _auto_search(
            base,
            param_grid,
            X_train,
            y_train,
            n_iter=n_iter,
            random_state=self.random_state,
        )
        self.reg_param = search.best_params_["reg_param"]
        logger.info(
            "%s best params: %s | best F1: %.4f",
            self.name,
            search.best_params_,
            search.best_score_,
        )
        return search.best_params_


# ---------------------------------------------------------------------------
# SGD subclass
# ---------------------------------------------------------------------------


class SGDDenialModel(DenialModelBase):
    """Stochastic Gradient Descent denial-prediction model.

    Optimises a log-loss linear classifier using SGD updates — functionally
    equivalent to Logistic Regression but scalable to very large datasets.
    ``loss='log_loss'`` is required for ``predict_proba`` support.

    Requires feature scaling — ``StandardScaler`` is fitted in :meth:`train`
    and applied inside each CV fold via a ``Pipeline``.

    Overrides :meth:`predict` and :meth:`_get_cv_estimator`.

    Attributes:
        penalty: Regularisation type — ``'l2'``, ``'l1'``, or ``'elasticnet'``.
        alpha: Regularisation strength (higher = stronger).
        max_iter: Maximum number of training epochs.
        scaler: ``StandardScaler`` fitted during :meth:`train`.
    """

    def __init__(self) -> None:
        super().__init__()
        self.name = "SGD"
        self.penalty: str = cfg.SGD_DEFAULTS["penalty"]
        self.alpha: float = cfg.SGD_DEFAULTS["alpha"]
        self.max_iter: int = cfg.SGD_DEFAULTS["max_iter"]
        self.scaler: StandardScaler | None = None

    def train(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
    ) -> SGDDenialModel:
        logger.info(
            "Training %s (penalty=%s, alpha=%.5f)", self.name, self.penalty, self.alpha
        )
        self.scaler = StandardScaler()
        X_scaled = self.scaler.fit_transform(X_train)
        self.model = SGDClassifier(
            loss="log_loss",
            penalty=self.penalty,
            alpha=self.alpha,
            max_iter=self.max_iter,
            random_state=self.random_state,
            class_weight="balanced",
        )
        self.model.fit(X_scaled, y_train)
        logger.info("%s trained", self.name)
        return self

    def predict(
        self,
        X: pd.DataFrame,
    ) -> tuple[np.ndarray, np.ndarray]:
        X_scaled = self.scaler.transform(X)
        return self.model.predict(X_scaled), self.model.predict_proba(X_scaled)[:, 1]

    def _get_cv_estimator(self) -> Pipeline:
        return Pipeline(
            [
                ("scaler", StandardScaler()),
                (
                    "sgd",
                    SGDClassifier(
                        loss="log_loss",
                        penalty=self.penalty,
                        alpha=self.alpha,
                        max_iter=self.max_iter,
                        random_state=self.random_state,
                        class_weight="balanced",
                    ),
                ),
            ]
        )

    def tune(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
        n_iter: int = cfg.SGD_N_ITER,
    ) -> dict[str, Any]:
        logger.info(
            "Tuning %s with Pipeline — scaler inside each fold (n_iter=%d)...",
            self.name,
            n_iter,
        )
        pipe = Pipeline(
            [
                ("scaler", StandardScaler()),
                (
                    "sgd",
                    SGDClassifier(
                        loss="log_loss",
                        random_state=self.random_state,
                        class_weight="balanced",
                    ),
                ),
            ]
        )
        param_grid = {
            "sgd__alpha": [0.0001, 0.001, 0.01, 0.1],
            "sgd__penalty": ["l2", "l1", "elasticnet"],
            "sgd__max_iter": [500, 1000],
        }
        search = _auto_search(
            pipe,
            param_grid,
            X_train,
            y_train,
            n_iter=n_iter,
            random_state=self.random_state,
        )
        self.alpha = search.best_params_["sgd__alpha"]
        self.penalty = search.best_params_["sgd__penalty"]
        self.max_iter = search.best_params_["sgd__max_iter"]
        logger.info(
            "%s best params: %s | best F1: %.4f",
            self.name,
            search.best_params_,
            search.best_score_,
        )
        return search.best_params_


# ---------------------------------------------------------------------------
# Bernoulli Naive Bayes subclass
# ---------------------------------------------------------------------------


class BernoulliNBDenialModel(DenialModelBase):
    """Bernoulli Naive Bayes denial-prediction model.

    Models each feature as a binary Bernoulli variable by thresholding at
    ``binarize``. Suitable when features represent presence/absence of
    clinical indicators or code flags. Fast to train; interpretable.

    Attributes:
        alpha: Laplace smoothing parameter.
        binarize: Threshold for binarising continuous features; ``0.0`` treats
            positive values as present.
    """

    def __init__(self) -> None:
        super().__init__()
        self.name = "Bernoulli NB"
        self.alpha: float = cfg.BERNOULLI_NB_DEFAULTS["alpha"]
        self.binarize: float = cfg.BERNOULLI_NB_DEFAULTS["binarize"]

    def train(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
    ) -> BernoulliNBDenialModel:
        logger.info(
            "Training %s (alpha=%.3f, binarize=%.3f)",
            self.name,
            self.alpha,
            self.binarize,
        )
        self.model = BernoulliNB(alpha=self.alpha, binarize=self.binarize)
        self.model.fit(X_train, y_train)
        logger.info("%s trained", self.name)
        return self

    def tune(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
        n_iter: int = cfg.TUNE_N_ITER,
    ) -> dict[str, Any]:
        logger.info("Tuning %s (n_iter=%d)...", self.name, n_iter)
        param_grid = {
            "alpha": [0.1, 0.5, 1.0, 2.0],
            "binarize": [0.0, 0.1, 0.5],
        }
        base = BernoulliNB()
        search = _auto_search(
            base,
            param_grid,
            X_train,
            y_train,
            n_iter=n_iter,
            random_state=self.random_state,
        )
        self.alpha = search.best_params_["alpha"]
        self.binarize = search.best_params_["binarize"]
        logger.info(
            "%s best params: %s | best F1: %.4f",
            self.name,
            search.best_params_,
            search.best_score_,
        )
        return search.best_params_


# ---------------------------------------------------------------------------
# Complement Naive Bayes subclass
# ---------------------------------------------------------------------------


class ComplementNBDenialModel(DenialModelBase):
    """Complement Naive Bayes denial-prediction model.

    Estimates class probabilities from the complement class, which is more
    robust to imbalanced class distributions than standard Multinomial NB.
    Requires non-negative feature values — features are clipped to [0, ∞) in
    both training and inference.

    Overrides :meth:`predict` and :meth:`_get_cv_estimator` to apply clipping.

    Attributes:
        alpha: Laplace smoothing parameter.
        norm: Whether to normalise the weights.
    """

    def __init__(self) -> None:
        super().__init__()
        self.name = "Complement NB"
        self.alpha: float = cfg.COMPLEMENT_NB_DEFAULTS["alpha"]
        self.norm: bool = False

    def train(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
    ) -> ComplementNBDenialModel:
        logger.info(
            "Training %s (alpha=%.3f, norm=%s)", self.name, self.alpha, self.norm
        )
        X_clip = np.clip(X_train.values, 0, None)
        self.model = ComplementNB(alpha=self.alpha, norm=self.norm)
        self.model.fit(X_clip, y_train)
        logger.info("%s trained", self.name)
        return self

    def predict(
        self,
        X: pd.DataFrame,
    ) -> tuple[np.ndarray, np.ndarray]:
        X_clip = np.clip(X.values, 0, None)
        return self.model.predict(X_clip), self.model.predict_proba(X_clip)[:, 1]

    def _get_cv_estimator(self) -> Pipeline:
        return Pipeline(
            [
                ("clip", FunctionTransformer(func=_nonneg_clip)),
                ("cnb", ComplementNB(alpha=self.alpha, norm=self.norm)),
            ]
        )

    def tune(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
        n_iter: int = cfg.TUNE_N_ITER,
    ) -> dict[str, Any]:
        logger.info("Tuning %s (n_iter=%d)...", self.name, n_iter)
        pipe = Pipeline(
            [
                ("clip", FunctionTransformer(func=_nonneg_clip)),
                ("cnb", ComplementNB()),
            ]
        )
        param_grid = {
            "cnb__alpha": [0.1, 0.5, 1.0, 2.0, 5.0],
            "cnb__norm": [False, True],
        }
        search = _auto_search(
            pipe,
            param_grid,
            X_train,
            y_train,
            n_iter=n_iter,
            random_state=self.random_state,
        )
        self.alpha = search.best_params_["cnb__alpha"]
        self.norm = search.best_params_["cnb__norm"]
        logger.info(
            "%s best params: %s | best F1: %.4f",
            self.name,
            search.best_params_,
            search.best_score_,
        )
        return search.best_params_


# ===========================================================================
# ENSEMBLE MODELS — Boosting, Soft Voting, Hard Voting, Stacking
# ===========================================================================
#
# These combine several base learners into a single stronger model. They inherit
# the full DenialModelBase interface (predict, evaluate, calibrate, catch-rate
# eligibility, explainability) so they flow through the exact same business gate
# and champion-selection logic as the individual models — no special-casing.
#
# Base-learner construction is centralised in _build_base_estimators() so every
# ensemble draws from a consistent, scaled-where-needed set of estimators.
# ---------------------------------------------------------------------------


def _build_base_estimators(members: list[str]) -> list[tuple[str, Any]]:
    """Construct ``(name, estimator)`` tuples for ensemble members.

    Each member is a plain sklearn estimator configured with the project's
    default hyperparameters. Estimators that need feature scaling (none of the
    tree/boosting members do) would be wrapped in a Pipeline here; the current
    members are all scale-invariant tree/boosting learners plus Logistic
    Regression, which is wrapped in a scaling Pipeline for correctness.

    Args:
        members: List of member keys drawn from the recognised base-learner set.

    Returns:
        List of ``(name, estimator)`` tuples ready for VotingClassifier /
        StackingClassifier.

    Raises:
        ValueError: When a member key is not recognised.
    """
    factory: dict[str, Any] = {
        "XGBoost": lambda: XGBClassifier(
            n_estimators=cfg.XGBOOST_DEFAULTS["n_estimators"],
            max_depth=cfg.XGBOOST_DEFAULTS["max_depth"],
            learning_rate=cfg.XGBOOST_DEFAULTS["learning_rate"],
            subsample=cfg.XGBOOST_DEFAULTS["subsample"],
            colsample_bytree=cfg.XGBOOST_DEFAULTS["colsample_bytree"],
            random_state=cfg.RANDOM_SEED,
            eval_metric="logloss",
            n_jobs=-1,
        ),
        "LightGBM": lambda: LGBMClassifier(
            n_estimators=cfg.LIGHTGBM_DEFAULTS["n_estimators"],
            num_leaves=cfg.LIGHTGBM_DEFAULTS["num_leaves"],
            learning_rate=cfg.LIGHTGBM_DEFAULTS["learning_rate"],
            random_state=cfg.RANDOM_SEED,
            class_weight="balanced",
            verbose=-1,
            n_jobs=-1,
        ),
        "Random Forest": lambda: RandomForestClassifier(
            n_estimators=cfg.RANDOM_FOREST_DEFAULTS["n_estimators"],
            max_depth=cfg.RANDOM_FOREST_DEFAULTS["max_depth"],
            min_samples_split=cfg.RANDOM_FOREST_DEFAULTS["min_samples_split"],
            random_state=cfg.RANDOM_SEED,
            class_weight="balanced",
            n_jobs=-1,
        ),
        "Gradient Boosting": lambda: GradientBoostingClassifier(
            random_state=cfg.RANDOM_SEED,
        ),
        "AdaBoost": lambda: AdaBoostClassifier(
            random_state=cfg.RANDOM_SEED,
        ),
        "CatBoost": lambda: CatBoostClassifier(
            iterations=cfg.CATBOOST_DEFAULTS.get("iterations", 200),
            depth=cfg.CATBOOST_DEFAULTS.get("depth", 6),
            learning_rate=cfg.CATBOOST_DEFAULTS.get("learning_rate", 0.1),
            random_state=cfg.RANDOM_SEED,
            verbose=0,
        ),
        "Extra Trees": lambda: ExtraTreesClassifier(
            n_estimators=cfg.EXTRA_TREES_DEFAULTS.get("n_estimators", 100),
            random_state=cfg.RANDOM_SEED,
            class_weight="balanced",
        ),
        "HistGradientBoosting": lambda: HistGradientBoostingClassifier(
            random_state=cfg.RANDOM_SEED,
        ),
        "Logistic Regression": lambda: Pipeline(
            [
                ("scaler", StandardScaler()),
                (
                    "lr",
                    LogisticRegression(
                        C=cfg.LOGISTIC_REGRESSION_DEFAULTS["C"],
                        max_iter=cfg.LOGISTIC_REGRESSION_DEFAULTS["max_iter"],
                        solver=cfg.LOGISTIC_REGRESSION_DEFAULTS["solver"],
                        random_state=cfg.RANDOM_SEED,
                        class_weight="balanced",
                        n_jobs=-1,
                    ),
                ),
            ]
        ),
    }

    estimators: list[tuple[str, Any]] = []
    for m in members:
        if m not in factory:
            raise ValueError(
                f"Unknown ensemble member '{m}'. Recognised: {sorted(factory.keys())}"
            )
        # Short, safe estimator key (VotingClassifier requires valid identifiers).
        key = m.lower().replace(" ", "_")
        estimators.append((key, factory[m]()))
    return estimators


# ---------------------------------------------------------------------------
# Soft Voting ensemble
# ---------------------------------------------------------------------------


class VotingSoftDenialModel(DenialModelBase):
    """Soft-voting ensemble — averages predicted probabilities across members.

    Soft voting is generally more accurate than hard voting because it uses the
    *confidence* of each member, not just its final vote. All members must expose
    ``predict_proba`` (they do). ``predict_proba`` on the ensemble returns the
    averaged probability, so calibration, AUC, and the Youden-J threshold all work
    unchanged.

    Members default to :data:`config.VOTING_ENSEMBLE_MEMBERS`.

    Attributes:
        members: Base-learner names combined by the ensemble.
    """

    def __init__(self, members: list[str] | None = None) -> None:
        super().__init__()
        self.name = "Voting (Soft)"
        self.members: list[str] = members or list(cfg.VOTING_ENSEMBLE_MEMBERS)

    def train(self, X_train: pd.DataFrame, y_train: pd.Series) -> VotingSoftDenialModel:
        logger.info("Training %s (members=%s)", self.name, self.members)
        self.model = VotingClassifier(
            estimators=_build_base_estimators(self.members),
            voting="soft",
            n_jobs=-1,
        )
        self.model.fit(X_train, y_train)
        logger.info("%s trained", self.name)
        return self

    def tune(self, X_train: pd.DataFrame, y_train: pd.Series) -> dict[str, Any]:
        """Ensembles are not hyperparameter-tuned; members use project defaults.

        Returns an empty dict so the pipeline's ``if tune:`` loop is a no-op for
        this model without special-casing.
        """
        logger.info("%s uses fixed member defaults — no tuning performed", self.name)
        return {}


# ---------------------------------------------------------------------------
# Hard Voting ensemble
# ---------------------------------------------------------------------------


class VotingHardDenialModel(DenialModelBase):
    """Hard-voting ensemble — majority vote of member class predictions.

    Hard voting counts discrete votes rather than averaging probabilities.
    ``VotingClassifier(voting='hard')`` does not implement ``predict_proba``, so
    this class overrides :meth:`predict` to synthesise a pseudo-probability equal
    to the *fraction of members voting "denied"*. This keeps the ensemble fully
    compatible with catch-rate validation, AUC computation, calibration, and the
    Youden-J threshold, all of which expect a probability.

    Members default to :data:`config.VOTING_ENSEMBLE_MEMBERS`.

    Attributes:
        members: Base-learner names combined by the ensemble.
    """

    def __init__(self, members: list[str] | None = None) -> None:
        super().__init__()
        self.name = "Voting (Hard)"
        self.members: list[str] = members or list(cfg.VOTING_ENSEMBLE_MEMBERS)
        self._fitted_members: list[tuple[str, Any]] = []

    def train(self, X_train: pd.DataFrame, y_train: pd.Series) -> VotingHardDenialModel:
        logger.info("Training %s (members=%s)", self.name, self.members)
        self.model = VotingClassifier(
            estimators=_build_base_estimators(self.members),
            voting="hard",
            n_jobs=-1,
        )
        self.model.fit(X_train, y_train)
        # Keep references to fitted members for the pseudo-probability computation.
        self._fitted_members = list(
            zip([n for n, _ in self.model.estimators], self.model.estimators_)
        )
        logger.info("%s trained", self.name)
        return self

    def predict(self, X: pd.DataFrame) -> tuple[np.ndarray, np.ndarray]:
        """Return (labels, pseudo-probabilities) for the hard-voting ensemble.

        The pseudo-probability is the share of members predicting the denied class.
        With three members, possible values are 0, 1/3, 2/3, 1 — a coarse but
        monotonic confidence signal that AUC and thresholding can consume.

        Args:
            X: Feature DataFrame.

        Returns:
            Tuple of ``(class_labels, pseudo_probabilities)``.
        """
        labels = self.model.predict(X)
        # Fraction of members voting "denied" (class 1).
        member_preds = np.column_stack(
            [est.predict(X) for _, est in self._fitted_members]
        )
        pseudo_proba = member_preds.mean(axis=1)
        return labels, pseudo_proba

    def _get_cv_estimator(self) -> Any:
        """Use a soft-voting clone for CV scoring.

        ``cross_val_score`` with F1 uses ``predict`` only, which hard voting
        supports; returning the hard-voting model directly is correct and avoids
        probability requirements during CV.
        """
        return VotingClassifier(
            estimators=_build_base_estimators(self.members),
            voting="hard",
            n_jobs=-1,
        )

    def calibrate(self, *args: Any, **kwargs: Any) -> Any:
        """Hard voting cannot be probability-calibrated (no continuous scores).

        Overrides the base calibrate to skip calibration and instead derive the
        Youden-J threshold directly from the pseudo-probabilities. Sets
        ``self.calibrated_model = None`` so :func:`save_pipeline_artifacts` falls
        back to saving the raw ensemble.
        """
        X_test = kwargs.get("X_test")
        y_test = kwargs.get("y_test")
        if X_test is None and len(args) >= 3:
            X_test = args[2]
        if y_test is None and len(args) >= 4:
            y_test = args[3]

        self.calibrated_model = None
        logger.info("%s — hard voting: calibration skipped (discrete votes)", self.name)

        if X_test is not None and y_test is not None:
            _, pseudo = self.predict(X_test)
            fpr, tpr, thr = roc_curve(y_test, pseudo)
            fpr, tpr, thr = fpr[1:], tpr[1:], thr[1:]
            j = tpr - fpr
            opt_thr = float(thr[j.argmax()])
            if (
                opt_thr >= cfg.THRESHOLD_GUARD_UPPER
                or opt_thr <= cfg.THRESHOLD_GUARD_LOWER
            ):
                opt_thr = cfg.THRESHOLD_FALLBACK
            self.calibration_threshold = opt_thr
            logger.info(
                "%s Youden-J threshold (pseudo-proba): %.4f", self.name, opt_thr
            )
        return None

    def tune(self, X_train: pd.DataFrame, y_train: pd.Series) -> dict[str, Any]:
        """No tuning; members use project defaults."""
        logger.info("%s uses fixed member defaults — no tuning performed", self.name)
        return {}


# ---------------------------------------------------------------------------
# Stacking ensemble
# ---------------------------------------------------------------------------


class StackingDenialModel(DenialModelBase):
    """Stacking ensemble — a meta-learner trained on base-model predictions.

    Stacking trains several base learners, then feeds their out-of-fold predicted
    probabilities into a meta-learner (Logistic Regression) that learns how to best
    combine them. This typically outperforms any single member and both voting
    schemes because the meta-learner discovers *which member to trust when*.

    ``StackingClassifier`` exposes ``predict_proba`` (from the final estimator), so
    calibration, AUC, and the Youden-J threshold all work unchanged.

    Members default to :data:`config.STACKING_ENSEMBLE_MEMBERS`; the meta-learner is
    a balanced Logistic Regression.

    Attributes:
        members: Base-learner names.
        cv_folds: Internal CV folds used to generate out-of-fold meta-features.
        passthrough: When True, the meta-learner also sees the raw features.
    """

    def __init__(
        self,
        members: list[str] | None = None,
        cv_folds: int = cfg.STACKING_CV_FOLDS,
        passthrough: bool = cfg.STACKING_PASSTHROUGH,
    ) -> None:
        super().__init__()
        self.name = "Stacking"
        self.members: list[str] = members or list(cfg.STACKING_ENSEMBLE_MEMBERS)
        self.cv_folds = cv_folds
        self.passthrough = passthrough

    def _make_meta_learner(self) -> LogisticRegression:
        """Return the meta-learner (level-1) estimator."""
        return LogisticRegression(
            max_iter=1000, class_weight="balanced", random_state=cfg.RANDOM_SEED, n_jobs=-1
        )

    def train(self, X_train: pd.DataFrame, y_train: pd.Series) -> StackingDenialModel:
        logger.info(
            "Training %s (members=%s, meta=LogisticRegression, cv=%d, passthrough=%s)",
            self.name,
            self.members,
            self.cv_folds,
            self.passthrough,
        )
        self.model = StackingClassifier(
            estimators=_build_base_estimators(self.members),
            final_estimator=self._make_meta_learner(),
            cv=self.cv_folds,
            stack_method="predict_proba",
            passthrough=self.passthrough,
            n_jobs=-1,
        )
        self.model.fit(X_train, y_train)
        logger.info("%s trained", self.name)
        return self

    def _get_cv_estimator(self) -> Any:
        """Return a fresh stacking estimator for CV scoring."""
        return StackingClassifier(
            estimators=_build_base_estimators(self.members),
            final_estimator=self._make_meta_learner(),
            cv=self.cv_folds,
            stack_method="predict_proba",
            passthrough=self.passthrough,
            n_jobs=-1,
        )

    def meta_learner_weights(self, top_n: int = cfg.XAI_TOP_N_FEATURES) -> pd.DataFrame:
        """Return the meta-learner's coefficients — how much each base model is trusted.

        Explainability for stacking: the final Logistic Regression's coefficients
        show the relative weight assigned to each base model's probability output.

        Args:
            top_n: Maximum rows to return (defaults to all members).

        Returns:
            DataFrame with ``base_model`` and ``meta_weight`` columns.
        """
        final = self.model.final_estimator_
        member_names = [n for n, _ in self.model.estimators]
        coefs = np.ravel(final.coef_)[: len(member_names)]
        weights = (
            pd.DataFrame({"base_model": member_names, "meta_weight": coefs})
            .sort_values("meta_weight", key=np.abs, ascending=False)
            .head(top_n)
            .reset_index(drop=True)
        )
        logger.info("%s meta-learner weights:\n%s", self.name, weights.to_string())
        return weights

    def tune(self, X_train: pd.DataFrame, y_train: pd.Series) -> dict[str, Any]:
        """No tuning; base members and meta-learner use project defaults."""
        logger.info("%s uses fixed member defaults — no tuning performed", self.name)
        return {}


# ---------------------------------------------------------------------------
# Boosting Voting ensemble (soft vote across all boosting learners)
# ---------------------------------------------------------------------------


class BoostingEnsembleDenialModel(DenialModelBase):
    """Soft-voting ensemble composed exclusively of boosting learners.

    Combines the gradient/adaptive boosting family (XGBoost, LightGBM, Gradient
    Boosting, AdaBoost) via soft voting. Isolating the boosting family often yields
    a strong, low-variance ensemble because boosting members already correct their
    own errors sequentially.

    Members default to :data:`config.BOOSTING_ENSEMBLE_MEMBERS`.

    Attributes:
        members: Boosting base-learner names.
    """

    def __init__(self, members: list[str] | None = None) -> None:
        super().__init__()
        self.name = "Boosting Ensemble"
        self.members: list[str] = members or list(cfg.BOOSTING_ENSEMBLE_MEMBERS)

    def train(
        self, X_train: pd.DataFrame, y_train: pd.Series
    ) -> BoostingEnsembleDenialModel:
        logger.info("Training %s (members=%s)", self.name, self.members)
        self.model = VotingClassifier(
            estimators=_build_base_estimators(self.members),
            voting="soft",
            n_jobs=-1,
        )
        self.model.fit(X_train, y_train)
        logger.info("%s trained", self.name)
        return self

    def tune(self, X_train: pd.DataFrame, y_train: pd.Series) -> dict[str, Any]:
        """No tuning; members use project defaults."""
        logger.info("%s uses fixed member defaults — no tuning performed", self.name)
        return {}


# ===========================================================================
# DEEP LEARNING — FastAI Tabular
# ===========================================================================
#
# A neural-network tabular model that competes on the same footing as the
# classical ML models: it inherits DenialModelBase and implements the same
# train / predict / tune interface, so it flows through the identical
# catch-rate gate, leaderboard, and champion-selection logic.
#
# FastAI features integrated:
#   - LR Finder                 (lr_find) to pick a good base learning rate
#   - Learning Rate Scheduler   (fit_one_cycle — 1-cycle policy)
#   - Early Stopping            (EarlyStoppingCallback on valid loss)
#   - Best Model Saving         (SaveModelCallback restores best epoch)
#   - Evaluation                (predict returns labels + probabilities)
#
# fastai/torch are heavy optional dependencies. Import is deferred to train()
# so the rest of modelling.py works even when fastai is not installed; if a
# FastAITabularModel is trained without fastai present, a clear error is raised.
# ---------------------------------------------------------------------------


class FastAITabularModel(DenialModelBase):
    """FastAI tabular neural-network denial-prediction model.

    Wraps a fastai ``TabularLearner`` behind the DenialModelBase interface so it
    can be trained, evaluated, gated, and ranked exactly like the classical models.

    Integrated FastAI capabilities:
        - **LR Finder**: ``learn.lr_find()`` suggests a learning rate before training.
        - **LR Scheduler**: ``fit_one_cycle`` applies the 1-cycle schedule.
        - **Early Stopping**: stops when validation loss stops improving.
        - **Best Model Saving**: restores the best epoch's weights at the end.
        - **Evaluation**: ``predict`` returns ``(labels, probabilities)`` like all models.

    Because a fastai ``Learner`` is not sklearn-clonable, this class overrides
    :meth:`calibrate` (threshold from raw probabilities, no CalibratedClassifierCV)
    and :meth:`_get_cv_estimator` (skips sklearn CV; leaderboard CV is approximated
    from the validation split).

    Attributes:
        epochs: Maximum training epochs (early stopping may end sooner).
        batch_size: Mini-batch size.
        layers: Hidden layer sizes for the tabular MLP.
        base_lr: Learning rate; when None, the LR finder chooses one.
        patience: Early-stopping patience (epochs without improvement).
        use_lr_finder: Whether to run the LR finder before training.
    """

    def __init__(self) -> None:
        super().__init__()
        self.name = "FastAI Tabular"
        self.epochs: int = getattr(cfg, "FASTAI_EPOCHS", 20)
        self.batch_size: int = getattr(cfg, "FASTAI_BATCH_SIZE", 256)
        self.layers: list[int] = list(getattr(cfg, "FASTAI_LAYERS", [200, 100]))
        self.base_lr: float | None = getattr(cfg, "FASTAI_BASE_LR", None)
        self.patience: int = getattr(cfg, "FASTAI_PATIENCE", 3)
        self.use_lr_finder: bool = getattr(cfg, "FASTAI_USE_LR_FINDER", True)
        self.valid_size: float = getattr(cfg, "FASTAI_VALID_SIZE", 0.2)
        self._learn: Any = None  # fastai Learner
        self._feature_cols: list[str] = []
        self._suggested_lr: float | None = None

    def train(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
    ) -> FastAITabularModel:
        """Train the fastai TabularLearner with LR finder, 1-cycle, early stopping.

        Args:
            X_train: Training features.
            y_train: Training labels.

        Returns:
            Self, for method chaining.

        Raises:
            ImportError: When fastai / torch are not installed.
        """
        try:
            import torch  # noqa: F401
            from fastai.tabular.all import (
                Categorify,
                EarlyStoppingCallback,
                FillMissing,
                Normalize,
                SaveModelCallback,
                TabularPandas,
                accuracy,
                tabular_learner,
                slide,
                valley,
            )
            from fastai.data.transforms import RandomSplitter
        except ImportError as exc:  # pragma: no cover
            raise ImportError(
                "FastAITabularModel requires 'fastai' and 'torch'. "
                "Install with: pip install fastai torch"
            ) from exc

        self._feature_cols = list(X_train.columns)

        # Assemble a single frame; fastai handles its own validation split.
        df = X_train.copy()
        df["denial_flag"] = y_train.values

        # All engineered features are numeric here; treat them as continuous.
        cont_names = list(X_train.columns)
        cat_names: list[str] = []
        procs = [FillMissing, Categorify, Normalize]

        splits = RandomSplitter(valid_pct=self.valid_size, seed=self.random_state)(
            range(len(df))
        )
        to = TabularPandas(
            df,
            procs=procs,
            cat_names=cat_names,
            cont_names=cont_names,
            y_names="denial_flag",
            y_block=None,
            splits=splits,
        )
        dls = to.dataloaders(bs=self.batch_size)

        self._learn = tabular_learner(dls, layers=self.layers, metrics=accuracy)

        # 1. LR Finder — pick a learning rate when none is configured.
        if self.use_lr_finder and self.base_lr is None:
            try:
                suggestions = self._learn.lr_find(suggest_funcs=(valley, slide))
                self._suggested_lr = float(
                    getattr(suggestions, "valley", None) or suggestions[0]
                )
                logger.info(
                    "%s LR finder suggested lr=%.2e", self.name, self._suggested_lr
                )
            except Exception as exc:  # noqa: BLE001
                logger.warning("%s LR finder failed (%s); using 1e-2", self.name, exc)
                self._suggested_lr = 1e-2
        lr = self.base_lr or self._suggested_lr or 1e-2

        # 2. Callbacks: Early Stopping + Best Model Saving.
        cbs = [
            EarlyStoppingCallback(monitor="valid_loss", patience=self.patience),
            SaveModelCallback(monitor="valid_loss", fname="fastai_best"),
        ]

        # 3. LR Scheduler: 1-cycle policy.
        logger.info(
            "Training %s (epochs=%d, bs=%d, layers=%s, lr=%.2e, patience=%d)",
            self.name,
            self.epochs,
            self.batch_size,
            self.layers,
            lr,
            self.patience,
        )
        self._learn.fit_one_cycle(self.epochs, lr, cbs=cbs)

        # Expose a lightweight object as `self.model` so downstream `getattr(model)`
        # checks (e.g. explainer) don't crash; the real inference path is `predict`.
        self.model = self._learn
        logger.info("%s trained (best model restored by SaveModelCallback)", self.name)
        return self

    def predict(
        self,
        X: pd.DataFrame,
    ) -> tuple[np.ndarray, np.ndarray]:
        """Return (labels, denial probabilities) from the trained fastai learner.

        Args:
            X: Feature DataFrame aligned to the training columns.

        Returns:
            Tuple of ``(class_labels, probabilities)`` as numpy arrays.
        """
        if self._learn is None:
            raise RuntimeError("FastAITabularModel.predict called before train()")

        dl = self._learn.dls.test_dl(X[self._feature_cols].copy())
        preds, _ = self._learn.get_preds(dl=dl)
        proba = preds[:, 1].numpy()
        labels = (proba >= 0.5).astype(int)
        return labels, proba

    def calibrate(self, *args: Any, **kwargs: Any) -> Any:
        """Derive the Youden-J threshold from raw NN probabilities.

        A fastai Learner is not sklearn-clonable, so we skip
        ``CalibratedClassifierCV`` and set the decision threshold directly from the
        test-set ROC curve. ``calibrated_model`` stays ``None`` so
        :func:`save_pipeline_artifacts` persists the learner via its own saver.
        """
        X_test = kwargs.get("X_test")
        y_test = kwargs.get("y_test")
        if X_test is None and len(args) >= 3:
            X_test = args[2]
        if y_test is None and len(args) >= 4:
            y_test = args[3]

        self.calibrated_model = None
        if X_test is not None and y_test is not None:
            _, proba = self.predict(X_test)
            fpr, tpr, thr = roc_curve(y_test, proba)
            fpr, tpr, thr = fpr[1:], tpr[1:], thr[1:]
            j = tpr - fpr
            opt_thr = float(thr[j.argmax()])
            if (
                opt_thr >= cfg.THRESHOLD_GUARD_UPPER
                or opt_thr <= cfg.THRESHOLD_GUARD_LOWER
            ):
                opt_thr = cfg.THRESHOLD_FALLBACK
            self.calibration_threshold = opt_thr
            logger.info(
                "%s Youden-J threshold (raw NN proba): %.4f", self.name, opt_thr
            )
        return None

    def _get_cv_estimator(self) -> Any:
        """FastAI is not sklearn-CV compatible; leaderboard handles this gracefully."""
        return None

    def tune(
        self,
        X_train: pd.DataFrame,
        y_train: pd.Series,
    ) -> dict[str, Any]:
        """LR-finder-driven tuning is performed inside :meth:`train`.

        Returns the suggested learning rate (if the finder has run) for auditability.
        """
        logger.info("%s tuning is handled by the LR finder inside train()", self.name)
        return {"suggested_lr": self._suggested_lr}


# ===========================================================================
# EXPLAINABILITY — standalone, operates on ANY trained model
# ===========================================================================
#
# Explainability is intentionally NOT part of the model inheritance chain.
# The inheritance chain is: DenialModelBase -> all child models (individual +
# ensembles). Explainability is a separate concern handled by this standalone
# ModelExplainer, which takes any trained DenialModelBase instance and runs the
# XAI battery on it. This keeps models focused on train/predict/evaluate and
# keeps all interpretability logic in one place.
# ---------------------------------------------------------------------------


class ModelExplainer:
    """Model-agnostic explainability for any trained denial-prediction model.

    Operates on any object exposing the DenialModelBase interface — it reads
    ``model.model`` (fitted estimator), ``model.name``, an optional
    ``model.scaler``, and ``model.predict``. It is deliberately decoupled from the
    model inheritance hierarchy: construct it with a trained model and call the
    technique you need.

    Techniques (per the XAI field guide, in decreasing order of preference):

    1. **Native importance** — tree ``feature_importances_`` or linear ``|coef|``.
    2. **SHAP values** — game-theoretic attributions; TreeExplainer for tree models,
       agnostic explainer otherwise. Primary technique in the field guide.
    3. **Permutation importance** — model-agnostic global importance.
    4. **Per-prediction explanation** — top contributing features for one claim.

    All SHAP methods degrade gracefully: if ``shap`` is not installed they log a
    warning and return ``None`` rather than raising, so pipelines never break.

    Usage::

        explainer = ModelExplainer(champion)
        report = explainer.full_report(X_train, y_train, feature_cols)
        one    = explainer.explain_prediction(X_test.iloc[0], feature_cols)

    Args:
        model: A trained model instance (any ``DenialModelBase`` subclass).
    """

    def __init__(self, model: DenialModelBase) -> None:
        self.model_obj = model
        self.estimator = model.model
        self.name = getattr(model, "name", type(model).__name__)
        self.scaler = getattr(model, "scaler", None)

    # ------------------------------------------------------------------
    # Native importance
    # ------------------------------------------------------------------

    def native_importance(
        self,
        feature_cols: list[str],
        top_n: int = cfg.XAI_TOP_N_FEATURES,
    ) -> pd.DataFrame | None:
        """Return built-in feature importances or absolute linear coefficients.

        Args:
            feature_cols: Ordered feature names matching training columns.
            top_n: Number of top features to return.

        Returns:
            DataFrame with ``feature`` and ``importance`` columns, or ``None``
            when the estimator exposes neither importances nor coefficients
            (e.g. voting ensembles, KNN).
        """
        est = self.estimator
        if hasattr(est, "feature_importances_"):
            scores = est.feature_importances_
            kind = "feature_importances_"
        elif hasattr(est, "coef_"):
            scores = np.abs(np.ravel(est.coef_))
            kind = "|coef|"
        else:
            logger.info("%s exposes no native importances (opaque model)", self.name)
            return None

        imp = (
            pd.DataFrame(
                {
                    "feature": list(feature_cols),
                    "importance": np.asarray(scores).ravel(),
                }
            )
            .sort_values("importance", ascending=False)
            .head(top_n)
            .reset_index(drop=True)
        )
        logger.info("%s native importance (%s) top-%d computed", self.name, kind, top_n)
        return imp

    # ------------------------------------------------------------------
    # Permutation importance
    # ------------------------------------------------------------------

    def permutation_importance_report(
        self,
        X: pd.DataFrame,
        y: pd.Series,
        scoring: str = "f1",
        n_repeats: int = cfg.XAI_PERMUTATION_REPEATS,
        top_n: int = cfg.XAI_TOP_N_FEATURES,
        random_state: int = cfg.RANDOM_SEED,
    ) -> pd.DataFrame:
        """Compute model-agnostic permutation importance.

        Measures the average drop in ``scoring`` when each feature's values are
        randomly shuffled. Large drop = feature the model relies on heavily.

        For scaled models (``model.scaler`` set), a scaling Pipeline is rebuilt so
        the estimator sees data in the space it was trained on.

        Args:
            X: Feature DataFrame (unscaled).
            y: True labels.
            scoring: sklearn scoring string.
            n_repeats: Number of shuffles per feature.
            top_n: Number of top features to return.
            random_state: RNG seed for reproducibility.

        Returns:
            DataFrame with ``feature``, ``importance_mean``, ``importance_std``.
        """
        if self.scaler is not None:
            estimator = Pipeline(
                [("scaler", clone(self.scaler)), ("clf", clone(self.estimator))]
            )
            estimator.fit(X, y)
        else:
            estimator = self.estimator

        result = permutation_importance(
            estimator,
            X,
            y,
            scoring=scoring,
            n_repeats=n_repeats,
            random_state=random_state,
            n_jobs=-1,
        )
        # Ensure 1-D arrays — some sklearn versions return (n_features, 1)
        imp_mean = np.asarray(result.importances_mean).ravel()
        imp_std = np.asarray(result.importances_std).ravel()
        feat_names = (
            list(X.columns)
            if hasattr(X, "columns")
            else [f"f{i}" for i in range(len(imp_mean))]
        )
        imp = (
            pd.DataFrame(
                {
                    "feature": feat_names,
                    "importance_mean": imp_mean,
                    "importance_std": imp_std,
                }
            )
            .sort_values("importance_mean", ascending=False)
            .head(top_n)
            .reset_index(drop=True)
        )
        logger.info(
            "%s permutation importance (%s) top-%d computed", self.name, scoring, top_n
        )
        return imp

    # ------------------------------------------------------------------
    # SHAP — global
    # ------------------------------------------------------------------

    def shap_importance(
        self,
        X: pd.DataFrame,
        top_n: int = cfg.XAI_TOP_N_FEATURES,
        max_samples: int = cfg.XAI_SHAP_MAX_SAMPLES,
    ) -> pd.DataFrame | None:
        """Compute global SHAP importance (mean absolute SHAP value per feature).

        Uses ``shap.TreeExplainer`` for tree models (exact and fast) and
        ``shap.Explainer`` (auto-selects Kernel/Linear) otherwise. Input is capped
        at ``max_samples`` rows for tractable runtime.

        Args:
            X: Feature DataFrame (unscaled). Scaled internally for linear models.
            top_n: Number of top features to return.
            max_samples: Maximum rows fed to the explainer.

        Returns:
            DataFrame with ``feature`` and ``mean_abs_shap`` columns, or ``None``
            when ``shap`` is not installed or the explainer cannot be built.
        """
        try:
            import shap
        except ImportError:
            logger.warning(
                "%s SHAP skipped — 'shap' not installed. "
                "Install with: pip install shap",
                self.name,
            )
            return None

        X_sample = X.sample(min(len(X), max_samples), random_state=cfg.RANDOM_SEED)

        try:
            if hasattr(self.estimator, "feature_importances_"):
                explainer = shap.TreeExplainer(self.estimator)
                shap_values = explainer.shap_values(X_sample)
                if isinstance(shap_values, list):
                    shap_values = shap_values[1]
            else:
                if self.scaler is not None:
                    X_input = pd.DataFrame(
                        self.scaler.transform(X_sample), columns=X_sample.columns
                    )
                else:
                    X_input = X_sample
                bg = shap.sample(
                    X_input, min(len(X_input), 100), random_state=cfg.RANDOM_SEED
                )
                explainer = shap.Explainer(self.estimator.predict_proba, bg)
                sv = explainer(X_input)
                shap_values = sv.values[..., 1] if sv.values.ndim == 3 else sv.values
        except Exception as exc:  # noqa: BLE001 — XAI must never break the pipeline
            logger.warning("%s SHAP failed (%s); returning None", self.name, exc)
            return None

        # shap_values may be 3-D (n_samples, n_features, n_classes) for newer SHAP
        # on binary classifiers — take the positive class slice so it's 2-D.
        shap_values = np.asarray(shap_values)
        if shap_values.ndim == 3:
            shap_values = shap_values[..., 1]
        mean_abs = np.abs(shap_values).mean(axis=0)
        mean_abs = np.asarray(mean_abs).ravel()  # guarantee 1-D
        imp = (
            pd.DataFrame({"feature": list(X_sample.columns), "mean_abs_shap": mean_abs})
            .sort_values("mean_abs_shap", ascending=False)
            .head(top_n)
            .reset_index(drop=True)
        )
        logger.info(
            "%s SHAP global importance top-%d computed (n=%d)",
            self.name,
            top_n,
            len(X_sample),
        )
        return imp

    # ------------------------------------------------------------------
    # SHAP — single prediction
    # ------------------------------------------------------------------

    def explain_prediction(
        self,
        x_row: pd.Series,
        feature_cols: list[str],
        top_n: int = 5,
    ) -> pd.DataFrame | None:
        """Explain a single claim's prediction with per-feature SHAP contributions.

        Answers "why was *this* claim flagged?" by decomposing the model output
        into additive per-feature contributions for one row.

        Args:
            x_row: A single claim's feature ``pd.Series`` (unscaled).
            feature_cols: Ordered feature names.
            top_n: Number of top contributing features to return.

        Returns:
            DataFrame with ``feature``, ``value``, ``shap_contribution`` sorted by
            absolute contribution, or ``None`` when SHAP is unavailable.
        """
        try:
            import shap
        except ImportError:
            logger.warning(
                "%s per-prediction SHAP skipped — 'shap' not installed", self.name
            )
            return None

        X_one = pd.DataFrame([x_row[feature_cols].values], columns=feature_cols)
        try:
            if hasattr(self.estimator, "feature_importances_"):
                explainer = shap.TreeExplainer(self.estimator)
                vals = explainer.shap_values(X_one)
                if isinstance(vals, list):
                    vals = vals[1]
                vals = np.asarray(vals)
                # 3-D (1, n_features, n_classes) → positive class slice
                if vals.ndim == 3:
                    vals = vals[..., 1]
                contributions = np.ravel(vals)[: len(feature_cols)]
            else:
                if self.scaler is not None:
                    X_in = pd.DataFrame(
                        self.scaler.transform(X_one), columns=feature_cols
                    )
                else:
                    X_in = X_one
                explainer = shap.Explainer(self.estimator.predict_proba, X_in)
                sv = explainer(X_in)
                contributions = (
                    sv.values[0, :, 1] if sv.values.ndim == 3 else sv.values[0]
                )
        except Exception as exc:  # noqa: BLE001
            logger.warning("%s per-prediction SHAP failed (%s)", self.name, exc)
            return None

        out = (
            pd.DataFrame(
                {
                    "feature": feature_cols,
                    "value": x_row[feature_cols].values,
                    "shap_contribution": contributions,
                }
            )
            .assign(abs_c=lambda d: d["shap_contribution"].abs())
            .sort_values("abs_c", ascending=False)
            .drop(columns="abs_c")
            .head(top_n)
            .reset_index(drop=True)
        )
        return out

    # ------------------------------------------------------------------
    # Consolidated report
    # ------------------------------------------------------------------

    def full_report(
        self,
        X: pd.DataFrame,
        y: pd.Series,
        feature_cols: list[str],
        top_n: int = cfg.XAI_TOP_N_FEATURES,
    ) -> dict[str, Any]:
        """Run the full XAI battery and return a consolidated report dict.

        Combines native importance, SHAP global importance, permutation importance,
        partial dependence, and a business-friendly summary table into one structure
        suitable for logging or JSON export. When the wrapped model is a stacking
        ensemble, the meta-learner weights are added.

        Args:
            X: Feature DataFrame.
            y: Labels.
            feature_cols: Ordered feature names.
            top_n: Number of top features per technique.

        Returns:
            Dict keyed by technique name; each value is a list of records
            (empty list when a technique is unavailable for this model).
        """
        report: dict[str, Any] = {"model": self.name}

        native = self.native_importance(feature_cols, top_n=top_n)
        report["native_importance"] = (
            native.to_dict(orient="records") if native is not None else []
        )

        shap_imp = self.shap_importance(X, top_n=top_n)
        report["shap_importance"] = (
            shap_imp.to_dict(orient="records") if shap_imp is not None else []
        )

        perm = self.permutation_importance_report(X, y, top_n=top_n)
        report["permutation_importance"] = perm.to_dict(orient="records")

        # Partial dependence for the top features (how the prediction changes as a
        # single feature varies, holding others fixed).
        pdp = self.partial_dependence_report(X, y, feature_cols, top_n=min(top_n, 8))
        report["partial_dependence"] = pdp

        # Stacking-specific: how much the meta-learner trusts each base model.
        if isinstance(self.model_obj, StackingDenialModel):
            try:
                report["stacking_meta_weights"] = self.model_obj.meta_learner_weights(
                    top_n=top_n
                ).to_dict(orient="records")
            except Exception as exc:  # noqa: BLE001
                logger.warning("Could not extract stacking meta-weights: %s", exc)
                report["stacking_meta_weights"] = []

        # Business-friendly summary table (plain-language, ranked drivers).
        summary = self.business_summary_table(X, y, feature_cols, top_n=top_n)
        report["business_summary"] = summary.to_dict(orient="records")

        logger.info("%s explainability report assembled", self.name)
        return report

    # ------------------------------------------------------------------
    # Partial Dependence
    # ------------------------------------------------------------------

    def partial_dependence_report(
        self,
        X: pd.DataFrame,
        y: pd.Series,
        feature_cols: list[str],
        top_n: int = 8,
        grid_resolution: int = 20,
    ) -> list[dict[str, Any]]:
        """Compute partial dependence for the most important features.

        Partial dependence shows how the model's predicted denial probability
        changes as one feature varies across its range, averaging out all other
        features. It answers "as this feature goes up, does denial risk go up or
        down, and by how much?" — a global, direction-of-effect view.

        The features analysed are the top ``top_n`` by native importance (falling
        back to permutation importance when native is unavailable, e.g. voting
        ensembles).

        For scaled models, a scaling Pipeline is rebuilt so the estimator sees data
        in its training space.

        Args:
            X: Feature DataFrame (unscaled).
            y: Labels (used only to fit the scaling pipeline when needed).
            feature_cols: Ordered feature names.
            top_n: Number of top features to analyse.
            grid_resolution: Number of grid points per feature.

        Returns:
            List of dicts, one per feature: ``{feature, grid_values, avg_prediction}``.
            Empty list if partial dependence cannot be computed.
        """
        from sklearn.inspection import partial_dependence

        # Pick which features to analyse — prefer native importance, else permutation.
        native = self.native_importance(feature_cols, top_n=top_n)
        if native is not None and len(native) > 0:
            chosen = native["feature"].tolist()
        else:
            perm = self.permutation_importance_report(X, y, top_n=top_n)
            chosen = perm["feature"].tolist()

        # Build a fitted estimator that accepts the raw (unscaled) X.
        if self.scaler is not None:
            estimator = Pipeline(
                [("scaler", clone(self.scaler)), ("clf", clone(self.estimator))]
            )
            estimator.fit(X, y)
        else:
            estimator = self.estimator

        results: list[dict[str, Any]] = []
        for feat in chosen:
            try:
                pd_result = partial_dependence(
                    estimator,
                    X,
                    [feat],
                    grid_resolution=grid_resolution,
                    kind="average",
                )
                grid = pd_result["grid_values"][0]
                avg = pd_result["average"][0]
                results.append(
                    {
                        "feature": feat,
                        "grid_values": [round(float(v), 4) for v in grid],
                        "avg_prediction": [round(float(v), 4) for v in avg],
                        "effect_direction": (
                            "increases risk" if avg[-1] > avg[0] else "decreases risk"
                        ),
                    }
                )
            except Exception as exc:  # noqa: BLE001 — PDP must never break the report
                logger.warning("%s PDP failed for %s (%s)", self.name, feat, exc)
                continue

        logger.info(
            "%s partial dependence computed for %d features", self.name, len(results)
        )
        return results

    def plot_partial_dependence(
        self,
        X: pd.DataFrame,
        y: pd.Series,
        feature_cols: list[str],
        top_n: int = 6,
    ) -> Any:
        """Render a partial-dependence plot grid for the top features.

        Args:
            X: Feature DataFrame (unscaled).
            y: Labels.
            feature_cols: Ordered feature names.
            top_n: Number of top features to plot.

        Returns:
            The matplotlib Figure, or ``None`` when plotting fails.
        """
        import matplotlib.pyplot as plt
        from sklearn.inspection import PartialDependenceDisplay

        native = self.native_importance(feature_cols, top_n=top_n)
        if native is not None and len(native) > 0:
            chosen = native["feature"].tolist()
        else:
            perm = self.permutation_importance_report(X, y, top_n=top_n)
            chosen = perm["feature"].tolist()

        if self.scaler is not None:
            estimator = Pipeline(
                [("scaler", clone(self.scaler)), ("clf", clone(self.estimator))]
            )
            estimator.fit(X, y)
        else:
            estimator = self.estimator

        try:
            n = len(chosen)
            ncols = 3
            nrows = (n + ncols - 1) // ncols
            fig, axes = plt.subplots(nrows, ncols, figsize=(5 * ncols, 3.5 * nrows))
            PartialDependenceDisplay.from_estimator(
                estimator,
                X,
                chosen,
                ax=axes.ravel()[:n] if n > 1 else axes,
                kind="average",
                grid_resolution=20,
            )
            fig.suptitle(f"{self.name} — Partial Dependence (top {n} features)")
            fig.tight_layout()
            return fig
        except Exception as exc:  # noqa: BLE001
            logger.warning("%s PDP plot failed (%s)", self.name, exc)
            return None

    # ------------------------------------------------------------------
    # Business summary table
    # ------------------------------------------------------------------

    def business_summary_table(
        self,
        X: pd.DataFrame,
        y: pd.Series,
        feature_cols: list[str],
        top_n: int = cfg.XAI_TOP_N_FEATURES,
    ) -> pd.DataFrame:
        """Build a plain-language explainability summary for business users.

        Consolidates the technical XAI outputs into one ranked table a non-technical
        reviewer can read: which features drive denial predictions, how strong each
        driver is, and which direction it pushes risk. Combines SHAP (when available)
        and permutation importance for the strength score, and partial dependence for
        the direction of effect.

        Args:
            X: Feature DataFrame.
            y: Labels.
            feature_cols: Ordered feature names.
            top_n: Number of top drivers to include.

        Returns:
            DataFrame with columns: ``Rank``, ``Feature``, ``Importance Score``,
            ``Importance Method``, ``Effect on Denial Risk``, ``Plain-Language Read``.
        """
        # Strength: prefer SHAP, fall back to permutation importance.
        shap_imp = self.shap_importance(X, top_n=len(feature_cols))
        if shap_imp is not None and len(shap_imp) > 0:
            strength = shap_imp.rename(columns={"mean_abs_shap": "score"})[
                ["feature", "score"]
            ]
            method = "SHAP (mean |value|)"
        else:
            perm = self.permutation_importance_report(X, y, top_n=len(feature_cols))
            strength = perm.rename(columns={"importance_mean": "score"})[
                ["feature", "score"]
            ]
            method = "Permutation importance"

        strength = (
            strength.sort_values("score", ascending=False)
            .head(top_n)
            .reset_index(drop=True)
        )

        # Direction: from partial dependence.
        pdp = self.partial_dependence_report(X, y, feature_cols, top_n=top_n)
        direction_map = {p["feature"]: p["effect_direction"] for p in pdp}

        rows = []
        for i, r in strength.iterrows():
            feat = r["feature"]
            direction = direction_map.get(feat, "mixed / unclear")
            arrow = (
                "↑"
                if "increases" in direction
                else ("↓" if "decreases" in direction else "~")
            )
            plain = (
                f"Higher '{feat}' {direction} — this is a "
                f"{'strong' if i < 3 else 'moderate' if i < 8 else 'minor'} driver "
                f"of the model's denial decision."
            )
            rows.append(
                {
                    "Rank": i + 1,
                    "Feature": feat,
                    "Importance Score": round(float(r["score"]), 4),
                    "Importance Method": method,
                    "Effect on Denial Risk": f"{arrow} {direction}",
                    "Plain-Language Read": plain,
                }
            )

        summary = pd.DataFrame(rows)
        logger.info(
            "%s business summary table built (%d rows)", self.name, len(summary)
        )
        return summary


# ---------------------------------------------------------------------------
# Module-level pipeline helpers
# ---------------------------------------------------------------------------


def _auto_search(
    estimator: Any,
    param_grid: dict[str, list],
    X: pd.DataFrame,
    y: pd.Series,
    *,
    n_iter: int = cfg.TUNE_N_ITER,
    cv: int = cfg.CV_FOLDS,
    scoring: str = "f1",
    random_state: int = cfg.RANDOM_SEED,
    threshold: int = cfg.GRID_SEARCH_MAX_COMBINATIONS,
) -> Any:
    """Choose GridSearchCV or RandomizedSearchCV based on parameter search space size.

    Computes the total number of hyperparameter combinations (product of each
    list's length). If that count is at or below ``threshold`` the search is
    exhaustive (GridSearchCV); above it a randomised budget of ``n_iter``
    samples is used (RandomizedSearchCV).  ``n_iter`` is automatically capped
    at ``n_combinations`` so RandomizedSearchCV never requests more samples
    than exist in the grid.

    Both the chosen strategy and the combination count are logged at INFO level
    so tuning decisions are auditable without reading source code.

    Args:
        estimator: Unfitted sklearn-compatible estimator or Pipeline.
        param_grid: Dict mapping parameter names to candidate value lists.
        X: Training features.
        y: Training labels.
        n_iter: Random-search budget (ignored when GridSearchCV is chosen).
        cv: Number of cross-validation folds.
        scoring: Scoring metric for search.
        random_state: RNG seed for RandomizedSearchCV reproducibility.
        threshold: Combination count at or below which GridSearchCV is used.
            Set via ``cfg.GRID_SEARCH_MAX_COMBINATIONS`` (default 50).

    Returns:
        Fitted GridSearchCV or RandomizedSearchCV instance.
    """
    n_combinations = 1
    for v in param_grid.values():
        n_combinations *= len(v)

    if n_combinations <= threshold:
        logger.info(
            "Tuning strategy: GridSearchCV | combinations: %d (≤ threshold %d)",
            n_combinations,
            threshold,
        )
        search = GridSearchCV(
            estimator,
            param_grid,
            cv=cv,
            scoring=scoring,
            n_jobs=-1,
        )
    else:
        effective_n_iter = min(n_iter, n_combinations)
        logger.info(
            "Tuning strategy: RandomizedSearchCV(n_iter=%d) | combinations: %d (> threshold %d)",
            effective_n_iter,
            n_combinations,
            threshold,
        )
        search = RandomizedSearchCV(
            estimator,
            param_grid,
            n_iter=effective_n_iter,
            cv=cv,
            scoring=scoring,
            n_jobs=-1,
            random_state=random_state,
        )

    search.fit(X, y)
    return search


def compute_metrics(
    y_true: pd.Series,
    y_pred: np.ndarray,
    y_proba: np.ndarray,
) -> dict[str, float]:
    """Compute the standard denial-prediction evaluation metrics.

    Args:
        y_true: Ground-truth labels.
        y_pred: Predicted class labels.
        y_proba: Predicted denial probabilities.

    Returns:
        Dict with keys: ``accuracy``, ``precision``, ``recall``, ``f1``, ``auc``.
    """
    return {
        "accuracy": accuracy_score(y_true, y_pred),
        "precision": precision_score(y_true, y_pred, zero_division=0),
        "recall": recall_score(y_true, y_pred, zero_division=0),
        "f1": f1_score(y_true, y_pred, zero_division=0),
        "auc": roc_auc_score(y_true, y_proba) if len(np.unique(y_true)) > 1 else 0.0,
    }


def train_test_gap(
    models_list: list[DenialModelBase],
    X_train: pd.DataFrame,
    y_train: pd.Series,
    X_test: pd.DataFrame,
    y_test: pd.Series,
) -> pd.DataFrame:
    """Compute per-metric train-vs-test gap for every model.

    A large positive gap (Train − Test) indicates overfitting.

    Args:
        models_list: Trained model instances.
        X_train: Training features.
        y_train: Training labels.
        X_test: Test features.
        y_test: Test labels.

    Returns:
        Multi-index DataFrame indexed by ``(Model, Metric)`` with columns
        ``Train``, ``Test``, and ``Gap (Train-Test)``.
    """
    frames = []
    for m in models_list:
        ytr_pred, ytr_proba = m.predict(X_train)
        yte_pred, yte_proba = m.predict(X_test)
        df = pd.DataFrame(
            {
                "Train": compute_metrics(y_train, ytr_pred, ytr_proba),
                "Test": compute_metrics(y_test, yte_pred, yte_proba),
            }
        )
        df["Gap (Train-Test)"] = df["Train"] - df["Test"]
        df = df.round(4)
        df.index.name = "Metric"
        frames.append(pd.concat({m.name: df}, names=["Model"]))

    result = pd.concat(frames)
    logger.info("Train vs test gap:\n%s", result.to_string())
    return result


def validate_catch_rates(
    model_map: dict[str, DenialModelBase],
    X_test: pd.DataFrame,
    y_test: pd.Series,
    threshold: float = cfg.CATCH_RATE_THRESHOLD,
) -> pd.DataFrame:
    """Compute the catch rate for every model and flag eligibility.

    Catch rate = TP / (TP + FN) × 100. A model must reach ``threshold`` percent
    to qualify as champion; a system that misses most denials has no operational value.

    Formula column ``((y1-x)/x)×100``:
        ``x`` = actual denied claims (TP + FN), ``y1`` = TP.
        Always negative because TP ≤ actual denied. Retained for auditability.

    Args:
        model_map: Dict mapping display name → trained model instance.
        X_test: Test features.
        y_test: Test labels.
        threshold: Minimum catch-rate percentage required for champion eligibility.

    Returns:
        DataFrame indexed by model name with catch-rate metrics and a boolean
        ``_passes`` column used by :func:`select_champion`.
    """
    rows = []
    for model_name, model_obj in model_map.items():
        y_pred, y_proba = model_obj.predict(X_test)
        cm = confusion_matrix(y_test, y_pred)
        tn, fp, fn, tp = cm.ravel()
        x = int(tp + fn)
        y1 = int(tp)
        formula = ((y1 - x) / x) * 100
        catch_rate = (y1 / x) * 100
        # Probability-quality guards: reject models that can't rank claims or
        # respond to Stage-4 corrections. Two failure modes:
        #   - narrow band (low std, e.g. AdaBoost)
        #   - binary 0/1 output (few distinct values, e.g. fully-grown Decision Tree)
        proba_std = float(np.std(y_proba))
        proba_distinct = int(np.unique(np.round(y_proba, 3)).size)
        spread_min = getattr(cfg, "PROBABILITY_SPREAD_MIN", 0.0)
        distinct_min = getattr(cfg, "PROBABILITY_DISTINCT_MIN", 0)
        spread_ok = proba_std >= spread_min
        distinct_ok = proba_distinct >= distinct_min
        proba_ok = spread_ok and distinct_ok
        passes = (catch_rate >= threshold) and proba_ok
        if catch_rate >= threshold and not proba_ok:
            reason = []
            if not spread_ok:
                reason.append(f"std={proba_std:.3f}<{spread_min}")
            if not distinct_ok:
                reason.append(f"distinct={proba_distinct}<{distinct_min}")
            logger.warning(
                "%s passes catch rate (%.1f%%) but REJECTED — poor probability "
                "quality (%s): can't rank or rescore claims",
                model_name,
                catch_rate,
                ", ".join(reason),
            )
        rows.append(
            {
                "Model": model_name,
                "Actual Denied (x)": x,
                "True Pos (y1)": y1,
                "False Neg (FN)": fn,
                "((y1-x)/x)×100": round(formula, 2),
                "Catch Rate %": round(catch_rate, 2),
                "Proba Std": round(proba_std, 4),
                "Proba Distinct": proba_distinct,
                f"Passes (>={threshold:.0f}%)": "YES" if passes else "NO",
                "_passes": passes,
            }
        )
    df = pd.DataFrame(rows).set_index("Model")
    logger.info("Catch rate validation:\n%s", df.drop(columns=["_passes"]).to_string())
    return df


def build_leaderboard(
    model_map: dict[str, DenialModelBase],
    X: pd.DataFrame,
    y: pd.Series,
    X_test: pd.DataFrame,
    y_test: pd.Series,
    validation: pd.DataFrame | None = None,
) -> pd.DataFrame:
    """Build a ranked leaderboard with test metrics and cross-validation scores.

    When ``validation`` is supplied (the output of :func:`validate_catch_rates`),
    the leaderboard enforces the business gate explicitly:

    - Eligible models (``_passes=True``) are ranked 1st, 2nd, … by F1 Score.
    - Ineligible models receive ``Rank = "Rejected"`` and appear at the bottom.
    - A ``"Catch Rate Gate"`` column shows ``"Eligible"`` or ``"Rejected"`` for
      every row, making the gate decision visible without re-reading the
      validation table.

    Without ``validation``, all models are ranked by F1 Score (legacy behaviour,
    used when calling the function in isolation).

    Args:
        model_map: Dict mapping display name → trained model instance.
        X: Full feature set used for CV (train + test, no NearMiss IDs).
        y: Full labels.
        X_test: Test features for metric computation.
        y_test: Test labels.
        validation: Optional output of :func:`validate_catch_rates`. When
            provided, catch-rate eligibility is merged into the leaderboard
            and the ``Rank`` column reflects eligibility.

    Returns:
        DataFrame indexed by model name, sorted by eligibility then F1 Score,
        with columns: ``Accuracy``, ``Precision``, ``Recall``, ``F1 Score``,
        ``AUC-ROC``, ``CV Mean F1``, ``CV Std``, ``Caught Denials``,
        ``Catch Rate Gate`` (when validation is provided), ``Rank``.
    """
    kf = StratifiedKFold(
        n_splits=cfg.CV_FOLDS, shuffle=True, random_state=cfg.RANDOM_SEED
    )
    rows = {}
    for model_name, model_obj in model_map.items():
        cv_estimator = model_obj._get_cv_estimator()
        if cv_estimator is None:
            # Models not compatible with sklearn cross_val_score (e.g. FastAI NN):
            # report the test F1 as a single-point CV proxy so the row still ranks.
            _yp, _ = model_obj.predict(X_test)
            proxy_f1 = f1_score(y_test, _yp, zero_division=0)
            cv_mean, cv_std = proxy_f1, 0.0
            logger.info(
                "%s: sklearn CV not applicable — using test F1 as CV proxy", model_name
            )
        else:
            cv_scores = cross_val_score(cv_estimator, X, y, cv=kf, scoring="f1")
            cv_mean, cv_std = cv_scores.mean(), cv_scores.std()
        y_pred, y_proba = model_obj.predict(X_test)
        cm = confusion_matrix(y_test, y_pred)
        tn, fp, fn, tp = cm.ravel()
        auc = roc_auc_score(y_test, y_proba) if len(set(y_test)) > 1 else 0.0
        rows[model_name] = {
            "Accuracy": round(accuracy_score(y_test, y_pred), 4),
            "Precision": round(precision_score(y_test, y_pred, zero_division=0), 4),
            "Recall": round(recall_score(y_test, y_pred, zero_division=0), 4),
            "F1 Score": round(f1_score(y_test, y_pred, zero_division=0), 4),
            "AUC-ROC": round(auc, 4),
            "CV Mean F1": round(cv_mean, 4),
            "CV Std": round(cv_std, 4),
            "Caught Denials": f"{tp} / {tp + fn}",
        }

    lb = pd.DataFrame(rows).T
    lb.index.name = "Model"
    lb["F1 Score"] = lb["F1 Score"].astype(float)

    def _ordinal(n: int) -> str:
        suffix = {1: "st", 2: "nd", 3: "rd"}.get(n if n < 20 else n % 10, "th")
        return f"{n}{suffix}"

    if validation is not None:
        eligible = validation.index[validation["_passes"]].tolist()
        rejected = validation.index[~validation["_passes"]].tolist()

        lb["Catch Rate Gate"] = lb.index.map(
            lambda m: "Eligible" if m in eligible else "Rejected"
        )

        eligible_mask = lb.index.isin(eligible)
        rank_series = (
            lb.loc[eligible_mask, "F1 Score"]
            .rank(ascending=False)
            .astype(int)
            .map(_ordinal)
        )
        lb["Rank"] = "Rejected"
        lb.loc[eligible_mask, "Rank"] = rank_series

        # Eligible models first (sorted by F1 desc), rejected models last (F1 desc)
        lb["_sort_key"] = lb["Catch Rate Gate"].map({"Eligible": 0, "Rejected": 1})
        lb = lb.sort_values(["_sort_key", "F1 Score"], ascending=[True, False]).drop(
            columns=["_sort_key"]
        )

        if rejected:
            logger.warning(
                "Catch Rate Gate — REJECTED (%d model(s) below %.0f%% catch rate): %s",
                len(rejected),
                cfg.CATCH_RATE_THRESHOLD,
                rejected,
            )
        logger.info(
            "Catch Rate Gate — ELIGIBLE (%d model(s)): %s", len(eligible), eligible
        )
    else:
        lb["Rank"] = lb["F1 Score"].rank(ascending=False).astype(int)
        lb = lb.sort_values("Rank")
        lb["Rank"] = lb["Rank"].map(_ordinal)

    logger.info("MODEL LEADERBOARD:\n%s", lb.to_string())
    return lb


def select_champion(
    leaderboard: pd.DataFrame,
    validation: pd.DataFrame,
    model_map: dict[str, DenialModelBase],
) -> tuple[str, DenialModelBase]:
    """Select the champion model: highest F1 among catch-rate-eligible models.

    Two-step selection:
        1. Eligibility filter — ``_passes`` must be True in the catch-rate validation.
        2. Performance selection — highest F1 Score among eligible models.

    Args:
        leaderboard: Output of :func:`build_leaderboard`.
        validation: Output of :func:`validate_catch_rates`.
        model_map: Dict mapping display name → trained model instance.

    Returns:
        Tuple of ``(champion_name, champion_model_instance)``.

    Raises:
        RuntimeError: When no model passes the catch-rate threshold.
    """
    qualifying = validation.index[validation["_passes"]].tolist()
    if not qualifying:
        raise RuntimeError(
            "No model passed the catch-rate threshold — "
            "review feature engineering or lower cfg.CATCH_RATE_THRESHOLD."
        )
    champion_name = (
        leaderboard.loc[leaderboard.index.isin(qualifying), "F1 Score"]
        .astype(float)
        .idxmax()
    )
    champion = model_map[champion_name]
    logger.info(
        "Champion selected: %s (F1=%.4f, CatchRate=%.1f%%)",
        champion_name,
        float(leaderboard.loc[champion_name, "F1 Score"]),
        float(validation.loc[champion_name, "Catch Rate %"]),
    )
    return champion_name, champion


def save_pipeline_artifacts(
    champion: DenialModelBase,
    champion_name: str,
    threshold: float,
    model_path: Path = cfg.CHAMPION_MODEL_PATH,
    threshold_path: Path = cfg.MODEL_THRESHOLD_PATH,
) -> None:
    """Persist the champion model and Youden-J threshold to disk.

    Saves the calibrated model (``CalibratedClassifierCV``) when available so that
    the saved probabilities and the threshold are in the same calibrated space.
    Falls back to an LR ``Pipeline`` (scaler + LR) or raw estimator when calibration
    has not been run.

    Args:
        champion: Trained champion model instance.
        champion_name: Display name written into the threshold JSON.
        threshold: Youden-J optimal decision threshold (from calibrated probabilities).
        model_path: Destination path for the serialised estimator (``champion_model.pkl``).
        threshold_path: Destination path for the threshold JSON (``model_threshold.json``).
    """
    # FIX Issue-03: save the calibrated model so that the threshold (derived from
    # calibrated probabilities) and the saved model live in the same probability space.
    # Fallback chain: calibrated_model → LR Pipeline → raw estimator.
    # FastAI Tabular has no sklearn estimator to joblib-dump; it uses fastai's own
    # export mechanism instead.
    if isinstance(champion, FastAITabularModel):
        try:
            fastai_path = model_path.with_suffix(".fastai.pkl")
            champion._learn.export(fastai_path)
            logger.info("FastAI champion exported → %s", fastai_path)
            logger.warning(
                "Champion is FastAI Tabular — saved via fastai export, not %s. "
                "NB05/production must load it with load_learner().",
                model_path,
            )
        except Exception as exc:  # noqa: BLE001
            logger.error("FastAI export failed: %s", exc)
        # Still write the threshold JSON below.
        threshold_data = {
            "champion_model": champion_name,
            "opt_threshold": round(float(threshold), 4),
            "method": "Youden_J",
        }
        with open(threshold_path, "w") as fh:
            json.dump(threshold_data, fh, indent=2)
        logger.info("Threshold saved: %.4f → %s", threshold, threshold_path)
        return

    if getattr(champion, "calibrated_model", None) is not None:
        artifact = champion.calibrated_model
    elif getattr(champion, "scaler", None) is not None:
        artifact = Pipeline([("scaler", champion.scaler), ("clf", champion.model)])
    else:
        artifact = champion.model

    joblib.dump(artifact, model_path)
    logger.info("Champion model saved: %s → %s", type(artifact).__name__, model_path)

    threshold_data = {
        "champion_model": champion_name,
        "opt_threshold": round(float(threshold), 4),
        "method": "Youden_J",
    }
    with open(threshold_path, "w") as fh:
        json.dump(threshold_data, fh, indent=2)
    logger.info("Threshold saved: %.4f → %s", threshold, threshold_path)


def generate_champion_explainability(
    champion: DenialModelBase,
    champion_name: str,
    X_train: pd.DataFrame,
    y_train: pd.Series,
    feature_cols: list[str],
    report_path: Path = cfg.XAI_CHAMPION_REPORT_PATH,
    top_n: int = cfg.XAI_TOP_N_FEATURES,
) -> dict[str, Any]:
    """Produce and persist an explainability report for the champion model.

    Runs the XAI battery (native importance, SHAP global importance, permutation
    importance) via the standalone :class:`ModelExplainer`, plus stacking
    meta-weights when the champion is a stacking ensemble. Writes the report to
    ``report_path`` as JSON.

    This is the code-level realisation of the XAI field guide: the champion — the
    model that will actually gate real claims — ships with a transparency report so
    reviewers can see which features drive its denials.

    Args:
        champion: Trained champion model instance.
        champion_name: Champion display name.
        X_train: Training features (used for SHAP / permutation).
        y_train: Training labels.
        feature_cols: Ordered feature names.
        report_path: JSON destination path.
        top_n: Number of top features per technique.

    Returns:
        The assembled report dict (also written to disk).
    """
    if not cfg.XAI_ENABLED:
        logger.info(
            "XAI disabled (cfg.XAI_ENABLED=False) — skipping explainability report"
        )
        return {}

    logger.info("Generating champion explainability report for %s", champion_name)
    # Explainability is a standalone concern — wrap the trained champion in the
    # ModelExplainer (not part of the model inheritance chain) and run the battery.
    explainer = ModelExplainer(champion)
    report = explainer.full_report(X_train, y_train, feature_cols, top_n=top_n)

    report_path.parent.mkdir(parents=True, exist_ok=True)
    with open(report_path, "w") as fh:
        json.dump(report, fh, indent=2, default=str)
    logger.info("Champion explainability report saved → %s", report_path)

    # Also persist the business-friendly summary table as CSV for non-technical users.
    try:
        summary_df = pd.DataFrame(report.get("business_summary", []))
        if not summary_df.empty:
            summary_path = getattr(
                cfg,
                "XAI_BUSINESS_SUMMARY_PATH",
                report_path.parent / "champion_business_summary.csv",
            )
            summary_df.to_csv(summary_path, index=False)
            logger.info("Business explainability summary saved → %s", summary_path)
    except Exception as exc:  # noqa: BLE001
        logger.warning("Could not save business summary CSV: %s", exc)

    return report


# ---------------------------------------------------------------------------
# Pipeline entry point
# ---------------------------------------------------------------------------


def run_modelling_pipeline(
    feature_matrix_path: Path | None = None,
    model_path: Path = cfg.CHAMPION_MODEL_PATH,
    threshold_path: Path = cfg.MODEL_THRESHOLD_PATH,
    tune: bool = True,
    generate_explainability: bool = cfg.XAI_ENABLED,
) -> tuple[str, DenialModelBase, float]:
    """Execute the full Stage 1 modelling pipeline end-to-end.

    When ``feature_matrix_path`` is None (default), the training data source
    is chosen automatically based on ``cfg.NEARMISS_ENABLED``:
      - True  → ``cfg.FEATURE_MATRIX_RESAMPLED`` (NearMiss-balanced)
      - False → ``cfg.FEATURE_MATRIX_PATH`` (full, natural-rate)

    This means toggling ``NEARMISS_ENABLED`` in config.py is the only change
    needed to switch resampling on or off — no code editing required.

    Steps:
        1. Load the selected feature matrix.
        2. Train all base + ensemble models (with optional hyperparameter tuning).
           Tuning auto-selects GridSearchCV vs RandomizedSearchCV per search-space
           size via :func:`_auto_search`.
        3. Validate catch rates — the business gate. Models below the threshold are
           rejected and cannot become champion.
        4. Build a ranked leaderboard (eligible models ranked by F1; rejected last).
        5. Select champion: highest F1 among catch-rate-eligible models.
        6. Calibrate the champion (isotonic/Platt) and derive the Youden-J threshold.
        7. Persist ``champion_model.pkl`` and ``model_threshold.json`` automatically.
        8. Generate and persist the champion explainability report (SHAP, permutation,
           native importance) when ``generate_explainability`` is True.

    The business logic in steps 3–5 is fixed: catch rate is a hard gate, and F1
    breaks ties among survivors. It is intentionally not configurable.

    Args:
        feature_matrix_path: Path to the NearMiss-resampled training CSV (NB03 output).
        model_path: Destination for the serialised champion estimator.
        threshold_path: Destination for the champion name and threshold JSON.
        tune: Whether to run hyperparameter tuning before final training.
        generate_explainability: Whether to produce the champion XAI report.

    Returns:
        Tuple of ``(champion_name, champion_model_instance, opt_threshold)``.
    """
    logger.info("--- Stage 1 Modelling Pipeline ---")

    # Auto-select training data source based on NEARMISS_ENABLED when caller
    # did not provide an explicit path.  Toggle cfg.NEARMISS_ENABLED in config.py.
    if feature_matrix_path is None:
        if getattr(cfg, "NEARMISS_ENABLED", True):
            feature_matrix_path = cfg.FEATURE_MATRIX_RESAMPLED
            logger.info(
                "NearMiss enabled — training on resampled matrix: %s",
                feature_matrix_path,
            )
        else:
            feature_matrix_path = cfg.FEATURE_MATRIX_PATH
            logger.info(
                "NearMiss disabled — training on full feature matrix: %s",
                feature_matrix_path,
            )

    # Load data
    fm = pd.read_csv(feature_matrix_path)

    # Use STAGE1_FEATURES from config as the canonical list so updating config.py
    # (Section 0.7) is the only change needed when the feature set evolves.
    # Features listed in config but absent from the CSV are dropped with a warning
    # (NB03 may not have produced them yet); features in the CSV not in config are
    # also excluded so the model never accidentally trains on unlisted columns.
    available_cols = set(fm.columns) - {"claim_id", "denial_flag"}
    config_features = list(cfg.STAGE1_FEATURES)
    missing_from_data = [f for f in config_features if f not in available_cols]
    extra_in_data = [f for f in available_cols if f not in config_features]
    feature_cols = [f for f in config_features if f in available_cols]

    if missing_from_data:
        logger.warning(
            "STAGE1_FEATURES listed in config but absent from data (will be skipped): %s",
            missing_from_data,
        )
    if extra_in_data:
        logger.info(
            "Columns in feature matrix not in STAGE1_FEATURES (excluded): %s",
            extra_in_data,
        )
    if not feature_cols:
        raise ValueError(
            "No STAGE1_FEATURES found in the feature matrix. "
            "Check config.py Section 0.7 matches the NB03 output columns."
        )

    logger.info("Using %d features from config STAGE1_FEATURES", len(feature_cols))
    X = fm[feature_cols].fillna(0)
    y = fm["denial_flag"]
    logger.info(
        "Feature matrix loaded: %s | denial rate: %.1f%%", fm.shape, y.mean() * 100
    )

    train_ids = set(pickle.load(open(cfg.SPLIT_TRAIN_IDS_PATH, "rb")))
    fm_train = fm[fm["claim_id"].isin(train_ids)]
    X_train = fm_train[feature_cols].fillna(0)
    y_train = fm_train["denial_flag"]

    eval_test = pd.read_csv(cfg.EVAL_TEST_SET_PATH)
    X_test = eval_test[feature_cols].fillna(0)
    y_test = eval_test["denial_flag"]
    logger.info("Train: %d | Test: %d (held-out from NB03)", len(X_train), len(X_test))
    # Instantiate all twenty base models plus the ensemble models
    model_map: dict[str, DenialModelBase] = {
        "XGBoost": XGBoostDenialModel(),
        "LightGBM": LightGBMDenialModel(),
        "Random Forest": RandomForestDenialModel(),
        "Logistic Regression": LogisticRegressionDenialModel(),
        "Gradient Boosting": GradientBoostingDenialModel(),
        "Extra Trees": ExtraTreesDenialModel(),
        "AdaBoost": AdaBoostDenialModel(),
        "Decision Tree": DecisionTreeDenialModel(),
        # "SVM": SVMDenialModel(),                                     # commented — uncomment to re-enable
        # "KNN": KNearestNeighborsDenialModel(),                       # commented — uncomment to re-enable
        # "Naive Bayes": NaiveBayesDenialModel(),                      # commented — uncomment to re-enable
        "CatBoost": CatBoostDenialModel(),
        # "HistGradientBoosting": HistGradientBoostingDenialModel(),    # commented — uncomment to re-enable
        # "Bagging": BaggingDenialModel(),                              # commented — uncomment to re-enable
        # "MLP": MLPDenialModel(),                                      # commented — uncomment to re-enable
        # "LDA": LinearDiscriminantAnalysisDenialModel(),               # commented — uncomment to re-enable
        # "QDA": QuadraticDiscriminantAnalysisDenialModel(),            # commented — uncomment to re-enable
        # "SGD": SGDDenialModel(),                                      # commented — uncomment to re-enable
        # "Bernoulli NB": BernoulliNBDenialModel(),                     # commented — uncomment to re-enable
        # "Complement NB": ComplementNBDenialModel(),                   # commented — uncomment to re-enable
        # --- Ensemble models: boosting + stacking (soft & hard voting) ---
        "Boosting Ensemble": BoostingEnsembleDenialModel(),
        "Voting (Soft)": VotingSoftDenialModel(),
        "Voting (Hard)": VotingHardDenialModel(),
        "Stacking": StackingDenialModel(),
    }

    # --- Deep learning: FastAI Tabular (optional; requires fastai + torch) ---
    # Enabled via cfg.FASTAI_ENABLED. Added only when fastai imports successfully,
    # so the classical pipeline still runs on machines without torch installed.
    if getattr(cfg, "FASTAI_ENABLED", False):
        try:
            import fastai  # noqa: F401

            model_map["FastAI Tabular"] = FastAITabularModel()
            logger.info("FastAI Tabular model added to the leaderboard")
        except ImportError:
            logger.warning(
                "cfg.FASTAI_ENABLED=True but fastai is not installed — "
                "skipping FastAI Tabular. Install with: pip install fastai torch"
            )

    # Tune (optional) then train
    for name, model in model_map.items():
        if tune:
            model.tune(X_train, y_train)
        model.train(X_train, y_train)

    # Evaluate on test set (metrics logged inside evaluate())
    for model in model_map.values():
        model.evaluate(X_test, y_test)

    # Train-vs-test gap analysis
    train_test_gap(list(model_map.values()), X_train, y_train, X_test, y_test)

    # Catch-rate validation — business gate; must run before leaderboard so that
    # the leaderboard can surface eligibility alongside performance metrics.
    validation = validate_catch_rates(model_map, X_test, y_test)

    # Leaderboard: eligible models ranked by F1, rejected models labelled "Rejected"
    leaderboard = build_leaderboard(
        model_map, X, y, X_test, y_test, validation=validation
    )

    # Champion selection — enforces the gate; raises if no model qualifies
    champion_name, champion = select_champion(leaderboard, validation, model_map)

    # Calibrate champion
    champion.calibrate(X_train, y_train, X_test=X_test, y_test=y_test)
    threshold = champion.calibration_threshold

    # Persist champion + threshold automatically
    save_pipeline_artifacts(
        champion, champion_name, threshold, model_path, threshold_path
    )

    # Champion explainability report (SHAP / permutation / native importance)
    if generate_explainability:
        try:
            generate_champion_explainability(
                champion, champion_name, X_train, y_train, feature_cols
            )
        except Exception as _xai_exc:  # noqa: BLE001
            logger.warning("Explainability report failed (non-fatal): %s", _xai_exc)

    logger.info(
        "Modelling pipeline complete — champion: %s | threshold: %.4f",
        champion_name,
        threshold,
    )
    return champion_name, champion, threshold


# ---------------------------------------------------------------------------
# Recovery Intelligence pipeline entry point
# ---------------------------------------------------------------------------


def run() -> None:
    """Stage 7 — Model Training.

    Bridges the class-based DenialModelBase hierarchy to the Recovery
    Intelligence Modeling pipeline.

    Reads the preprocessed train/test Excel files produced by Stage 6,
    applies CO/PR filtering, trains all 24 models, validates catch rates,
    selects a champion, calibrates it, and saves:
      - champion_model.pkl  (dict bundle — includes preprocessing artifacts
                             so Stage 8 / validation.py can run standalone)
      - champion_threshold.json
      - test_predictions.csv

    Nothing from this function modifies the DenialModelBase classes; all
    pipeline I/O is handled here.
    """
    import config.modeling_config as _mc

    logger.info("Stage 7 - Model Training started.")
    np.random.seed(_mc.RANDOM_STATE)

    os.makedirs(_mc.REPORTS_DIR,     exist_ok=True)
    os.makedirs(_mc.MODELS_DIR,      exist_ok=True)
    os.makedirs(_mc.PREDICTIONS_DIR, exist_ok=True)
    os.makedirs(_mc.VALIDATION_DIR,  exist_ok=True)

    label_lookup = {v: k for k, v in _mc.TARGET_ENCODING.items()}

    # ── Step 0: Load preprocessed train / test data ──────────────────────
    print("\nStep 0: Load preprocessed data")
    for fpath in (_mc.TRAIN_PREPROCESSED_FILE, _mc.TEST_PREPROCESSED_FILE):
        if not os.path.exists(fpath):
            raise FileNotFoundError(
                f"Preprocessed file not found at:\n  {fpath}\n"
                "Run preprocessing.py first."
            )
    train_df = pd.read_excel(_mc.TRAIN_PREPROCESSED_FILE)
    test_df  = pd.read_excel(_mc.TEST_PREPROCESSED_FILE)
    print(f"  Train : {train_df.shape[0]:,} rows x {train_df.shape[1]} columns")
    print(f"  Test  : {test_df.shape[0]:,} rows x {test_df.shape[1]} columns")

    # ── Step 1: Filter adjustment groups (CO / PR) ────────────────────────
    print(f"\nStep 1: Filter adjustment groups — {_mc.ML_EXCLUDE_GROUPS}")
    if _mc.ML_EXCLUDE_GROUP_COL in train_df.columns:
        train_df[_mc.ML_EXCLUDE_GROUP_COL] = (
            train_df[_mc.ML_EXCLUDE_GROUP_COL].astype(str).str.strip()
        )
        test_df[_mc.ML_EXCLUDE_GROUP_COL] = (
            test_df[_mc.ML_EXCLUDE_GROUP_COL].astype(str).str.strip()
        )
        train_df = train_df[
            ~train_df[_mc.ML_EXCLUDE_GROUP_COL].isin(_mc.ML_EXCLUDE_GROUPS)
        ].reset_index(drop=True)
        test_df = test_df[
            ~test_df[_mc.ML_EXCLUDE_GROUP_COL].isin(_mc.ML_EXCLUDE_GROUPS)
        ].reset_index(drop=True)
        print(f"  After filter — Train: {len(train_df):,}  Test: {len(test_df):,}")

    # ── Step 2: Prepare features and target ──────────────────────────────
    print("\nStep 2: Prepare features and target")
    train_df = train_df[train_df[_mc.TARGET_COLUMN].notna()].copy().reset_index(drop=True)
    test_df  = test_df[test_df[_mc.TARGET_COLUMN].notna()].copy().reset_index(drop=True)

    # Save claim ID columns before stripping features — needed for predictions CSV
    test_claim_ids = (
        test_df[_mc.CLAIM_CONTROL_NUMBER_COL].values
        if _mc.CLAIM_CONTROL_NUMBER_COL in test_df.columns else None
    )
    test_line_ids = (
        test_df[_mc.CLAIM_LINE_NUMBER_COL].values
        if _mc.CLAIM_LINE_NUMBER_COL in test_df.columns else None
    )

    y_train = train_df[_mc.TARGET_COLUMN].map(_mc.TARGET_ENCODING).astype(int)
    y_test  = test_df[_mc.TARGET_COLUMN].map(_mc.TARGET_ENCODING).astype(int)

    # Zero-fill any MODEL_FEATURES not present in the data
    for col in _mc.MODEL_FEATURES:
        if col not in train_df.columns:
            train_df[col] = 0
        if col not in test_df.columns:
            test_df[col] = 0

    X_train = train_df[_mc.MODEL_FEATURES].copy()
    X_test  = test_df[_mc.MODEL_FEATURES].copy()
    print(f"  X_train: {X_train.shape}  X_test: {X_test.shape}")
    print(f"  Positive rate — train: {y_train.mean():.1%}  test: {y_test.mean():.1%}")

    # ── Step 3: Load preprocessing bundle from Stage 6 ───────────────────
    print("\nStep 3: Load preprocessing bundle")
    if not os.path.exists(_mc.PREPROCESSING_BUNDLE_PKL):
        raise FileNotFoundError(
            f"Preprocessing bundle not found at:\n  {_mc.PREPROCESSING_BUNDLE_PKL}\n"
            "Run preprocessing.py first."
        )
    bundle         = joblib.load(_mc.PREPROCESSING_BUNDLE_PKL)
    fill_values    = bundle["fill_values"]
    encoding_state = bundle["encoding_state"]
    scalers        = bundle["scalers"]
    print(f"  Bundle loaded from: {_mc.PREPROCESSING_BUNDLE_PKL}")

    # ── Step 4: Class balancing (training set only) ───────────────────────
    if _mc.IMBALANCE_METHOD not in (None, "class_weight"):
        try:
            if _mc.IMBALANCE_METHOD == "SMOTE":
                from imblearn.over_sampling import SMOTE
                sampler = SMOTE(random_state=_mc.RANDOM_STATE)
            elif _mc.IMBALANCE_METHOD == "NearMiss":
                from imblearn.under_sampling import NearMiss
                sampler = NearMiss(**_mc.IMBALANCE_METHOD_PARAMS.get("NearMiss", {}))
            else:
                from imblearn.under_sampling import RandomUnderSampler
                sampler = RandomUnderSampler(
                    random_state=_mc.RANDOM_STATE,
                    **_mc.IMBALANCE_METHOD_PARAMS.get("RandomUnderSampling", {}),
                )
            cols = X_train.columns.tolist()
            X_res, y_res = sampler.fit_resample(X_train, y_train)
            X_train = pd.DataFrame(X_res, columns=cols)
            y_train = pd.Series(y_res, name=_mc.TARGET_COLUMN)
            print(
                f"\nClass balancing ({_mc.IMBALANCE_METHOD}): "
                f"{dict(y_train.value_counts())}"
            )
        except Exception as exc:
            logger.warning("Class balancing failed (%s) — proceeding without resampling", exc)
    else:
        print(f"\nClass balancing: {_mc.IMBALANCE_METHOD} (no resampling)")

    # NaN sweep — fill with training-set median; fall back to 0
    for col in X_train.columns:
        if X_train[col].isna().any():
            fill_val = X_train[col].median()
            if pd.isna(fill_val):
                fill_val = 0.0
            X_train[col] = X_train[col].fillna(fill_val)
        if col in X_test.columns and X_test[col].isna().any():
            fill_val = X_train[col].median()
            if pd.isna(fill_val):
                fill_val = 0.0
            X_test[col] = X_test[col].fillna(fill_val)

    # ── Step 5: Build model map ───────────────────────────────────────────
    print("\nStep 5: Build model map")
    model_map: dict[str, DenialModelBase] = {
        "XGBoost":              XGBoostDenialModel(),
        "LightGBM":             LightGBMDenialModel(),
        "Random Forest":        RandomForestDenialModel(),
        "Logistic Regression":  LogisticRegressionDenialModel(),
        "Gradient Boosting":    GradientBoostingDenialModel(),
        "Extra Trees":          ExtraTreesDenialModel(),
        "AdaBoost":             AdaBoostDenialModel(),
        "Decision Tree":        DecisionTreeDenialModel(),
        # "SVM":                  SVMDenialModel(),                         # commented — uncomment to re-enable
        # "KNN":                  KNearestNeighborsDenialModel(),           # commented — uncomment to re-enable
        # "Naive Bayes":          NaiveBayesDenialModel(),                  # commented — uncomment to re-enable
        "CatBoost":             CatBoostDenialModel(),
        # "HistGradientBoosting": HistGradientBoostingDenialModel(),        # commented — uncomment to re-enable
        # "Bagging":              BaggingDenialModel(),                     # commented — uncomment to re-enable
        # "MLP":                  MLPDenialModel(),                         # commented — uncomment to re-enable
        # "LDA":                  LinearDiscriminantAnalysisDenialModel(),  # commented — uncomment to re-enable
        # "QDA":                  QuadraticDiscriminantAnalysisDenialModel(), # commented — uncomment to re-enable
        # "SGD":                  SGDDenialModel(),                         # commented — uncomment to re-enable
        # "Bernoulli NB":         BernoulliNBDenialModel(),                 # commented — uncomment to re-enable
        # "Complement NB":        ComplementNBDenialModel(),                # commented — uncomment to re-enable
        "Boosting Ensemble":    BoostingEnsembleDenialModel(),
        "Voting (Soft)":        VotingSoftDenialModel(),
        "Voting (Hard)":        VotingHardDenialModel(),
        "Stacking":             StackingDenialModel(),
    }
    if getattr(cfg, "FASTAI_ENABLED", False):
        try:
            import fastai  # noqa: F401
            model_map["FastAI Tabular"] = FastAITabularModel()
            logger.info("FastAI Tabular model added to the leaderboard")
        except ImportError:
            logger.warning(
                "cfg.FASTAI_ENABLED=True but fastai is not installed — skipping"
            )
    print(f"  Total models: {len(model_map)}")

    # ── Step 6: Tune (optional) and train all models ──────────────────────
    tune = _mc.TUNING_METHOD != "none"
    print(f"\nStep 6: {'Tune + ' if tune else ''}Train all models")
    for name, model in model_map.items():
        try:
            if tune:
                model.tune(X_train, y_train)
            model.train(X_train, y_train)
            print(f"  {name:30s} trained")
        except Exception as exc:
            logger.error("Training failed for %s: %s", name, exc)
            print(f"  {name:30s} FAILED — {exc}")

    # Drop models that failed to produce a fitted estimator
    model_map = {k: v for k, v in model_map.items() if v.model is not None}

    # Evaluate each model on the test set (metrics written to log)
    for model in model_map.values():
        try:
            model.evaluate(X_test, y_test)
        except Exception as exc:
            logger.warning("Evaluation failed for %s: %s", model.name, exc)

    # Train-vs-test gap analysis
    try:
        _gap_df = train_test_gap(list(model_map.values()), X_train, y_train, X_test, y_test)
        _metrics_path = os.path.join(str(_mc.REPORTS_DIR), _mc.TRAIN_TEST_METRICS_XLSX)
        os.makedirs(str(_mc.REPORTS_DIR), exist_ok=True)
        _gap_df.to_excel(_metrics_path, engine="openpyxl")
        print(f"  Train/test metrics saved → {_metrics_path}")
        logger.info("Train/test metrics saved → %s | %d rows x %d cols", _metrics_path, _gap_df.shape[0], _gap_df.shape[1])
        logger.info("Train/test metrics:\n%s", _gap_df.to_string())
    except Exception as exc:
        logger.warning("train_test_gap failed (non-fatal): %s", exc)

    # ── Step 7: Catch-rate validation (business gate) ─────────────────────
    print("\nStep 7: Catch-rate validation")
    validation = validate_catch_rates(model_map, X_test, y_test)
    print(validation.drop(columns=["_passes"], errors="ignore").to_string())

    # ── Step 8: Leaderboard ───────────────────────────────────────────────
    print("\nStep 8: Leaderboard")
    leaderboard = build_leaderboard(
        model_map, X_train, y_train, X_test, y_test, validation=validation
    )
    print(leaderboard.to_string())
    leaderboard.to_csv(
        os.path.join(str(_mc.REPORTS_DIR), _mc.MODEL_COMPARISON_CSV), index=False
    )

    # ── Step 9: Champion selection ────────────────────────────────────────
    print("\nStep 9: Champion selection")
    champion_name, champion = select_champion(leaderboard, validation, model_map)
    print(f"  Champion: {champion_name}")

    # ── Step 10: Calibrate champion ───────────────────────────────────────
    print("\nStep 10: Calibrate champion")
    champion.calibrate(X_train, y_train, X_test=X_test, y_test=y_test)
    threshold = champion.calibration_threshold
    print(f"  Threshold: {threshold:.4f}")
    print(f"  Calibration: {getattr(champion, 'calibration_method', 'N/A')}")

    # ── Step 11: Predictions on test set ─────────────────────────────────
    print("\nStep 11: Predictions")
    if champion.calibrated_model is not None:
        test_pred, test_prob = champion.predict_calibrated(X_test, threshold)
    else:
        _, test_prob = champion.predict(X_test)
        test_pred = (test_prob >= threshold).astype(int)

    predictions_df = X_test.copy()
    predictions_df.insert(
        0, _mc.CLAIM_CONTROL_NUMBER_COL,
        test_claim_ids if test_claim_ids is not None else np.nan,
    )
    predictions_df.insert(
        1, _mc.CLAIM_LINE_NUMBER_COL,
        test_line_ids if test_line_ids is not None else np.nan,
    )
    predictions_df["actual_class"]         = y_test.map(label_lookup).values
    predictions_df["recovery_probability"] = test_prob.round(4)
    predictions_df["predicted_class"] = (
        pd.Series(test_pred, index=X_test.index).map(label_lookup).values
    )
    predictions_df.to_csv(_mc.TEST_PREDICTIONS_CSV, index=False)
    print(f"  Predictions saved → {_mc.TEST_PREDICTIONS_CSV}")

    # ── Step 12: Save champion model bundle + threshold ───────────────────
    print("\nStep 12: Save outputs")

    # Build the dict bundle Stage 8 / validation.py expects.
    # The preprocessing artifacts (fill_values, encoding_state, scalers) are
    # embedded here so the champion PKL is self-contained for inference.
    model_artifact = (
        champion.calibrated_model
        if champion.calibrated_model is not None
        else champion.model
    )
    model_bundle = {
        "calibrated_model":   model_artifact,
        "fill_values":        fill_values,
        "encoding_state":     encoding_state,
        "scalers":            scalers,
        "feature_names":      list(_mc.MODEL_FEATURES),
        "champion_name":      champion_name,
        "selected_features":  list(_mc.MODEL_FEATURES),
        "optimal_threshold":  threshold,
        "calibration_method": getattr(champion, "calibration_method", "isotonic"),
        "target_encoding":    _mc.TARGET_ENCODING,
        "target_names":       _mc.TARGET_NAMES,
        "label_lookup":       label_lookup,
    }
    os.makedirs(os.path.dirname(str(_mc.CHAMPION_MODEL_PKL)), exist_ok=True)
    joblib.dump(model_bundle, _mc.CHAMPION_MODEL_PKL)
    print(f"  Champion bundle saved → {_mc.CHAMPION_MODEL_PKL}")

    os.makedirs(os.path.dirname(str(_mc.THRESHOLD_JSON)), exist_ok=True)
    with open(_mc.THRESHOLD_JSON, "w") as fh:
        json.dump(
            {
                "champion_model":     champion_name,
                "decision_threshold": round(float(threshold), 4),
                "calibration_method": getattr(champion, "calibration_method", "isotonic"),
            },
            fh,
            indent=2,
        )
    print(f"  Threshold JSON saved → {_mc.THRESHOLD_JSON}")

    # ── Step 12b: Rebuild end-to-end sklearn inference pipeline ──────────────
    # This step is mandatory: every training run must produce a fresh
    # model_pipeline.joblib so the agent's probability always matches the
    # probability computed directly from the training artifacts.
    print("\nStep 12b: Rebuild sklearn inference pipeline")
    try:
        _bp_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "sklearn_pipeline")
        if _bp_dir not in sys.path:
            sys.path.insert(0, _bp_dir)
        from build_pipeline import build_and_save_pipeline
        build_and_save_pipeline()
        _pipe_path = os.path.join(
            os.path.dirname(str(_mc.CHAMPION_MODEL_PKL)), "model_pipeline.joblib"
        )
        print(f"  Inference pipeline saved → {_pipe_path}")
        logger.info("Inference pipeline rebuilt → %s", _pipe_path)
    except Exception as _pipe_exc:
        logger.warning("Pipeline rebuild failed (non-fatal): %s", _pipe_exc)
        print(f"  WARNING: Pipeline rebuild failed — {_pipe_exc}")
        print("  Run src/sklearn_pipeline/build_pipeline.py manually to sync inference.")

    # ── Step 13: Explainability (non-fatal) ──────────────────────────────
    if cfg.XAI_ENABLED:
        try:
            generate_champion_explainability(
                champion, champion_name, X_train, y_train, list(_mc.MODEL_FEATURES)
            )
        except Exception as xai_exc:
            logger.warning("Explainability report failed (non-fatal): %s", xai_exc)

    logger.info(
        "Stage 7 complete. Champion: %s | threshold: %.4f",
        champion_name,
        threshold,
    )
    print("\nStage 7 complete.\n")


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s  %(levelname)s  %(message)s")
    run()
