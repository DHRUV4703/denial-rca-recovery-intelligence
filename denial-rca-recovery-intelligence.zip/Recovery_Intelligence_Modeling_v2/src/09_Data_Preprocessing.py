# 09- Data_Preprocessing.py

"""
preprocessing.py - Stage 6: Imputation, Encoding, and Scaling

Reads the ADS files produced by Stage 5 (feature_engineering.py), applies
column-level preprocessing (imputation, encoding, scaling), and saves two
preprocessed files plus a preprocessing bundle PKL.

Leakage-safe design:
  - All preprocessing steps (imputers, encoder maps, scalers) are FITTED on
    the TRAINING ADS only. The fitted objects are then APPLIED to both splits.
  - Fitted objects are saved as preprocessing_bundle.pkl so that modeling.py
    can include them in champion_model.pkl for production inference.

Preprocessing rules are driven entirely by preprocessing_config.py — do not change
rules in this file; update config.

Input  : output/Feature_Engineered_Data/train_ads.xlsx
         output/Feature_Engineered_Data/test_ads.xlsx
Output : output/Preprocessed_Data/train_preprocessed.xlsx
         output/Preprocessed_Data/test_preprocessed.xlsx
         output/Model/PKL/preprocessing_bundle.pkl
"""

import logging
import os
import sys

import joblib
import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import config.preprocessing_config as config

logger = logging.getLogger(__name__)


# =============================================================================
# STEP 0 — LOAD ADS FILES
# =============================================================================

def load_ads(file_path, label):
    print(f"\nStep 0: Load ADS ({label})")
    print(f"  Input : {file_path}")

    if not os.path.exists(file_path):
        raise FileNotFoundError(
            f"ADS file not found:\n  {file_path}\n"
            "Run feature_engineering.py first."
        )

    df = pd.read_excel(file_path)
    print(f"  Loaded : {df.shape[0]:,} rows x {df.shape[1]} columns")
    logger.info("INPUT  (%s): %s | %d rows x %d cols", label, file_path, df.shape[0], df.shape[1])
    logger.info("Columns (%d): %s", len(df.columns), ", ".join(df.columns.tolist()))
    return df


# =============================================================================
# STEP A — DERIVE FLAG COLUMNS (raw source column dropped after flag is made)
# =============================================================================

def derive_flags(df):
    """
    Create binary flag columns from raw columns that are too sparse to encode.

    Controlled by config.IMPUTE_DROP_TO_FLAG:
        { "new_flag_col": "raw_source_col" }

    The raw source column is dropped after the flag is created.
    """
    for flag_col, raw_col in config.IMPUTE_DROP_TO_FLAG.items():
        if raw_col not in df.columns:
            logger.warning("Flag derivation: '%s' not found — setting '%s' to 0.", raw_col, flag_col)
            df[flag_col] = 0
            continue

        not_null   = df[raw_col].notna()
        not_empty  = df[raw_col].astype(str).str.strip() != ""
        not_absent = ~(
            df[raw_col].astype(str).str.upper()
            .str.startswith(("NO_", "NONE", "MISSING", "NAN"))
        )
        df[flag_col] = (not_null & not_empty & not_absent).astype(int)
        df = df.drop(columns=[raw_col])

    return df


# =============================================================================
# STEP B — CATEGORICAL FILLS
# =============================================================================

def apply_categorical_fills(df):
    """Fill missing categoricals with placeholder strings from config."""
    for col in config.IMPUTE_FILL_NONE:
        if col in df.columns:
            df[col] = df[col].fillna("None")

    for col in config.IMPUTE_FILL_MISSING:
        if col in df.columns:
            df[col] = df[col].fillna("Missing")

    return df


# =============================================================================
# STEP C — NUMERIC IMPUTATION
# =============================================================================

def apply_numeric_imputation(df, fill_values, fit):
    """
    Impute numeric columns using the strategy declared in config.py.

    fit=True  : compute and store fill values (training data)
    fit=False : reuse stored fill values (test data)
    """
    # Zero fill
    for col in config.IMPUTE_ZERO:
        if col in df.columns:
            df[col] = df[col].fillna(0)

    # Median, mean, mode
    groups = [
        (config.IMPUTE_MEDIAN, "median"),
        (config.IMPUTE_MEAN,   "mean"),
        (config.IMPUTE_MODE,   "mode"),
    ]
    for col_list, strategy in groups:
        for col in col_list:
            if col not in df.columns:
                continue
            key = f"{strategy}__{col}"
            if fit:
                if strategy == "median":
                    val = df[col].median()
                elif strategy == "mean":
                    val = df[col].mean()
                else:
                    modes = df[col].mode()
                    val = modes.iloc[0] if len(modes) > 0 else 0
                fill_values[key] = val
            val = fill_values.get(key, 0)
            df[col] = df[col].fillna(val)

    # KNN imputation
    knn_cols = [c for c in config.IMPUTE_KNN if c in df.columns]
    if knn_cols:
        from sklearn.impute import KNNImputer
        knn_key = "__knn_imputer__"
        if fit:
            knn = KNNImputer(n_neighbors=config.IMPUTE_KNN_NEIGHBORS)
            df[knn_cols] = knn.fit_transform(df[knn_cols])
            fill_values[knn_key] = knn
        else:
            knn = fill_values.get(knn_key)
            if knn is not None:
                df[knn_cols] = knn.transform(df[knn_cols])

    # MICE / IterativeImputer
    mice_cols = [c for c in config.IMPUTE_MICE if c in df.columns]
    if mice_cols:
        from sklearn.experimental import enable_iterative_imputer  # noqa: F401
        from sklearn.impute import IterativeImputer
        mice_key = "__mice_imputer__"
        if fit:
            mice = IterativeImputer(random_state=config.RANDOM_STATE, max_iter=10)
            df[mice_cols] = mice.fit_transform(df[mice_cols])
            fill_values[mice_key] = mice
        else:
            mice = fill_values.get(mice_key)
            if mice is not None:
                df[mice_cols] = mice.transform(df[mice_cols])

    return df, fill_values


# =============================================================================
# STEP D — ENCODING
# =============================================================================

def apply_encoding(df, encoding_state, fit):
    """
    Encode categorical columns.

    Processing order:
        1. Binary manual maps     (BINARY_MAP_COLUMNS)
        2. One-hot encoding       (OHE_COLUMNS)
        3. Frequency encoding     (FREQUENCY_ENCODE_COLUMNS)
        4. Ordinal / as-is        (ORDINAL_AS_IS_COLUMNS — no change)

    fit=True  : compute and store encoding maps (training data)
    fit=False : reuse stored maps (test data)
    """
    ohe_drop = getattr(config, "OHE_DROP", "first")

    # 1. Binary manual maps
    for col, mapping in config.BINARY_MAP_COLUMNS.items():
        if col not in df.columns:
            continue
        new_col = col + "_bin"
        df[new_col] = df[col].map(mapping).fillna(0).astype(int)
        df = df.drop(columns=[col])

    # 2. One-hot encoding
    for col in config.OHE_COLUMNS:
        if col not in df.columns:
            continue
        if fit:
            cats = sorted(df[col].dropna().astype(str).unique().tolist())
            encoding_state[f"ohe__{col}"] = cats
        else:
            cats = encoding_state.get(f"ohe__{col}", [])

        encode_cats = cats[1:] if ohe_drop == "first" and len(cats) > 1 else cats
        for cat in encode_cats:
            dummy_col = f"{col}_{cat}_ohe"
            df[dummy_col] = (df[col].astype(str) == str(cat)).astype(int)
        df = df.drop(columns=[col])

    # 3. Frequency encoding
    for col in config.FREQUENCY_ENCODE_COLUMNS:
        if col not in df.columns:
            continue
        if fit:
            freq_map = df[col].value_counts(normalize=True).to_dict()
            encoding_state[f"freq__{col}"] = freq_map
        else:
            freq_map = encoding_state.get(f"freq__{col}", {})
        new_col = col + "_freq"
        df[new_col] = df[col].map(freq_map).fillna(0).astype(float)
        df = df.drop(columns=[col])

    # 4. Ordinal / as-is columns — no transformation needed

    return df, encoding_state


# =============================================================================
# STEP E — SCALING
# =============================================================================

def apply_scaling(df, scalers, fit):
    """
    Scale numeric columns.

    Three groups, each with its own fitted scaler:
        SCALE_ROBUST   → RobustScaler  (dollar amounts, lag days)
        SCALE_STANDARD → StandardScaler (payer metrics)
        SCALE_MINMAX   → MinMaxScaler  (columns needing [0, 1] bounds)

    fit=True  : fit and transform (training data)
    fit=False : transform only (test data)
    """
    from sklearn.preprocessing import MinMaxScaler, RobustScaler, StandardScaler

    groups = [
        (config.SCALE_ROBUST,   "robust",   RobustScaler()),
        (config.SCALE_STANDARD, "standard", StandardScaler()),
        (config.SCALE_MINMAX,   "minmax",   MinMaxScaler()),
    ]

    for col_list, name, template in groups:
        if not col_list:
            continue
        present = [c for c in col_list if c in df.columns]
        missing = [c for c in col_list if c not in df.columns]
        if missing:
            logger.warning("Scaling (%s): columns not found — %s", name, missing)
        if not present:
            continue

        if fit:
            scaler = template
            df[present] = scaler.fit_transform(df[present])
            scalers[name] = scaler
        else:
            scaler = scalers.get(name)
            if scaler is not None:
                df[present] = scaler.transform(df[present])

    return df, scalers


# =============================================================================
# SAVE OUTPUTS
# =============================================================================

def save_preprocessed(train_df, test_df):
    print("\nStep F: Save preprocessed datasets")

    os.makedirs(config.PREPROCESSED_DATA_DIR, exist_ok=True)

    train_df.to_excel(config.TRAIN_PREPROCESSED_FILE, index=False, engine="openpyxl")
    test_df.to_excel(config.TEST_PREPROCESSED_FILE,   index=False, engine="openpyxl")

    print(f"  Train saved : {config.TRAIN_PREPROCESSED_FILE}  ({train_df.shape[0]:,} rows x {train_df.shape[1]} cols)")
    print(f"  Test  saved : {config.TEST_PREPROCESSED_FILE}  ({test_df.shape[0]:,} rows x {test_df.shape[1]} cols)")


def save_bundle(fill_values, encoding_state, scalers):
    print("\nStep G: Save preprocessing bundle")

    os.makedirs(config.PKL_DIR, exist_ok=True)

    bundle = {
        "fill_values":    fill_values,
        "encoding_state": encoding_state,
        "scalers":        scalers,
    }
    joblib.dump(bundle, config.PREPROCESSING_BUNDLE_PKL)
    print(f"  Bundle saved : {config.PREPROCESSING_BUNDLE_PKL}")


# =============================================================================
# MAIN ORCHESTRATOR
# =============================================================================

def run():
    """
    Run the full preprocessing pipeline on both the train and test ADS files.

    All imputers, encoder maps, and scalers are fitted on training data only.
    The same fitted objects are then applied to the test data.
    """
    logger.info("Stage 6 - Preprocessing started.")
    logger.info("INPUT  train : %s", config.TRAIN_ADS_FILE)
    logger.info("INPUT  test  : %s", config.TEST_ADS_FILE)
    logger.info("OUTPUT train : %s", config.TRAIN_PREPROCESSED_FILE)
    logger.info("OUTPUT test  : %s", config.TEST_PREPROCESSED_FILE)
    logger.info("Impute zero   columns: %s", ", ".join(config.IMPUTE_ZERO))
    logger.info("Impute median columns: %s", ", ".join(config.IMPUTE_MEDIAN))
    logger.info("OHE columns         : %s", ", ".join(config.OHE_COLUMNS))
    logger.info("RobustScaler columns: %s", ", ".join(config.SCALE_ROBUST))
    logger.info("StandardScaler cols : %s", ", ".join(config.SCALE_STANDARD))

    train_df = load_ads(config.TRAIN_ADS_FILE, "train")
    test_df  = load_ads(config.TEST_ADS_FILE,  "test")

    fill_values    = {}
    encoding_state = {}
    scalers        = {}

    # ---------------------------------------------------------------
    # TRAINING SPLIT — fit all preprocessing steps on train, then transform
    # ---------------------------------------------------------------
    print("\n" + "=" * 60)
    print("TRAINING SPLIT — fit and transform")
    print("=" * 60)

    train_df = derive_flags(train_df)
    train_df = apply_categorical_fills(train_df)
    train_df, fill_values    = apply_numeric_imputation(train_df, fill_values,    fit=True)
    train_df, encoding_state = apply_encoding(train_df, encoding_state, fit=True)
    train_df, scalers        = apply_scaling(train_df, scalers,        fit=True)

    print(f"\n  Train after preprocessing : {train_df.shape[0]:,} rows x {train_df.shape[1]} columns")

    # ---------------------------------------------------------------
    # TEST SPLIT — apply fitted transformations only (no fitting on test)
    # ---------------------------------------------------------------
    print("\n" + "=" * 60)
    print("TEST SPLIT — transform only (using train-fitted objects)")
    print("=" * 60)

    test_df = derive_flags(test_df)
    test_df = apply_categorical_fills(test_df)
    test_df, _ = apply_numeric_imputation(test_df, fill_values,    fit=False)
    test_df, _ = apply_encoding(test_df, encoding_state, fit=False)
    test_df, _ = apply_scaling(test_df, scalers,        fit=False)

    print(f"\n  Test after preprocessing : {test_df.shape[0]:,} rows x {test_df.shape[1]} columns")

    save_preprocessed(train_df, test_df)
    save_bundle(fill_values, encoding_state, scalers)

    logger.info("Stage 6 complete. Train: %s, Test: %s", train_df.shape, test_df.shape)
    logger.info("OUTPUT train : %s | %d rows x %d cols", config.TRAIN_PREPROCESSED_FILE, train_df.shape[0], train_df.shape[1])
    logger.info("OUTPUT test  : %s | %d rows x %d cols", config.TEST_PREPROCESSED_FILE,  test_df.shape[0],  test_df.shape[1])
    logger.info("Train preprocessed columns (%d): %s", len(train_df.columns), ", ".join(train_df.columns.tolist()))
    logger.info("Test  preprocessed columns (%d): %s", len(test_df.columns),  ", ".join(test_df.columns.tolist()))
    print("\nStage 6 complete.\n")


if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format="%(asctime)s  %(levelname)s  %(message)s")
    run()
