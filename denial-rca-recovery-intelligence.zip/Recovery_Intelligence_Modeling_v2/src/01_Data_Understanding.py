# 01- Data_Understanding.py
"""
Data_Understanding.py - Stage 1: Data Understanding

Purpose:
    Performs initial data understanding and profiling of the source
    dataset to identify data structure, quality issues, missing values,
    data types, and basic statistical characteristics.

Input:
    Source Excel workbook containing the raw EDI data.

Output:
    HTML profiling reports generated for each worksheet in the
    source workbook.
"""

import logging
import os
import sys

import pandas as pd

# Support both the legacy and current ydata profiling package names.
try:
    from data_profiling import ProfileReport
except ModuleNotFoundError:
    from ydata_profiling import ProfileReport

# Add project root directory to the Python path for config imports.
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import config.paths_config as paths_cfg
import config.data_source_config as src_cfg

# Initialize module-level logger.
logger = logging.getLogger(__name__)


def run() -> None:
    # Initialize Stage 1 logging and record input/output locations.
    logger.info("Stage 1 - Data Understanding started.")
    logger.info("INPUT  : %s", src_cfg.SOURCE_FILE_PATH)
    logger.info("OUTPUT : %s", paths_cfg.DATA_UNDERSTANDING_DIR)

    # Create the output directory if it does not already exist.
    os.makedirs(paths_cfg.DATA_UNDERSTANDING_DIR, exist_ok=True)

    print(f"Input  : {src_cfg.SOURCE_FILE_PATH}")
    print(f"Output : {paths_cfg.DATA_UNDERSTANDING_DIR}")

    # Read the workbook metadata to identify all available sheets.
    xls = pd.ExcelFile(src_cfg.SOURCE_FILE_PATH)
    logger.info("Sheets found in workbook: %s", xls.sheet_names)

    # Generate a profiling report for each sheet in the source workbook.
    for sheet in xls.sheet_names:
        print(f"\nProfiling: {sheet}")

        # Load the current sheet into a DataFrame for profiling.
        df = pd.read_excel(src_cfg.SOURCE_FILE_PATH, sheet_name=sheet)
        print(f"  Shape: {df.shape[0]:,} rows x {df.shape[1]} columns")

        # Log sheet dimensions and column names for traceability.
        logger.info(
            "Sheet: %-30s | %d rows x %d cols",
            sheet, df.shape[0], df.shape[1],
        )
        logger.info("Columns (%d): %s", len(df.columns), ", ".join(df.columns.tolist()))

        # Use minimal profiling to avoid expensive pairwise plots on wide EDI sheets.
        profile = ProfileReport(df, title=f"{sheet} - Data Understanding", minimal=True)

        # Save the generated profiling report as an HTML file.
        output_file = os.path.join(paths_cfg.DATA_UNDERSTANDING_DIR, f"{sheet}.html")
        profile.to_file(output_file)

        print(f"  Saved: {output_file}")
        logger.info("OUTPUT : %s", output_file)

    print(f"\nAll reports saved to: {paths_cfg.DATA_UNDERSTANDING_DIR}")
    logger.info("Stage 1 - Data Understanding complete. %d HTML reports written.", len(xls.sheet_names))


if __name__ == "__main__":
    # Configure logging when the script is executed directly.
    logging.basicConfig(level=logging.INFO, format="%(asctime)s  %(levelname)s  %(message)s")
    run()
