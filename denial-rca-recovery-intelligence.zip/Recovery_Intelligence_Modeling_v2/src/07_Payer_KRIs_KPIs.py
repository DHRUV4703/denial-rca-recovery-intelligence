# 07- Payer_KRIs_KPIs.py
"""
Payer_KRIs_KPIs.py - KRI (KRI-1..4) and KPI (KPI-01..05) Features

Called by feature_engineering.py (orchestrator).
Leakage-safe: computed on TRAINING split only, applied to test via payer_id LEFT JOIN.
"""

import os
import sys

import joblib
import numpy as np
import pandas as pd

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import config.feature_engineering_config as config
from cpt_family_lookup import get_lookup_func, scrape_in_memory, scrape_and_save

import logging
logger = logging.getLogger(__name__)

# ==============================================================================
# KRI FUNCTIONS (KRI-1 to KRI-4)
# ==============================================================================
def find_pci(
    df: pd.DataFrame,
    pci_thresh: float = 0.40,
    conf_thresh: float = 0.80,
) -> pd.DataFrame:

# ==============================================================================
# KRI-1 - Policy Concentration Index (PCI)
# ==============================================================================
    # Keep only denied claims and ensure each claim is counted once.
    denied = df[df["claim_denial_flag"] == 1].drop_duplicates("claim_id")

    # Calculate total denied dollars for each payer.
    payer_total = denied.groupby("payer_id")["billed_charge"].sum()

    # Calculate denied dollars by payer and CARC code.
    by_group = (
        denied.groupby(["payer_id", "carc_code"])["billed_charge"]
        .sum().reset_index(name="group_dollars")
    )

    # Map each payer's total denial dollars and calculate the PCI.
    by_group["total_denial_dollars"] = by_group["payer_id"].map(payer_total)
    by_group["pci"] = by_group["group_dollars"] / by_group["total_denial_dollars"]

    # Select the CARC code with the highest concentration for each payer.
    pci_df = (
        by_group.sort_values("pci", ascending=False)
        .drop_duplicates("payer_id")
        .rename(columns={"carc_code": "dominant_carc"})
        .reset_index(drop=True)
    )

    # Calculate confidence based on PCI strength and denial volume.
    def conf(row: pd.Series) -> float:
        c1 = min(row["pci"], 1.0)
        c2 = min(
            (row["pci"] - pci_thresh) / max(1.0 - pci_thresh, 1e-9), 1.0
        ) if row["pci"] > pci_thresh else 0.0
        c3 = min(row["total_denial_dollars"] / 50000, 1.0)
        c4 = 0.1 if row["pci"] > pci_thresh else 0.0
        return round(min(c1*0.4 + c2*0.3 + c3*0.2 + c4, 1.0), 4)

    # Apply confidence scoring and determine the PCI flag.
    pci_df["pciconfidence"] = pci_df.apply(conf, axis=1)
    pci_df["pci_flag"] = (
        (pci_df["pci"] > pci_thresh) &
        (pci_df["pciconfidence"] >= conf_thresh)
    ).astype(int)

    return pci_df

def find_fcr(
    df: pd.DataFrame,
    cpt_family_lookup: dict,
    fcr_thresh: float = 0.60,
    conf_thresh: float = 0.80,
) -> pd.DataFrame:

# ==============================================================================
# KRI-2 - Family Capture Ratio (FCR)
# ==============================================================================
    # Create a working copy and map each CPT code to its family.
    lines = df.copy()
    lines["cpt_family"] = lines["billed_cpt"].astype(str).map(cpt_family_lookup)

    # Calculate total billed dollars by payer and CPT family.
    total = (
        lines.groupby(["payer_id", "cpt_family"])["billed_charge"]
        .sum().rename("total_dollars")
    )

    # Calculate denied billed dollars by payer and CPT family.
    denied = (
        lines[lines["line_denied_flag"] == 1]
        .groupby(["payer_id", "cpt_family"])["billed_charge"]
        .sum().rename("denied_dollars")
    )

    # Combine total and denied amounts and calculate FCR.
    family = pd.concat([total, denied], axis=1).fillna(0).reset_index()
    family["fcr"] = family["denied_dollars"] / family["total_dollars"]

    # Select the CPT family with the highest FCR for each payer.
    fcr_df = (
        family.sort_values("fcr", ascending=False)
        .drop_duplicates("payer_id")
        .rename(columns={"cpt_family": "captured_family"})
        .reset_index(drop=True)
    )

    # Calculate confidence based on FCR strength and total dollar volume.
    def conf(row: pd.Series) -> float:
        c1 = min(row["fcr"], 1.0)
        c2 = min(
            (row["fcr"] - fcr_thresh) / max(1.0 - fcr_thresh, 1e-9), 1.0
        ) if row["fcr"] > fcr_thresh else 0.0
        c3 = min(row["total_dollars"] / 100000, 1.0)
        c4 = 0.1 if row["fcr"] > fcr_thresh else 0.0
        return round(min(c1*0.4 + c2*0.3 + c3*0.2 + c4, 1.0), 4)

    # Apply confidence scoring and determine the FCR flag.
    fcr_df["fcrconfidence"] = fcr_df.apply(conf, axis=1)
    fcr_df["fcr_flag"] = (
        (fcr_df["fcr"] > fcr_thresh) &
        (fcr_df["fcrconfidence"] >= conf_thresh)
    ).astype(int)

    return fcr_df

def find_cd(
    df: pd.DataFrame,
    conf_thresh: float = 0.80,
) -> pd.DataFrame:

# ==============================================================================
# KRI-3 - Contradiction Density (CD)
# ==============================================================================
    # Reduce the dataset to one record per claim.
    claims = df.drop_duplicates("claim_id")

    # Identify claims associated with a prior-authorization denial.
    mask = claims["pa_related_denial_flag"] == 1

    # Aggregate contradiction count and associated dollars by payer.
    cd_df = (
        claims[mask]
        .groupby("payer_id")
        .agg(
            cd=("claim_id", "count"),
            cd_dollars=("total_claim_charge", "sum"),
        )
        .reset_index()
    )

    # Calculate confidence based on contradiction count and dollar exposure.
    def conf(row: pd.Series) -> float:
        c1 = min(row["cd"] / 10, 1.0)
        c2 = min(row["cd_dollars"] / 100000, 1.0)
        c3 = min(row["cd"] / 5, 1.0)
        c4 = 0.1 if row["cd"] > 0 else 0.0
        return round(min(c1*0.4 + c2*0.3 + c3*0.2 + c4, 1.0), 4)

    # Apply confidence scoring and determine the CD flag.
    cd_df["cdconfidence"] = cd_df.apply(conf, axis=1)
    cd_df["cd_flag"] = (
        (cd_df["cd"] > 0) &
        (cd_df["cdconfidence"] >= conf_thresh)
    ).astype(int)

    return cd_df

def find_pbr(
    df: pd.DataFrame,
    pbr_cnt_thresh: int = 20,
    pbr_pct_thresh: float = 0.50,
    conf_thresh: float = 0.80,
) -> pd.DataFrame:

# ==============================================================================
# KRI-4 - Provider Blast Radius (PBR)
# ==============================================================================
    # Reduce the dataset to one record per claim.
    claims = df.drop_duplicates("claim_id")

    # Keep only denied claims for blast-radius analysis.
    denied = claims[claims["claim_denial_flag"] == 1]

    # Identify the dominant CARC code for each payer based on denied dollars.
    dominant = (
        denied.groupby(["payer_id", "carc_code"])["billed_charge"]
        .sum().reset_index()
        .sort_values("billed_charge", ascending=False)
        .drop_duplicates("payer_id")
        .rename(columns={"carc_code": "dominant_carc"})
        [["payer_id", "dominant_carc"]]
    )

    # Attach the dominant CARC to each denied claim.
    denied_with_dominant = denied.merge(dominant, on="payer_id")

    # Count unique providers affected by the dominant CARC for each payer.
    pbr_cnt = (
        denied_with_dominant[
            denied_with_dominant["carc_code"] ==
            denied_with_dominant["dominant_carc"]
        ]
        .groupby(["payer_id", "dominant_carc"])["provider_id"]
        .nunique().reset_index(name="pbr_cnt")
    )

    # Calculate the total number of providers associated with each payer.
    total_providers = (
        claims.groupby("payer_id")["provider_id"]
        .nunique().reset_index(name="total_providers")
    )

    # Combine affected and total provider counts and calculate the PBR percentage.
    pbr_df = pbr_cnt.merge(total_providers, on="payer_id").reset_index(drop=True)
    pbr_df["pbr_pct"] = (
        pbr_df["pbr_cnt"] / pbr_df["total_providers"]
    ).round(4)

    # Calculate confidence based on provider count and affected percentage.
    def conf(row: pd.Series) -> float:
        c1 = min(row["pbr_cnt"] / 50, 1.0)
        c2 = min(row["pbr_pct"] / 1.0, 1.0)
        c3 = min(row["pbr_cnt"] / pbr_cnt_thresh, 1.0)
        c4 = 0.1 if row["pbr_cnt"] > pbr_cnt_thresh else 0.0
        return round(min(c1*0.4 + c2*0.3 + c3*0.2 + c4, 1.0), 4)

    # Apply confidence scoring and determine the PBR flag.
    pbr_df["pbrconfidence"] = pbr_df.apply(conf, axis=1)
    pbr_df["pbr_flag"] = (
        (pbr_df["pbr_cnt"] > pbr_cnt_thresh) &
        (pbr_df["pbr_pct"] > pbr_pct_thresh) &
        (pbr_df["pbrconfidence"] >= conf_thresh)
    ).astype(int)

    return pbr_df

# =============================================================================
# KPI FUNCTIONS (KPI-01 to KPI-05)
# =============================================================================

def find_kpi_denial_risk(
    df: pd.DataFrame,
    act_run_thresh: int = 3,
    watch_jump_pp: float = 3.0,
    conf_thresh: float = 0.80,
) -> pd.DataFrame:
    
# =============================================================================
# KPI-01 - QoQ Denial Risk
# =============================================================================
    # Prepare one record per claim and derive the claim quarter.
    claims = df.drop_duplicates("claim_id").copy()
    claims["quarter_date"] = claims["claim_adjudication_date"].fillna(claims["service_date"])
    claims["quarter"] = claims["quarter_date"].dt.to_period("Q")

    # Calculate total claims and denied claims by payer and quarter.
    qtr = (
        claims.groupby(["payer_id", "quarter"])
              .agg(n_claims=("claim_id", "size"), n_denied=("claim_denial_flag", "sum"))
              .reset_index()
    )
    qtr["denial_rate"] = qtr["n_denied"] / qtr["n_claims"]

    rows = []

    # Evaluate denial-rate trends independently for each payer.
    for payer, g in qtr.groupby("payer_id"):
        g = g.sort_values("quarter")
        rates = g["denial_rate"].values

        # Identify the longest consecutive run of increasing denial rates.
        max_run, run = 0, 0
        for i in range(1, len(rates)):
            if rates[i] > rates[i - 1]:
                run += 1; max_run = max(max_run, run)
            else:
                run = 0

        # Calculate quarter-over-quarter denial-rate changes.
        diffs = [rates[i] - rates[i - 1] for i in range(1, len(rates))]
        max_jump = max(diffs) if diffs else 0

        # Assign the risk band based on sustained increases and rate jumps.
        band = "Act" if max_run >= act_run_thresh else (
            "Watch" if max_jump > watch_jump_pp / 100 else "Good"
        )

        # Calculate confidence from trend strength, jump size, and data history.
        c1 = min(max_run / 5, 1.0)
        c2 = min(max_jump / 0.10, 1.0)
        c3 = min(len(g) / 8, 1.0)
        c4 = 0.1 if band == "Act" else 0.0
        confidence = round(min(c1*0.4 + c2*0.3 + c3*0.2 + c4, 1.0), 4)

        # Store the payer-level KPI result.
        rows.append(dict(
            payer_id=payer,
            kpi01_latest_denial_rate=round(rates[-1], 4),
            kpi01_max_consecutive_rising=max_run,
            kpi01_band=band,
            kpi01confidence=confidence,
            kpi01_flag=int(band == "Act" and confidence >= conf_thresh),
        ))

    return pd.DataFrame(rows)


def find_kpi_recovery_rate(
    df: pd.DataFrame,
    act_win_thresh: float = 0.40,
    watch_recovery_thresh: float = 0.25,
    conf_thresh: float = 0.80,
) -> pd.DataFrame:
    
# =============================================================================
# KPI-02 - Recovery Rate
# =============================================================================
    # Prepare one record per claim for recovery analysis.
    claims = df.drop_duplicates("claim_id").copy()
    rows = []

    # Calculate recovery performance independently for each payer.
    for payer, g in claims.groupby("payer_id"):
        n_denied = len(g[g["claim_denial_flag"] == 1])

        # Identify successfully recovered and unsuccessful resubmitted claims.
        won = g[(g["terminal_status_277"] == "F1") & (g["is_resubmitted"] == 1)]
        lost = g[(g["terminal_status_277"] == "F2") & (g["is_resubmitted"] == 1)]

        n_won, n_lost = len(won), len(lost)

        # Calculate recovery rate and win rate.
        recovery_rate = n_won / n_denied if n_denied > 0 else 0
        win_rate = n_won / (n_won + n_lost) if (n_won + n_lost) > 0 else 0

        # Assign the risk band based on recovery and win-rate thresholds.
        band = "Act" if win_rate < act_win_thresh else (
            "Watch" if win_rate >= 0.50 and recovery_rate < watch_recovery_thresh else "Good"
        )

        # Calculate confidence based on win-rate gap, recovery rate, and volume.
        c1 = min(
            (act_win_thresh - win_rate) / act_win_thresh, 1.0
        ) if win_rate < act_win_thresh else 0.0
        c2 = min(1.0 - recovery_rate, 1.0)
        c3 = min(n_denied / 50, 1.0)
        c4 = 0.1 if band == "Act" else 0.0
        confidence = round(min(c1*0.4 + c2*0.3 + c3*0.2 + c4, 1.0), 4)

        # Store the payer-level KPI result.
        rows.append(dict(
            payer_id=payer,
            kpi02_win_rate=round(win_rate, 4),
            kpi02_recovery_rate=round(recovery_rate, 4),
            kpi02_band=band,
            kpi02confidence=confidence,
            kpi02_flag=int(band == "Act" and confidence >= conf_thresh),
        ))

    return pd.DataFrame(rows)


def find_kpi_resub_rate(
    df: pd.DataFrame,
    watch_resub_thresh: float = 0.30,
    conf_thresh: float = 0.80,
) -> pd.DataFrame:

# =============================================================================
# KPI-03 - Resubmission Rate
# =============================================================================
    # Prepare one record per claim for resubmission analysis.
    claims = df.drop_duplicates("claim_id").copy()
    rows = []

    # Calculate resubmission metrics independently for each payer.
    for payer, g in claims.groupby("payer_id"):
        n_total = len(g)
        resub = g[g["is_resubmitted"] == 1]
        n_resub = len(resub)

        # Calculate the overall resubmission rate.
        resub_rate = n_resub / n_total if n_total > 0 else 0

        # Count resubmitted claims that have not received payment when available.
        n_never_paid = (
            int((resub["payment_received"] == 0).sum())
            if "payment_received" in resub.columns else 0
        )

        # Assign the risk band based on the resubmission threshold.
        band = "Watch" if resub_rate >= watch_resub_thresh else "Good"

        # Calculate confidence based on resubmission rate and claim volume.
        c1 = min(
            (resub_rate - watch_resub_thresh) /
            max(1.0 - watch_resub_thresh, 1e-9), 1.0
        ) if resub_rate >= watch_resub_thresh else 0.0
        c2 = min(n_resub / 50, 1.0)
        c3 = min(n_never_paid / max(n_resub, 1), 1.0)
        c4 = 0.1 if band == "Watch" else 0.0
        confidence = round(min(c1*0.4 + c2*0.3 + c3*0.2 + c4, 1.0), 4)

        # Store the payer-level KPI result.
        rows.append(dict(
            payer_id=payer,
            kpi03_resub_rate=round(resub_rate, 4),
            kpi03_band=band,
            kpi03confidence=confidence,
            kpi03_flag=int(band == "Watch" and confidence >= conf_thresh),
        ))

    return pd.DataFrame(rows)


def find_kpi_ttp(
    df: pd.DataFrame,
    act_days: int = 30,
    watch_days: int = 24,
    conf_thresh: float = 0.80,
) -> pd.DataFrame:

# =============================================================================
# KPI-04 - Time-to-Pay
# =============================================================================
    # Prepare one record per claim for payment-time analysis.
    claims = df.drop_duplicates("claim_id").copy()
    rows = []

    # Calculate time-to-pay metrics independently for each payer.
    for payer, g in claims.groupby("payer_id"):

        # Skip the payer when required payment fields are unavailable.
        if "payment_received" not in g.columns or "time_to_payment_days" not in g.columns:
            continue

        # Keep paid claims with a valid time-to-payment value.
        paid = g[g["payment_received"] == 1].dropna(subset=["time_to_payment_days"])
        median_days = paid["time_to_payment_days"].median()
        median_val = median_days if pd.notna(median_days) else 0.0

        # Assign the risk band based on median payment days.
        band = (
            "Act" if pd.notna(median_days) and median_days > act_days else
            "Watch" if pd.notna(median_days) and median_days > watch_days else "Good"
        )

        # Calculate confidence based on payment delay and paid-claim volume.
        c1 = min((median_val - act_days) / act_days, 1.0) if median_val > act_days else 0.0
        c2 = min(median_val / (act_days * 2), 1.0)
        c3 = min(len(paid) / 50, 1.0)
        c4 = 0.1 if band == "Act" else 0.0
        confidence = round(min(c1*0.4 + c2*0.3 + c3*0.2 + c4, 1.0), 4)

        # Store the payer-level KPI result.
        rows.append(dict(
            payer_id=payer,
            kpi04_median_days=round(median_val, 2),
            kpi04_band=band,
            kpi04confidence=confidence,
            kpi04_flag=int(band == "Act" and confidence >= conf_thresh),
        ))

    return pd.DataFrame(rows)


def find_kpi_bvp_gap(df: pd.DataFrame) -> pd.DataFrame:

# =============================================================================
# KPI-05 - Billed-vs-Paid Gap (informational only, never flagged)
# =============================================================================
    # Prepare one record per claim for billed-versus-paid analysis.
    claims = df.drop_duplicates("claim_id").copy()
    rows = []

    # Calculate billed and paid amounts independently for each payer.
    for payer, g in claims.groupby("payer_id"):
        total_billed = g["total_claim_charge"].sum()
        total_paid = g["claim_total_paid"].sum() if "claim_total_paid" in g.columns else 0

        # Calculate the percentage gap between billed and paid amounts.
        gap_pct = (
            (total_billed - total_paid) / total_billed
            if total_billed > 0 else 0
        )

        # KPI-05 is informational and is never flagged.
        rows.append(dict(
            payer_id=payer,
            kpi05_gap_pct=round(gap_pct, 4),
            kpi05_band="Info",
            kpi05_flag=0,
        ))

    return pd.DataFrame(rows)

# =============================================================================
# WRAPPER — add_kri_kpi_features
# =============================================================================

def add_kri_kpi_features(
    train_df: pd.DataFrame,
    test_df: pd.DataFrame,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """
    Step 15 — KRI / KPI Features (KRI-1..4, KPI-01..05).
    Computed on TRAINING split only; applied to test via payer_id LEFT JOIN.
    """

    # Use the configured payer identifier for all KRI/KPI lookups.
    PAYER_ID = config.PAYER_ID_COL

    # Map project-specific column names to the standardized KRI/KPI input names.
    rename_in = {
        config.CLAIM_CONTROL_NUMBER_COL: "claim_id",
        "denial_flag_beh":               "claim_denial_flag",
        "denial_flag":                   "line_denied_flag",
        "post_approved_then_denied":     "pa_related_denial_flag",
        config.PROCEDURE_CODE_COL:       "billed_cpt",
        config.BILLING_PROVIDER_COL:     "provider_id",
        config.FINAL_STATUS_DATE_COL:    "claim_adjudication_date",
        config.SUBMISSION_DATE_COL:      "submission_date",
        config.PAYMENT_DATE_COL:         "payment_date",
        "claim_final_status":            "terminal_status_277",
        "resubmission_indicator":        "is_resubmitted",
        config.TOTAL_PAID_AMOUNT_COL:    "claim_total_paid",
    }

    # Retain only mappings for columns available in the training dataset.
    rename_in = {k: v for k, v in rename_in.items() if k in train_df.columns}
    work = train_df.rename(columns=rename_in)

    # Standardize billed charge for KRI calculations.
    if config.TOTAL_CLAIM_CHARGE_COL in work.columns:
        work["billed_charge"] = work[config.TOTAL_CLAIM_CHARGE_COL]

    # Derive a binary payment-received indicator when payment data is available.
    if "claim_total_paid" in work.columns:
        work["payment_received"] = (work["claim_total_paid"] > 0).astype(int)

    # Derive time-to-payment in days when it is not already present.
    if "time_to_payment_days" not in work.columns:
        if "payment_date" in work.columns and "submission_date" in work.columns:
            work["time_to_payment_days"] = (
                pd.to_datetime(work["payment_date"],      errors="coerce")
                - pd.to_datetime(work["submission_date"], errors="coerce")
            ).dt.days

    print("\nStep 15: KRI / KPI features (train — computing KRI-1..4, KPI-01..05)")

    # Build the CPT-family lookup used by KRI-2.
    # Use a cached CSV when available so the scraper only runs once.
    _SRC_DIR   = os.path.dirname(os.path.abspath(__file__))
    _CACHE_CSV = os.path.join(_SRC_DIR, "..", "output", "medical_code_ranges.csv")
    _CACHE_CSV = os.path.normpath(_CACHE_CSV)

    if os.path.exists(_CACHE_CSV):
        print(f"  CPT family lookup — using cached CSV: {_CACHE_CSV}")
        cpt_lookup = get_lookup_func(ranges_csv_path=_CACHE_CSV)
    else:
        print("  CPT family lookup — running AAPC scraper (this happens once)…")
        try:
            scrape_and_save(_CACHE_CSV)
            cpt_lookup = get_lookup_func(ranges_csv_path=_CACHE_CSV)
            print(f"  CPT family lookup — scraped and cached to: {_CACHE_CSV}")
        except Exception as _scrape_err:
            logger.warning("CPT scraper failed (%s) — falling back to 2-char prefix.", _scrape_err)
            print(f"  CPT family lookup — scraper failed ({_scrape_err}); using 2-char prefix fallback.")
            cpt_lookup = get_lookup_func()

    # Compute all KRI and KPI payer-level metrics using training data.
    p_kri1 = find_pci(work)
    p_kri2 = find_fcr(work, cpt_lookup)
    p_kri3 = find_cd(work)
    p_kri4 = find_pbr(work)
    p_kpi1 = find_kpi_denial_risk(work)
    p_kpi2 = find_kpi_recovery_rate(work)
    p_kpi3 = find_kpi_resub_rate(work)
    p_kpi4 = find_kpi_ttp(work)
    p_kpi5 = find_kpi_bvp_gap(work)

    # Report the number of payers evaluated for each KRI/KPI.
    print(
        f"  KRI-1 PCI: {len(p_kri1)} payers | KRI-2 FCR: {len(p_kri2)} payers | "
        f"KRI-3 CD: {len(p_kri3)} payers | KRI-4 PBR: {len(p_kri4)} payers"
    )
    print(f"  KPI-01..05 scored for {len(p_kpi1)} payers")

    logger.info(
        "KRI/KPI computed — KRI-1:%d KRI-2:%d KRI-3:%d KRI-4:%d payers; KPI-01..05:%d payers.",
        len(p_kri1), len(p_kri2), len(p_kri3), len(p_kri4), len(p_kpi1)
    )

    # Define payer-level lookup tables and their final feature names.
    payer_lookups = [
        (p_kri1, {"group_dollars": "kri1_carc_denied_dollars", "pci": "kri1_carc_denial_share", "pci_flag": "kri1_pci_flag"}),
        (p_kri2, {"total_dollars": "kri2_family_total_dollars", "denied_dollars": "kri2_family_denied_dollars", "fcr": "kri2_fcr", "fcr_flag": "kri2_fcr_flag"}),
        (p_kri3, {"cd": "kri3_cd", "cd_dollars": "kri3_cd_dollars", "cd_flag": "kri3_cd_flag"}),
        (p_kri4, {"pbr_cnt": "kri4_pbr_cnt", "pbr_pct": "kri4_pbr_pct", "pbr_flag": "kri4_pbr_flag"}),
        (p_kpi1, {"kpi01_latest_denial_rate": "kpi01_latest_denial_rate", "kpi01_max_consecutive_rising": "kpi01_max_consecutive_rising", "kpi01_band": "kpi01_band", "kpi01_flag": "kpi01_flag"}),
        (p_kpi2, {"kpi02_win_rate": "kpi02_win_rate", "kpi02_recovery_rate": "kpi02_recovery_rate", "kpi02_band": "kpi02_band", "kpi02_flag": "kpi02_flag"}),
        (p_kpi3, {"kpi03_resub_rate": "kpi03_resub_rate", "kpi03_band": "kpi03_band", "kpi03_flag": "kpi03_flag"}),
        (p_kpi4, {"kpi04_median_days": "kpi04_median_days", "kpi04_band": "kpi04_band", "kpi04_flag": "kpi04_flag"}),
        (p_kpi5, {"kpi05_gap_pct": "kpi05_gap_pct", "kpi05_band": "kpi05_band", "kpi05_flag": "kpi05_flag"}),
    ]

    # Identify all generated KRI/KPI columns and categorize flag/band columns.
    all_final_cols = [c for _, rename_map in payer_lookups for c in rename_map.values()]
    flag_cols = {c for c in all_final_cols if c.endswith("_flag")}
    band_cols = {c for c in all_final_cols if c.endswith("_band")}

    def apply(target_df: pd.DataFrame) -> pd.DataFrame:
        # Apply each payer-level lookup to the target dataset using a left join.
        for pdf, rename_map in payer_lookups:
            if pdf is None or pdf.empty:
                continue

            # Select only source columns required for the current lookup.
            src_cols = [c for c in rename_map if c in pdf.columns]
            if not src_cols:
                continue

            # Keep one lookup record per payer and rename output columns.
            lookup = (
                pdf[[PAYER_ID] + src_cols]
                .drop_duplicates(PAYER_ID)
                .rename(columns=rename_map)
            )

            # Merge payer-level KRI/KPI features onto the target dataset.
            target_df = target_df.merge(lookup, on=PAYER_ID, how="left")

            # Apply appropriate defaults based on the feature type.
            for final_col in rename_map.values():
                if final_col not in target_df.columns:
                    continue

                if final_col in flag_cols:
                    target_df[final_col] = target_df[final_col].fillna(0).astype(int)

                elif final_col in band_cols:
                    default_band = "Info" if final_col == "kpi05_band" else "Good"
                    target_df[final_col] = target_df[final_col].fillna(default_band)

                else:
                    fill = lookup[final_col].median()
                    target_df[final_col] = target_df[final_col].fillna(
                        fill if pd.notna(fill) else 0.0
                    )

        return target_df

    # Apply training-derived payer features to the training dataset.
    train_df = apply(train_df)

    print("Step 15: KRI / KPI features (test — applying train payer tables)")

    # Apply the same payer-level lookup tables to the test dataset.
    test_df = apply(test_df)

    # Count the KRI/KPI columns successfully added to each dataset.
    n_train = sum(1 for c in all_final_cols if c in train_df.columns)
    n_test = sum(1 for c in all_final_cols if c in test_df.columns)

    print(f"  {n_train} KRI/KPI columns added to train, {n_test} applied to test.")
    logger.info(
        "KRI/KPI applied — %d columns on train, %d columns on test.",
        n_train, n_test
    )

    # Define fallback values for any missing KRI/KPI columns.
    KRI_KPI_DEFAULTS = {
        "kri1_carc_denied_dollars": 0.0, "kri1_carc_denial_share": 0.0, "kri1_pci_flag": 0,
        "kri2_family_total_dollars": 0.0, "kri2_family_denied_dollars": 0.0, "kri2_fcr": 0.0, "kri2_fcr_flag": 0,
        "kri3_cd": 0, "kri3_cd_dollars": 0.0, "kri3_cd_flag": 0,
        "kri4_pbr_cnt": 0, "kri4_pbr_pct": 0.0, "kri4_pbr_flag": 0,
        "kpi01_latest_denial_rate": 0.0, "kpi01_max_consecutive_rising": 0, "kpi01_band": "Good", "kpi01_flag": 0,
        "kpi02_win_rate": 0.0, "kpi02_recovery_rate": 0.0, "kpi02_band": "Good", "kpi02_flag": 0,
        "kpi03_resub_rate": 0.0, "kpi03_band": "Good", "kpi03_flag": 0,
        "kpi04_median_days": 0.0, "kpi04_band": "Good", "kpi04_flag": 0,
        "kpi05_gap_pct": 0.0, "kpi05_band": "Info", "kpi05_flag": 0,
    }

    # Ensure all expected KRI/KPI columns exist in both datasets.
    for col, default in KRI_KPI_DEFAULTS.items():
        if col not in train_df.columns:
            train_df[col] = default
        if col not in test_df.columns:
            test_df[col] = default

    print("  [DONE] add_kri_kpi_features — KRI-1..4 and KPI-01..05 complete.")
    logger.info(
        "add_kri_kpi_features complete — train %s | test %s.",
        train_df.shape, test_df.shape
    )

    return train_df, test_df

