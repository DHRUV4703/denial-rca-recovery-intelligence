# 02- Data_Merging.py

"""
data_merging.py - Stage 2: Data Merging

Loads the three EDI source sheets (837, 277, 835) from the configured input
Excel file, removes duplicate columns, collapses the 277 to one row per claim,
adds a submission type label, merges all three tables, and writes the merged
Analytic Data Set to output/claims_ads_merged.xlsx.

Steps:
    0.  Load 837, 277, 835 from config.DATA_FILE
    1.  Sort each table by date
    2.  Drop duplicate columns (keep 837 copy as authoritative source)
    3.  Collapse 277 to one row per claim
    4.  Add submission_type label to 837
    5.  Merge 837 + 277 (claim level)
    6.  Merge + 835 (claim + service line level)
    7.  Derive initial_outcome  (first-pass adjudication result)
    8.  Derive final_outcome    (payment across all passes)
    9.  Derive recovery_status  (Recovered / Not Recovered / First Paid)
    10. Derive recovery_method  (Resubmission / Appeal)
    11. Dedup corrected submissions for already-paid lines
    12. Drop temp columns
    13. Write merged ADS to config.MERGED_ADS_FILE
    14. Validation summary

Input  : data/healthcare_claims_edi_1.xlsx  (three sheets: 837, 277, 835)
Output : output/claims_ads_merged.xlsx
Grain  : one row per claim + service line + adjudication pass
"""

import logging
import os
import sys

import numpy as np
import pandas as pd

# Add project root directory to the Python path for config import.
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import config.merge_config as config

# Initialize module-level logger.
logger = logging.getLogger(__name__)


def run() -> None:
    logger.info("Stage 2 - Data Merging started.")
    logger.info("INPUT  : %s", config.DATA_FILE)
    logger.info("OUTPUT : %s", config.MERGED_ADS_FILE)

    print(f"Input  : {config.DATA_FILE}")
    print(f"Output : {config.MERGED_ADS_FILE}")

    # Validate that the configured input workbook exists before processing.
    if not os.path.exists(config.DATA_FILE):
        raise FileNotFoundError(
            f"Input file not found:\n  {config.DATA_FILE}\n"
            f"Place the EDI Excel workbook in the data\\ folder."
        )

    # STEP 0 - LOAD
    print("\nStep 0: Load")

    # Load the 837, 277, and 835 EDI data from their respective sheets.
    df_837 = pd.read_excel(config.DATA_FILE, sheet_name=config.SHEET_837)
    df_277 = pd.read_excel(config.DATA_FILE, sheet_name=config.SHEET_277)
    df_835 = pd.read_excel(config.DATA_FILE, sheet_name=config.SHEET_835)

    print(f"837 rows : {len(df_837):,}   cols : {len(df_837.columns)}")
    print(f"277 rows : {len(df_277):,}   cols : {len(df_277.columns)}")
    print(f"835 rows : {len(df_835):,}   cols : {len(df_835.columns)}")

    # Log source dataset dimensions and columns for traceability.
    logger.info("Sheet 837 loaded | %d rows x %d cols | Columns: %s",
                len(df_837), len(df_837.columns), ", ".join(df_837.columns.tolist()))
    logger.info("Sheet 277 loaded | %d rows x %d cols | Columns: %s",
                len(df_277), len(df_277.columns), ", ".join(df_277.columns.tolist()))
    logger.info("Sheet 835 loaded | %d rows x %d cols | Columns: %s",
                len(df_835), len(df_835.columns), ", ".join(df_835.columns.tolist()))

    # STEP 1 - SORT
    print("\nStep 1: Sort")

    # Sort each EDI dataset by its claim identifier and relevant date fields
    # to establish the required processing order.
    df_837 = df_837.sort_values([config.CLAIM_CONTROL_NUMBER_COL, config.SUBMISSION_DATE_COL, config.CLAIM_LINE_NUMBER_COL])
    df_277 = df_277.sort_values([config.CLAIM_CONTROL_NUMBER_COL, "claim_status_effective_date"])
    df_835 = df_835.sort_values([config.CLAIM_CONTROL_NUMBER_COL, config.CLAIM_LINE_NUMBER_COL, config.PAYMENT_DATE_COL])
    print("  Sorted 837 / 277 / 835.")

    # STEP 2 - DROP DUPLICATE COLUMNS
    # Rule: the 837 copy is authoritative — remove duplicates from 277 / 835.
    print("\nStep 2: Drop duplicate columns")

    # Remove duplicate fields from 277 and 835 while retaining the 837 fields
    # as the authoritative source for overlapping columns.
    df_277 = df_277.drop(columns=[c for c in config.COLS_DROP_FROM_277 if c in df_277.columns])
    df_835 = df_835.drop(columns=[c for c in config.COLS_DROP_FROM_835 if c in df_835.columns])

    print(f"837 cols : {len(df_837.columns)}")
    print(f"277 cols after drop : {len(df_277.columns)}")
    print(f"835 cols after drop : {len(df_835.columns)}")

    # STEP 3 - COLLAPSE 277 TO ONE ROW PER CLAIM
    # Keep: last status category, last status date, appeal event flag,
    #       last value of all other 277 columns.
    print("\nStep 3: Collapse 277 to one row per claim")

    # Capture the final claim status from the latest 277 record.
    final_status = (
        df_277
        .groupby(config.CLAIM_CONTROL_NUMBER_COL)["claim_status_category_code"]
        .last()
        .reset_index()
        .rename(columns={"claim_status_category_code": "claim_final_status"})
    )

    # Capture the effective date associated with the final claim status.
    final_status_date = (
        df_277
        .groupby(config.CLAIM_CONTROL_NUMBER_COL)["claim_status_effective_date"]
        .last()
        .reset_index()
        .rename(columns={"claim_status_effective_date": config.FINAL_STATUS_DATE_COL})
    )

    # Identify all remaining 277 columns that should retain their latest value.
    other_277_cols = [
        c for c in df_277.columns
        if c not in [config.CLAIM_CONTROL_NUMBER_COL, "claim_status_category_code",
                     "claim_status_effective_date"]
    ]

    # Collapse the 277 data to one record per claim and append final status
    # and final status date information.
    df_277_summary = (
        df_277
        .groupby(config.CLAIM_CONTROL_NUMBER_COL)[other_277_cols]
        .last()
        .reset_index()
        .merge(final_status,      on=config.CLAIM_CONTROL_NUMBER_COL, how="left")
        .merge(final_status_date, on=config.CLAIM_CONTROL_NUMBER_COL, how="left")
    )

    print(f"277 summary : {len(df_277_summary):,} rows, {len(df_277_summary.columns)} cols")

    # STEP 4 - ADD SUBMISSION TYPE LABEL TO 837
    print("\nStep 4: Add submission_type")

    # Map claim frequency codes to their corresponding submission type.
    df_837["submission_type"] = (
        df_837["claim_frequency_code"]
        .map(config.CLAIM_FREQ_SUBMISSION_TYPE_MAP)
        .fillna("Other")
    )
    print(f"  submission_type distribution:\n"
          f"  {df_837['submission_type'].value_counts().to_dict()}")

    # STEP 5 - MERGE 837 + 277  (claim level)
    print("\nStep 5: Merge 837 + 277")

    # Join claim-level 277 information to the 837 submission data.
    claim = df_837.merge(df_277_summary, on=config.CLAIM_CONTROL_NUMBER_COL, how="left")
    print(f"After 837 + 277 : {len(claim):,} rows, {len(claim.columns)} cols")
    logger.info("STEP 5 — 837+277 merge | %d rows x %d cols | Key: %s",
                len(claim), len(claim.columns), config.CLAIM_CONTROL_NUMBER_COL)

    # STEP 6 - MERGE + 835  (claim + service line level)
    print("\nStep 6: Merge + 835")

    # Join payment/remittance information at claim + service-line level.
    claim = claim.merge(df_835, on=[config.CLAIM_CONTROL_NUMBER_COL, config.CLAIM_LINE_NUMBER_COL], how="left")
    print(f"After + 835     : {len(claim):,} rows, {len(claim.columns)} cols")
    logger.info("STEP 6 — +835 merge    | %d rows x %d cols | Keys: %s, %s",
                len(claim), len(claim.columns),
                config.CLAIM_CONTROL_NUMBER_COL, config.CLAIM_LINE_NUMBER_COL)

    # STEP 7 - DERIVE initial_outcome
    # Rank 835 rows by payment_effective_date within each claim+service-line.
    # Pass 1 = first adjudication.  A denial GROUP code on pass 1 means the
    # claim was initially denied; no denial GROUP = paid on first submission.
    print("\nStep 7: Derive initial_outcome")

    # Ensure line_paid_amount is numeric and null-safe before aggregation.
    if "line_paid_amount" in claim.columns:
        claim["line_paid_amount"] = pd.to_numeric(claim["line_paid_amount"], errors="coerce").fillna(0)

    # Sort payment records so the first record represents the first adjudication
    # pass for each claim and service line.
    claim = claim.sort_values(
        [config.CLAIM_CONTROL_NUMBER_COL, config.CLAIM_LINE_NUMBER_COL, config.PAYMENT_DATE_COL],
        na_position="last",
    ).reset_index(drop=True)

    # Assign a sequential pass number within each claim and service line.
    claim["pass_rank"] = (
        claim.groupby([config.CLAIM_CONTROL_NUMBER_COL, config.CLAIM_LINE_NUMBER_COL]).cumcount() + 1
    )

    # Select the first submission record for each claim and service line.
    first_pass = (
        claim.loc[
            (claim["pass_rank"] == 1) & (claim["submission_type"] == config.CLAIM_FREQ_SUBMISSION_TYPE_MAP[1]),
            [config.CLAIM_CONTROL_NUMBER_COL, config.CLAIM_LINE_NUMBER_COL, config.GROUP_COL, "line_paid_amount"],
        ]
        .copy()
    )

    # Determine whether the first adjudication resulted in payment or denial.
    first_pass[config.INITIAL_OUTCOME_COL] = np.where(
        first_pass["line_paid_amount"] > 0,
        config.CLAIM_PAID_LABEL,
        config.CLAIM_DENIED_LABEL,
    )

    # Merge the first-pass outcome back into the complete claim dataset.
    claim = claim.merge(
        first_pass[[config.CLAIM_CONTROL_NUMBER_COL, config.CLAIM_LINE_NUMBER_COL, config.INITIAL_OUTCOME_COL]],
        on=[config.CLAIM_CONTROL_NUMBER_COL, config.CLAIM_LINE_NUMBER_COL],
        how="left",
    )

    # Corrected-only claims (no original submission in data) get NaN after the merge.
    # A corrected submission by definition means the original was denied — fill accordingly.
    claim[config.INITIAL_OUTCOME_COL] = claim[config.INITIAL_OUTCOME_COL].fillna(config.CLAIM_DENIED_LABEL)

    print(f"  initial_outcome : {claim[config.INITIAL_OUTCOME_COL].value_counts().to_dict()}")

    # STEP 8 - DERIVE final_outcome
    # Sum line_paid_amount across all passes per claim+service-line.
    # Paid if any pass resulted in payment; Denied otherwise.
    print("\nStep 8: Derive final_outcome")

    # Calculate the total payment received across all adjudication passes.
    claim["total_paid_all_passes"] = (
        claim.groupby([config.CLAIM_CONTROL_NUMBER_COL, config.CLAIM_LINE_NUMBER_COL])["line_paid_amount"]
             .transform("sum")
             .fillna(0)
    )

    # Determine the final outcome based on whether any payment was received.
    claim[config.FINAL_OUTCOME_COL] = np.where(
        claim["total_paid_all_passes"] > 0, config.CLAIM_PAID_LABEL, config.CLAIM_DENIED_LABEL
    )
    print(f"  final_outcome   : {claim[config.FINAL_OUTCOME_COL].value_counts().to_dict()}")

    # STEP 9 - DERIVE recovery_status
    #   Recovered     — initially denied, eventually paid
    #   Not Recovered — initially denied, never paid
    #   First Paid    — paid on first submission (no denial, no corrected resubmission)
    print("\nStep 9: Derive recovery_status")

    # Classify each record according to the initial outcome and eventual payment.
    claim[config.TARGET_COLUMN] = np.select(
        [
            (claim[config.INITIAL_OUTCOME_COL] == config.CLAIM_DENIED_LABEL) & (claim["total_paid_all_passes"] > 0),
            (claim[config.INITIAL_OUTCOME_COL] == config.CLAIM_DENIED_LABEL) & (claim["total_paid_all_passes"] == 0),
            # Corrected submissions (claim_frequency_code=7) that were paid are recoveries
            # by definition — the original was denied, then resubmitted and paid.
            (claim["submission_type"] == config.CORRECTED_SUBMISSION_LABEL) & (claim["total_paid_all_passes"] > 0),
        ],
        [config.TARGET_NAMES[1], config.TARGET_NAMES[0], config.TARGET_NAMES[1]],
        default=config.FIRST_PAID_LABEL,
    )
    print(f"  recovery_status : {claim[config.TARGET_COLUMN].value_counts().to_dict()}")

    # STEP 10 - DERIVE recovery_method
    # For Recovered claims: Resubmission if a Corrected submission resulted in
    # payment on any pass; Appeal if the original claim was reconsidered without
    # a corrected resubmission.
    print("\nStep 10: Derive recovery_method")

    # Identify claim/service-line combinations containing a corrected submission.
    claim["resub_paid_on_any_pass"] = (
        claim.groupby([config.CLAIM_CONTROL_NUMBER_COL, config.CLAIM_LINE_NUMBER_COL])["submission_type"]
             .transform(lambda x: (x == config.CORRECTED_SUBMISSION_LABEL).any())
    )

    # Assign the recovery method for recovered claims.
    claim[config.RECOVERY_METHOD_COL] = np.select(
        [
            (claim[config.TARGET_COLUMN] == config.TARGET_NAMES[1]) & claim["resub_paid_on_any_pass"],
            (claim[config.TARGET_COLUMN] == config.TARGET_NAMES[1]) & ~claim["resub_paid_on_any_pass"],
        ],
        [config.RECOVERY_METHOD_RESUBMISSION, config.RECOVERY_METHOD_APPEAL],
        default=None,
    )
    print(f"  recovery_method : {claim[config.RECOVERY_METHOD_COL].value_counts(dropna=False).to_dict()}")

    # STEP 11 - DEDUP CORRECTED SUBMISSIONS FOR ALREADY-PAID LINES
    # A corrected/void submission filed after an original claim was already paid
    # creates a redundant row.  Remove rows where a prior pass already resulted
    # in payment AND the current row is a zero-payment Corrected or Void submission.
    print("\nStep 11: Dedup corrected submissions")

    rows_before = len(claim)

    # Sort records by claim, service line, and adjudication pass before identifying
    # whether a payment occurred on a previous pass.
    claim = claim.sort_values(
        [config.CLAIM_CONTROL_NUMBER_COL, config.CLAIM_LINE_NUMBER_COL, "pass_rank"]
    ).copy()

    # Determine whether a payment was recorded on any preceding pass.
    claim["prior_paid"] = (
        claim.groupby([config.CLAIM_CONTROL_NUMBER_COL, config.CLAIM_LINE_NUMBER_COL])["line_paid_amount"]
             .transform(lambda x: x.shift(1).expanding().sum().fillna(0)) > 0
    )

    # Retain records that are not redundant corrected/void submissions following
    # an already-paid claim line.
    dedup_mask = ~(
        claim["prior_paid"]
        & claim["submission_type"].isin(config.DEDUP_SUBMISSION_TYPES)
        & (claim["line_paid_amount"] == 0)
    )
    claim = claim[dedup_mask].reset_index(drop=True)

    print(f"  Removed {rows_before - len(claim):,} redundant corrected-submission rows.")
    print(f"  Shape  : {claim.shape[0]:,} rows x {claim.shape[1]} columns")

    # STEP 12 - DROP TEMP COLUMNS
    print("\nStep 12: Drop temp columns")

    # Remove intermediate columns used only during outcome and deduplication logic.
    temp_cols = ["pass_rank", "prior_paid", "resub_paid_on_any_pass", "total_paid_all_passes"]
    claim.drop(columns=[c for c in temp_cols if c in claim.columns], inplace=True)

    # STEP 12a - EXCLUDE FIRST PAID RECORDS
    # Claims paid on first submission are not modelling targets; remove them
    # before saving so all downstream stages only see denied claims.
    print("\nStep 12a: Exclude First Paid records")

    rows_before = len(claim)

    # Retain only claims that were initially denied and therefore require
    # downstream recovery analysis.
    claim = claim[claim[config.TARGET_COLUMN] != config.FIRST_PAID_LABEL].reset_index(drop=True)

    print(f"  Removed {rows_before - len(claim):,} First Paid rows.")
    print(f"  Remaining : {len(claim):,} rows")
    print(f"  recovery_status : {claim[config.TARGET_COLUMN].value_counts().to_dict()}")

    # STEP 13 - WRITE OUTPUT
    # Cast mixed-type object columns to string before writing to Excel.
    print("\nStep 13: Write output")

    # Convert object columns to strings to ensure consistent Excel output.
    for col in claim.select_dtypes(include="object").columns:
        claim[col] = claim[col].astype(str).replace("nan", "")

    # Create the output directory if required and write the merged ADS.
    os.makedirs(os.path.dirname(config.MERGED_ADS_FILE), exist_ok=True)
    claim.to_excel(config.MERGED_ADS_FILE, index=False, engine="openpyxl")

    print(f"Saved : {config.MERGED_ADS_FILE}")
    print(f"Shape : {claim.shape[0]:,} rows x {claim.shape[1]} columns")

    # STEP 14 - VALIDATION SUMMARY
    print("\nStep 14: Validation summary")

    # Validate the number of unique claim and service-line combinations.
    uniq = claim.drop_duplicates([config.CLAIM_CONTROL_NUMBER_COL, config.CLAIM_LINE_NUMBER_COL])
    print(f"  Unique claim+line combinations : {len(uniq):,}")

    # Display value distributions for key derived outcome columns.
    for col in [config.INITIAL_OUTCOME_COL, config.FINAL_OUTCOME_COL, config.TARGET_COLUMN, config.RECOVERY_METHOD_COL]:
        if col in claim.columns:
            print(f"\n  {col}:")
            for val, cnt in claim[col].value_counts(dropna=False).items():
                print(f"    {str(val):<25} : {cnt:,}")

    # Record final output details and key derived fields for traceability.
    logger.info("OUTPUT : %s | %d rows x %d cols", config.MERGED_ADS_FILE, claim.shape[0], claim.shape[1])
    logger.info("Columns (%d): %s", len(claim.columns), ", ".join(claim.columns.tolist()))
    logger.info("Derived columns: initial_outcome, final_outcome, recovery_status, recovery_method")
    logger.info("Stage 2 complete. Merged shape: %s", claim.shape)

    print("\nStage 2 complete.\n")


if __name__ == "__main__":
    # Configure logging when the script is executed directly.
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s  %(levelname)s  %(message)s",
        datefmt="%H:%M:%S",
    )
    run()
