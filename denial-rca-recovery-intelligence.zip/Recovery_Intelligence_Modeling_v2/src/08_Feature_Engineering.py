# 08- Feature_Engineering.py
"""
feature_engineering.py - Stage 5: Feature Engineering (Orchestrator)

Reads the cleaned train and test splits from Stage 4, runs all feature
engineering modules in sequence, and saves two ADS files.

Flow:
    Raw Data
       ↓
    feature_engineering_basic      (Steps 1-9: temporal, lifecycle, financial,
                                    field flags, denial codes, clinical,
                                    claim status, auth/PA flags, line detail)
       ↓
    feature_engineering_behaviors  (B01-B12 Payer Behaviors + EBS E01-E03)
       ↓
    feature_engineering_kpi_kri    (KRI-1..4 + KPI-01..05)
       ↓
    Final Feature Dataset (train_ads.xlsx, test_ads.xlsx)

Leakage-safe design:
  - Payer behaviour signals (B01-B12), Early Behavioral Signals (E01-E03),
    and KRI/KPI metrics are computed from the TRAINING split only. Per-payer
    lookup tables are applied to the test split via payer_id LEFT JOIN.
    Test rows for unseen payers get 0 for flags and the training median for
    continuous signals.

Input  : output/Cleaned_Data/train_cleaned.xlsx
         output/Cleaned_Data/test_cleaned.xlsx
Output : output/Feature_Engineered_Data/train_ads.xlsx
         output/Feature_Engineered_Data/test_ads.xlsx
"""

import importlib
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import config.feature_engineering_config as config

# These sibling modules are numbered (e.g. "05_Basic_Features.py"), so their
# module names start with a digit and cannot be loaded with a normal
# `from ... import ...` statement (invalid Python syntax) — importlib is used
# to load them, and the needed functions are pulled off the module objects.
_basic     = importlib.import_module("05_Basic_Features")
_behaviors = importlib.import_module("06_Payer_Behaviours")
_kpi_kri   = importlib.import_module("07_Payer_KRIs_KPIs")

load_data                    = _basic.load_data
add_temporal_features        = _basic.add_temporal_features
add_lifecycle_count_features = _basic.add_lifecycle_count_features
add_financial_features       = _basic.add_financial_features
add_field_presence_flags     = _basic.add_field_presence_flags
add_denial_code_features     = _basic.add_denial_code_features
add_clinical_features        = _basic.add_clinical_features
add_claim_status_flags       = _basic.add_claim_status_flags
add_auth_and_pa_flags        = _basic.add_auth_and_pa_flags
add_line_detail_flags        = _basic.add_line_detail_flags
save_ads                     = _basic.save_ads

add_payer_behaviour_features = _behaviors.add_payer_behaviour_features
add_early_signal_features    = _behaviors.add_early_signal_features

add_kri_kpi_features = _kpi_kri.add_kri_kpi_features

import logging
logger = logging.getLogger(__name__)


# =============================================================================
# MAIN ORCHESTRATOR
# =============================================================================

def run():
    """
    Run the full feature engineering pipeline on both the train and test splits.

    Steps 1-9 are applied identically to both splits (no fitting needed).
    Payer behaviour (B01-B12), Early Signals (E01-E03), and KRI/KPI are
    computed on TRAIN only, then applied to TEST via payer_id lookup tables.
    """
    print("\n" + "=" * 60)
    print("STAGE 5 — FEATURE ENGINEERING STARTED")
    print("=" * 60)
    logger.info("Stage 5 - Feature Engineering started.")
    logger.info("INPUT  train : %s", config.TRAIN_CLEANED_FILE)
    logger.info("INPUT  test  : %s", config.TEST_CLEANED_FILE)
    logger.info("OUTPUT train : %s", config.TRAIN_ADS_FILE)
    logger.info("OUTPUT test  : %s", config.TEST_ADS_FILE)

    # Load both splits
    train_df = load_data(config.TRAIN_CLEANED_FILE, "train")
    test_df  = load_data(config.TEST_CLEANED_FILE,  "test")
    print(f"  [OK] Data loaded — train: {train_df.shape[0]:,} rows | test: {test_df.shape[0]:,} rows")
    logger.info("Data loaded — train %s | test %s", train_df.shape, test_df.shape)

# ------------------------------------------------------------------
# TRAINING SPLIT — Basic feature engineering (Steps 1-9)
# ------------------------------------------------------------------
    print("\n" + "=" * 60)
    print("PHASE 1 — BASIC FEATURE ENGINEERING  [TRAINING SPLIT]")
    print("=" * 60)
    logger.info("Phase 1 started — basic feature engineering (train).")

    train_df = add_temporal_features(train_df)
    print("  [OK] Step 1 — Temporal features complete.")
    logger.info("Step 1 complete — temporal features (train).")

    train_df = add_lifecycle_count_features(train_df)
    print("  [OK] Step 2 — Lifecycle count features complete.")
    logger.info("Step 2 complete — lifecycle count features (train).")

    train_df = add_financial_features(train_df)
    print("  [OK] Step 3 — Financial features complete.")
    logger.info("Step 3 complete — financial features (train).")

    train_df = add_field_presence_flags(train_df)
    print("  [OK] Step 4 — Field presence flags complete.")
    logger.info("Step 4 complete — field presence flags (train).")

    train_df = add_denial_code_features(train_df)
    print("  [OK] Step 5 — Denial code features complete.")
    logger.info("Step 5 complete — denial code features (train).")

    train_df = add_clinical_features(train_df)
    print("  [OK] Step 6 — Clinical features complete.")
    logger.info("Step 6 complete — clinical features (train).")

    train_df = add_claim_status_flags(train_df)
    print("  [OK] Step 7 — Claim status flags complete.")
    logger.info("Step 7 complete — claim status flags (train).")

    train_df = add_auth_and_pa_flags(train_df)
    print("  [OK] Step 8 — Auth and prior-auth flags complete.")
    logger.info("Step 8 complete — auth and PA flags (train).")

    train_df = add_line_detail_flags(train_df)
    print("  [OK] Step 9 — Line-level detail flags complete.")
    logger.info("Step 9 complete — line detail flags (train).")

    print(f"\n  [OK] Phase 1 (train) complete — {train_df.shape[1]} columns total.")
    logger.info("Phase 1 complete (train) — shape %s.", train_df.shape)

# ------------------------------------------------------------------
# TEST SPLIT — Basic feature engineering (Steps 1-9)
# ------------------------------------------------------------------
    print("\n" + "=" * 60)
    print("PHASE 1 — BASIC FEATURE ENGINEERING  [TEST SPLIT]")
    print("=" * 60)
    logger.info("Phase 1 started — basic feature engineering (test).")

    test_df = add_temporal_features(test_df)
    print("  [OK] Step 1 — Temporal features complete.")
    logger.info("Step 1 complete — temporal features (test).")

    test_df = add_lifecycle_count_features(test_df)
    print("  [OK] Step 2 — Lifecycle count features complete.")
    logger.info("Step 2 complete — lifecycle count features (test).")

    test_df = add_financial_features(test_df)
    print("  [OK] Step 3 — Financial features complete.")
    logger.info("Step 3 complete — financial features (test).")

    test_df = add_field_presence_flags(test_df)
    print("  [OK] Step 4 — Field presence flags complete.")
    logger.info("Step 4 complete — field presence flags (test).")

    test_df = add_denial_code_features(test_df)
    print("  [OK] Step 5 — Denial code features complete.")
    logger.info("Step 5 complete — denial code features (test).")

    test_df = add_clinical_features(test_df)
    print("  [OK] Step 6 — Clinical features complete.")
    logger.info("Step 6 complete — clinical features (test).")

    test_df = add_claim_status_flags(test_df)
    print("  [OK] Step 7 — Claim status flags complete.")
    logger.info("Step 7 complete — claim status flags (test).")

    test_df = add_auth_and_pa_flags(test_df)
    print("  [OK] Step 8 — Auth and prior-auth flags complete.")
    logger.info("Step 8 complete — auth and PA flags (test).")

    test_df = add_line_detail_flags(test_df)
    print("  [OK] Step 9 — Line-level detail flags complete.")
    logger.info("Step 9 complete — line detail flags (test).")

    print(f"\n  [OK] Phase 1 (test) complete — {test_df.shape[1]} columns total.")
    logger.info("Phase 1 complete (test) — shape %s.", test_df.shape)

# ------------------------------------------------------------------
# PHASE 2 — Payer Behaviour B01-B12
# Computed on train only; results applied to test via payer_id join.
# ------------------------------------------------------------------
    print("\n" + "=" * 60)
    print("PHASE 2 — PAYER BEHAVIOR FEATURES (B01–B12)")
    print("=" * 60)
    logger.info("Phase 2 started — payer behavior features B01-B12.")

    train_df, test_df = add_payer_behaviour_features(train_df, test_df)

    print("  [OK] Phase 2 — Payer behavior B01-B12 complete.")
    logger.info("Phase 2 complete — payer behavior B01-B12. Train shape %s | Test shape %s.",
                train_df.shape, test_df.shape)

# ------------------------------------------------------------------
# PHASE 3 — Early Signal Features E01-E03
# Computed on train only; applied to test via payer_id / (payer, CPT).
# ------------------------------------------------------------------
    print("\n" + "=" * 60)
    print("PHASE 3 — EARLY BEHAVIORAL SIGNALS (E01–E03)")
    print("=" * 60)
    logger.info("Phase 3 started — early behavioral signal features E01-E03.")

    train_df, test_df = add_early_signal_features(train_df, test_df)

    print("  [OK] Phase 3 — Early behavioral signals E01-E03 complete.")
    logger.info("Phase 3 complete — EBS E01-E03. Train shape %s | Test shape %s.",
                train_df.shape, test_df.shape)

# ------------------------------------------------------------------
# PHASE 4 — KRI / KPI Features KRI-1..4, KPI-01..05
# Computed on train only; applied to test via payer_id LEFT JOIN.
# ------------------------------------------------------------------
    print("\n" + "=" * 60)
    print("PHASE 4 — KRI / KPI FEATURES (KRI-1..4, KPI-01..05)")
    print("=" * 60)
    logger.info("Phase 4 started — KRI/KPI features KRI-1..4, KPI-01..05.")

    train_df, test_df = add_kri_kpi_features(train_df, test_df)

    print("  [OK] Phase 4 — KRI/KPI features complete.")
    logger.info("Phase 4 complete — KRI/KPI. Train shape %s | Test shape %s.",
                train_df.shape, test_df.shape)

# ------------------------------------------------------------------
# SAVE ADS
# ------------------------------------------------------------------
    print("\n" + "=" * 60)
    print("SAVING FINAL ADS FILES")
    print("=" * 60)
    logger.info("Saving ADS files.")

    save_ads(train_df, config.TRAIN_ADS_FILE, "train")
    print(f"  [OK] Train ADS saved → {config.TRAIN_ADS_FILE}")
    logger.info("Train ADS saved → %s | shape %s", config.TRAIN_ADS_FILE, train_df.shape)

    save_ads(test_df,  config.TEST_ADS_FILE,  "test")
    print(f"  [OK] Test  ADS saved → {config.TEST_ADS_FILE}")
    logger.info("Test  ADS saved → %s | shape %s", config.TEST_ADS_FILE, test_df.shape)

    print("\n" + "=" * 60)
    print("STAGE 5 — FEATURE ENGINEERING COMPLETE")
    print(f"  Train ADS : {train_df.shape[0]:,} rows x {train_df.shape[1]} columns")
    print(f"  Test  ADS : {test_df.shape[0]:,} rows x {test_df.shape[1]} columns")
    print("=" * 60)
    logger.info("Stage 5 complete. Train: %s  Test: %s", train_df.shape, test_df.shape)
    logger.info("Train ADS columns (%d): %s", len(train_df.columns), ", ".join(train_df.columns.tolist()))
    logger.info("Test  ADS columns (%d): %s", len(test_df.columns),  ", ".join(test_df.columns.tolist()))


if __name__ == "__main__":
    import logging
     # Configure logging when the script is executed directly.
    logging.basicConfig(level=logging.INFO, format="%(asctime)s  %(levelname)s  %(message)s")
    run()
