# sklearn_pipeline — sklearn-native inference packaging layer
#
# build_pipeline.py             assembles model_pipeline.joblib from trained artifacts
# feature_engineer_transformer  sklearn transformer wrapping FE (B01-B12, E01-E03)
# preprocessor_transformer      sklearn transformer wrapping preprocessing + FeatureSelector
# predictor.py                  production inference wrapper around model_pipeline.joblib
