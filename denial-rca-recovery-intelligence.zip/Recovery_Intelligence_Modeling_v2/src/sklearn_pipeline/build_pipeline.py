"""
build_pipeline.py
------------------
One-time script: assembles model_pipeline.joblib from the existing trained artifacts.

Run this ONCE after training completes (Stages 5-7 done). It reads:
    output/Model/PKL/payer_lookup_bundle.pkl   — B01-B12 + E01-E03 lookup tables
    output/Model/PKL/champion_model.pkl        — calibrated model + preprocessing state

Produces:
    output/Model/PKL/model_pipeline.joblib     — self-contained sklearn Pipeline + metadata

The saved bundle contains EVERYTHING needed for inference — no disk reads required
at predict time beyond loading model_pipeline.joblib itself.

Usage
-----
    cd Recovery_Intelligence_Modeling_v1
    python src/build_pipeline.py

Or from Python:
    from build_pipeline import build_and_save_pipeline
    build_and_save_pipeline()
"""

import os
import sys
import joblib
from sklearn.pipeline import Pipeline

HERE = os.path.dirname(os.path.abspath(__file__))
SRC  = os.path.dirname(HERE)
PROJ = os.path.dirname(SRC)
for p in (PROJ, SRC, HERE):
    if p not in sys.path:
        sys.path.insert(0, p)

import config.paths_config as paths_cfg
from feature_engineer_transformer import FeatureEngineerTransformer
from preprocessor_transformer import PreprocessorTransformer, FeatureSelector


def build_and_save_pipeline(
    payer_bundle_path=None,
    champion_model_path=None,
    output_path=None,
):
    """
    Assemble and save model_pipeline.joblib.

    Parameters
    ----------
    payer_bundle_path   : str or Path, optional. Defaults to paths_cfg.PAYER_LOOKUP_BUNDLE_PKL
    champion_model_path : str or Path, optional. Defaults to paths_cfg.CHAMPION_MODEL_PKL
    output_path         : str or Path, optional. Defaults to PKL_DIR/model_pipeline.joblib

    Returns
    -------
    dict  — the saved bundle (same object that is joblib-dumped)
    """
    payer_bundle_path   = payer_bundle_path   or paths_cfg.PAYER_LOOKUP_BUNDLE_PKL
    champion_model_path = champion_model_path or paths_cfg.CHAMPION_MODEL_PKL
    output_path         = output_path         or (paths_cfg.PKL_DIR / "model_pipeline.joblib")

    # ── 1. Load existing artifacts ─────────────────────────────────────────────
    print(f"Loading payer bundle       : {payer_bundle_path}")
    payer_bundle = joblib.load(str(payer_bundle_path))

    print(f"Loading champion model     : {champion_model_path}")
    champion = joblib.load(str(champion_model_path))

    # ── 2. Build FeatureEngineerTransformer from payer lookup tables ───────────
    fe = FeatureEngineerTransformer()
    fe.payer_behaviour_lookups_    = payer_bundle.get("payer_behaviour_lookups", [])
    fe.early_signal_payer_lookups_ = payer_bundle.get("early_signal_payer_lookups", [])
    fe.cpt_drift_    = payer_bundle.get("cpt_drift")
    fe.at_risk_      = payer_bundle.get("at_risk")
    fe.top_family_   = payer_bundle.get("top_family")
    fe.payer_id_col_ = payer_bundle.get("payer_id_col", "payer_id")
    fe.cpt_col_      = payer_bundle.get("cpt_col",      "procedure_code")

    # ── 3. Build PreprocessorTransformer from champion bundle ──────────────────
    pp = PreprocessorTransformer()
    pp.fill_values_    = champion["fill_values"]
    pp.encoding_state_ = champion["encoding_state"]
    pp.scalers_        = champion["scalers"]

    # ── 4. Build FeatureSelector ───────────────────────────────────────────────
    feature_names = champion.get("feature_names") or champion.get("selected_features", [])
    selector = FeatureSelector(feature_names)

    # ── 5. Assemble sklearn Pipeline ───────────────────────────────────────────
    pipeline = Pipeline([
        ("feature_engineer", fe),
        ("preprocessor",     pp),
        ("feature_selector", selector),
        ("model",            champion["calibrated_model"]),
    ])

    # ── 6. Wrap in a bundle dict so metadata travels with the pipeline ─────────
    bundle = {
        "pipeline":          pipeline,          # full sklearn Pipeline (FE → PP → FS → model)
        "optimal_threshold": champion.get("optimal_threshold", 0.5),
        "label_lookup":      champion.get("label_lookup", {1: "Recovered", 0: "Not Recovered"}),
        "champion_name":     champion.get("champion_name", "unknown"),
        "feature_names":     feature_names,
    }

    # ── 7. Save ────────────────────────────────────────────────────────────────
    os.makedirs(str(paths_cfg.PKL_DIR), exist_ok=True)
    joblib.dump(bundle, str(output_path))
    print(f"model_pipeline.joblib saved: {output_path}")
    print(f"  Champion      : {bundle['champion_name']}")
    print(f"  Threshold     : {bundle['optimal_threshold']:.4f}")
    print(f"  Feature count : {len(feature_names)}")

    return bundle


if __name__ == "__main__":
    build_and_save_pipeline()
