"""
preprocessor_transformer.py
-----------------------------
Sklearn-compatible transformers for Stage 6 preprocessing and feature selection.

Classes:
    PreprocessorTransformer  — wraps apply_numeric_imputation / apply_encoding /
                               apply_scaling with a fit/transform interface.
    FeatureSelector          — selects (and zero-fills missing) MODEL_FEATURES
                               columns before the model step.
"""

import importlib
import os
import sys
import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin

HERE = os.path.dirname(os.path.abspath(__file__))
SRC  = os.path.dirname(HERE)
PROJ = os.path.dirname(SRC)
for p in (PROJ, SRC, HERE):
    if p not in sys.path:
        sys.path.insert(0, p)

# "09_Data_Preprocessing.py" starts with a digit, so it cannot be loaded with
# a normal `import` statement (invalid Python syntax) — use importlib instead.
pp = importlib.import_module("09_Data_Preprocessing")   # Stage 6 functions in src/


# =============================================================================
# PreprocessorTransformer
# =============================================================================

class PreprocessorTransformer(BaseEstimator, TransformerMixin):
    """
    Sklearn-compatible preprocessing transformer.

    fit(X_train)  — learns imputation values, OHE categories, frequency maps,
                    and scaler parameters from training data only.
    transform(X)  — applies frozen parameters to X (test / production data).
    fit_transform — inherited.

    Learned attributes:
        fill_values_     : dict — medians, means, fitted KNN/MICE imputers
        encoding_state_  : dict — OHE category lists, frequency maps
        scalers_         : dict — fitted RobustScaler, StandardScaler, MinMaxScaler
    """

    def __init__(self):
        self.fill_values_    = {}
        self.encoding_state_ = {}
        self.scalers_        = {}

    def fit(self, X: pd.DataFrame, y=None):
        """Fit imputers, encoders, and scalers on training data X."""
        df = X.copy()
        df = pp.derive_flags(df)
        df = pp.apply_categorical_fills(df)

        # Each call with fit=True computes AND applies the transformation.
        # We store the learned parameters and ignore the transformed output here
        # (transform() will re-apply them correctly on any future data).
        df, self.fill_values_    = pp.apply_numeric_imputation(df, {},          fit=True)
        df, self.encoding_state_ = pp.apply_encoding(df,          {},          fit=True)
        _,  self.scalers_        = pp.apply_scaling(df,           {},          fit=True)

        return self

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        """Apply frozen preprocessing parameters to X."""
        df = X.copy()
        df = pp.derive_flags(df)
        df = pp.apply_categorical_fills(df)
        df, _ = pp.apply_numeric_imputation(df, self.fill_values_,    fit=False)
        df, _ = pp.apply_encoding(df,           self.encoding_state_, fit=False)
        df, _ = pp.apply_scaling(df,            self.scalers_,        fit=False)
        return df


# =============================================================================
# FeatureSelector
# =============================================================================

class FeatureSelector(BaseEstimator, TransformerMixin):
    """
    Selects a fixed list of feature columns, zero-filling any that are missing.

    This is the bridge between the preprocessing output (many columns) and
    the model input (MODEL_FEATURES only). It never learns anything from data —
    fit() is a no-op. It is stateless except for the feature list set at init.

    Parameters
    ----------
    feature_names : list[str]
        Exact column names the model was trained on, in order.
    """

    def __init__(self, feature_names: list):
        self.feature_names = feature_names

    def fit(self, X, y=None):
        return self

    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        df = X.copy()
        for feat in self.feature_names:
            if feat not in df.columns:
                df[feat] = 0
        return df[self.feature_names]
