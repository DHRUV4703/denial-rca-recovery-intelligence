"""
predictor.py
-------------
Self-contained production inference interface for the Recovery Intelligence pipeline.

Load once, call predict() for every claim. No re-loading between calls.

Usage
-----
    from predictor import RecoveryPredictor

    predictor = RecoveryPredictor("output/Model/PKL/model_pipeline.joblib")

    result = predictor.predict(raw_merged_df)

Output
------
    Single row  → dict
    {
        "predicted_class":   "Recovered",    # or "Not Recovered"
        "probability":        0.8742,         # P(Recovered), respects optimal_threshold
        "shap_top_features": {"b02_flag": 0.23, "e01_line_drift": -0.14, ...}
                              # top-5 SHAP drivers; None if shap not installed
    }

    Multiple rows → list[dict]

Agent Pipeline Integration
--------------------------
    # In your agent, replace predict_with_class / explain with:
    from predictor import RecoveryPredictor

    _predictor = None
    def get_predictor():
        global _predictor
        if _predictor is None:
            _predictor = RecoveryPredictor("path/to/model_pipeline.joblib")
        return _predictor

    def score_claim_line(merged_row: dict) -> tuple:
        result = get_predictor().predict(pd.DataFrame([merged_row]))
        return result["probability"], result["predicted_class"], result["shap_top_features"]

Requirements
------------
    pandas, numpy, scikit-learn, joblib
    shap (optional — SHAP drivers silently absent if not installed)

sys.path
--------
    The sklearn Pipeline inside model_pipeline.joblib references
    FeatureEngineerTransformer, PreprocessorTransformer, and FeatureSelector.
    Ensure src/ of the ML pipeline is on sys.path before loading:
        sys.path.insert(0, "/path/to/Recovery_Intelligence_Modeling_v1/src")
"""

import os
import sys
import json
import warnings
import numpy as np
import pandas as pd
import joblib

HERE = os.path.dirname(os.path.abspath(__file__))
SRC  = os.path.dirname(HERE)
PROJ = os.path.dirname(SRC)
for p in (PROJ, SRC, HERE):
    if p not in sys.path:
        sys.path.insert(0, p)


class RecoveryPredictor:
    """
    Production inference wrapper around model_pipeline.joblib.

    Parameters
    ----------
    pipeline_path : str
        Path to model_pipeline.joblib produced by build_pipeline.py.

    Attributes (after loading)
    --------------------------
    pipeline        : sklearn Pipeline  — FE → Preprocessor → FeatureSelector → Model
    threshold       : float             — optimal decision threshold from training
    label_lookup    : dict              — {0: "Not Recovered", 1: "Recovered"}
    champion_name   : str
    """

    # Payer behaviour (B01-B12) and early signal (E01-E03) columns produced by FE.
    PAYER_SIGNAL_COLS = [
        "b01_flag", "b01_confidence",
        "b02_flag", "b02_confidence",
        "b03_flag", "b03_confidence",
        "b04_flag", "b04_confidence",
        "b05_flag", "b05_slope_per_month", "b05_total_drift", "b05_confidence",
        "b06_flag", "b06_confidence",
        "b07_flag", "b07_confidence",
        "b08_flag", "b08_confidence",
        "b09_flag", "b09_confidence",
        "b10_flag", "b10_confidence",
        "b11_flag", "b11_confidence",
        "b12_flag", "b12_confidence",
        "e01_edv", "e01_flag", "e01_line_drift",
        "e02_pdp", "e02_confidence", "e02_flag", "e02_line_at_risk",
        "e03_sas", "e03_flag", "e03_line_anomalous",
    ]

    def __init__(self, pipeline_path: str):
        bundle = joblib.load(pipeline_path)
        self.pipeline       = bundle["pipeline"]
        self.threshold      = bundle.get("optimal_threshold", 0.5)
        self.label_lookup   = bundle.get("label_lookup", {1: "Recovered", 0: "Not Recovered"})
        self.champion_name  = bundle.get("champion_name", "unknown")
        self.feature_names  = bundle.get("feature_names", [])

    # ------------------------------------------------------------------
    # Public interface
    # ------------------------------------------------------------------

    def predict(self, raw_data: pd.DataFrame, top_k: int = 5):
        """
        Score raw merged claim data.

        Parameters
        ----------
        raw_data : pd.DataFrame
            One or more rows of raw merged data (output of data_merging.py).
            Must contain the 835/837 columns required for feature engineering:
            payer_id, procedure_code, line_paid_amount, total_claim_charge,
            submission_date, claim_final_status_date, etc.
        top_k : int
            Number of top SHAP drivers to return per row. Default 5.

        Returns
        -------
        dict (single row) or list[dict] (multiple rows)
            Keys: predicted_class, probability, shap_top_features
        """
        # ── Step 1-3: FE → Preprocessing → FeatureSelector ──────────────────
        # Capture the FE output before preprocessing so we can read back
        # denied_amount and payer/early-signal flags for the agent pipeline.
        X = raw_data.copy()
        after_fe = None
        for step_name, step in self.pipeline.steps[:-1]:   # all but "model"
            X = step.transform(X)
            if step_name == "feature_engineer":
                after_fe = X.copy()

        # ── Step 4: Predict probability ──────────────────────────────────────
        model = self.pipeline.named_steps["model"]
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            proba = model.predict_proba(X)[:, 1]      # P(Recovered)

        pred_int    = (proba >= self.threshold).astype(int)
        pred_labels = [self.label_lookup.get(int(p), str(p)) for p in pred_int]

        # ── Step 5: SHAP top-k drivers ────────────────────────────────────────
        shap_results = self.compute_shap(model, X, top_k=top_k)

        # ── Step 6: Extract FE-derived fields (denied_amount + payer signals) ─
        fe_fields = self.extract_fe_fields(after_fe, n_rows=len(proba))

        # ── Assemble output ───────────────────────────────────────────────────
        results = [
            {
                "predicted_class":   pred_labels[i],
                "probability":       round(float(proba[i]), 4),
                "shap_top_features": shap_results[i] if shap_results else None,
                "denied_amount":     fe_fields[i]["denied_amount"],
                "payer_signals":     fe_fields[i]["payer_signals"],
            }
            for i in range(len(proba))
        ]

        return results[0] if len(results) == 1 else results

    # ------------------------------------------------------------------
    # FE field extraction — reads denied_amount and payer signals
    # from the intermediate FE output (before preprocessing).
    # ------------------------------------------------------------------

    @classmethod
    def extract_fe_fields(cls, after_fe, n_rows: int) -> list:
        """
        Extract denied_amount and payer/early-signal flags from the FE output.

        Returns list of dicts (one per row):
            {"denied_amount": float|None, "payer_signals": {col: value, ...}}

        denied_amount is computed by add_financial_features() only when
        total_paid_amount is present in the input data.
        Payer behaviour (B01-B12) and early signal (E01-E03) columns are
        populated via LEFT JOIN on payer_id in FeatureEngineerTransformer.
        """
        empty = {"denied_amount": None, "payer_signals": {}}
        if after_fe is None or after_fe.empty:
            return [empty] * n_rows

        out = []
        for i in range(n_rows):
            row = after_fe.iloc[i]

            # denied_amount
            da = None
            if "denied_amount" in after_fe.columns:
                raw = row["denied_amount"]
                try:
                    fv = float(raw)
                    if not np.isnan(fv):
                        da = round(fv, 4)
                except (TypeError, ValueError):
                    pass

            # payer behaviour (B01-B12) + early signal (E01-E03)
            signals = {}
            for col in cls.PAYER_SIGNAL_COLS:
                if col not in after_fe.columns:
                    continue
                v = row[col]
                try:
                    fv = float(v)
                    if not np.isnan(fv):
                        signals[col] = round(fv, 4)
                except (TypeError, ValueError):
                    if v is not None:
                        signals[col] = bool(v) if isinstance(v, (bool, np.bool_)) else v

            out.append({"denied_amount": da, "payer_signals": signals})
        return out

    # ------------------------------------------------------------------
    # SHAP computation — non-fatal; returns [] if shap not installed
    # ------------------------------------------------------------------

    @staticmethod
    def compute_shap(model, X: pd.DataFrame, top_k: int = 5) -> list:
        """
        Compute SHAP values for each row in X.

        Tries TreeExplainer first (fast, exact for tree models), then
        LinearExplainer (for linear models), then KernelExplainer (slow,
        model-agnostic fallback).

        Returns list[dict] — one dict per row mapping feature → shap_value,
        or [] if shap is not installed or computation fails.
        """
        try:
            import shap

            def _unwrap(m, _depth=0):
                if _depth > 8:   # guard against infinite recursion
                    return m
                # CalibratedClassifierCV → _CalibratedClassifier
                if hasattr(m, "calibrated_classifiers_") and m.calibrated_classifiers_:
                    inner = getattr(m.calibrated_classifiers_[0], "estimator",
                                    m.calibrated_classifiers_[0])
                    return _unwrap(inner, _depth + 1)
                # FrozenEstimator (sklearn >= 1.6 wraps base estimators during calibration)
                if type(m).__name__ == "FrozenEstimator" and hasattr(m, "estimator"):
                    return _unwrap(m.estimator, _depth + 1)
                # VotingClassifier / BaggingClassifier — first fitted sub-estimator
                if hasattr(m, "estimators_") and isinstance(m.estimators_, list) and m.estimators_:
                    return m.estimators_[0]
                # Generic single-estimator wrapper
                if hasattr(m, "estimator"):
                    return _unwrap(m.estimator, _depth + 1)
                return m

            base       = _unwrap(model)
            feat_names = list(X.columns)
            sv         = None

            try:
                exp = shap.TreeExplainer(base)
                raw = exp.shap_values(X)
                sv  = raw[1] if isinstance(raw, list) else raw
            except Exception:
                pass

            if sv is None:
                try:
                    exp = shap.LinearExplainer(base, X)
                    sv  = exp.shap_values(X)
                except Exception:
                    pass

            if sv is None:
                try:
                    bg  = shap.kmeans(X, min(10, len(X)))
                    exp = shap.KernelExplainer(model.predict_proba, bg)
                    raw = exp.shap_values(X, nsamples=100)
                    sv  = raw[1] if isinstance(raw, list) else raw
                except Exception:
                    pass

            if sv is None:
                return []

            sv_arr  = np.array(sv)
            results = []
            for i in range(len(X)):
                row     = sv_arr[i]
                top_idx = np.argsort(np.abs(row))[::-1][:top_k]
                results.append(
                    {feat_names[j]: round(float(row[j]), 4) for j in top_idx}
                )
            return results

        except Exception:
            return []



# ------------------------------------------------------------------
# Quick smoke-test
# ------------------------------------------------------------------

if __name__ == "__main__":
    import argparse

    parser = argparse.ArgumentParser(description="Smoke-test RecoveryPredictor.")
    parser.add_argument("pipeline_path", help="Path to model_pipeline.joblib")
    parser.add_argument("--data",        help="Path to a single-row CSV for testing", default=None)
    args = parser.parse_args()

    predictor = RecoveryPredictor(args.pipeline_path)
    print(f"Loaded: {predictor.champion_name}  threshold={predictor.threshold:.4f}")

    if args.data:
        df = pd.read_csv(args.data)
        result = predictor.predict(df.iloc[[0]])
        print("Prediction:", json.dumps(result, indent=2, default=str))
