"""
feature_engineer_transformer.py
---------------------------------
Sklearn-compatible transformer wrapping all feature engineering steps.

  fit(X_train)    — learns payer-level statistics (B01-B12, E01-E03) from
                    training data only. Row-level functions are stateless so
                    they need no fitting.
  transform(X)    — applies row-level FE, then LEFT JOINs the stored payer
                    lookup tables onto X. Unseen payers get safe defaults.
  fit_transform() — inherited from TransformerMixin (calls fit then transform).

Design rule: transform() NEVER recalculates payer statistics from X.
It only uses the tables frozen at fit() time.
"""

import importlib
import os
import sys
import pandas as pd
import joblib
from sklearn.base import BaseEstimator, TransformerMixin

# Make src/ and config/ importable regardless of the working directory.
HERE = os.path.dirname(os.path.abspath(__file__))
SRC  = os.path.dirname(HERE)
PROJ = os.path.dirname(SRC)
for p in (PROJ, SRC, HERE):
    if p not in sys.path:
        sys.path.insert(0, p)

# "08_Feature_Engineering.py" starts with a digit, so it cannot be loaded with
# a normal `import` statement (invalid Python syntax) — use importlib instead.
fe = importlib.import_module("08_Feature_Engineering")   # stateless FE functions in src/
import config.paths_config as paths_cfg   # PAYER_LOOKUP_BUNDLE_PKL
import config.feature_engineering_config as fe_cfg  # PAYER_ID_COL, PROCEDURE_CODE_COL


class FeatureEngineerTransformer(BaseEstimator, TransformerMixin):
    """
    Sklearn-compatible feature engineering transformer.

    Learned attributes (populated by fit, consumed by transform):
        payer_behaviour_lookups_     : list[(payer_df, [col, ...])]  — B01-B12
        early_signal_payer_lookups_  : list[(payer_df, [col, ...])]  — E01-E03 payer level
        cpt_drift_                   : DataFrame or None  — E01 (payer_id, CPT) → e01_line_drift
        at_risk_                     : DataFrame or None  — E02 at-risk CPT set per payer
        top_family_                  : DataFrame or None  — E03 anomalous CPT family per payer
        payer_id_col_                : str  — name of the payer_id column
        cpt_col_                     : str  — name of the CPT column
    """

    def __init__(self):
        self.payer_behaviour_lookups_    = []
        self.early_signal_payer_lookups_ = []
        self.cpt_drift_   = None
        self.at_risk_     = None
        self.top_family_  = None
        self.payer_id_col_ = getattr(fe_cfg, "PAYER_ID_COL", "payer_id")
        self.cpt_col_      = getattr(fe_cfg, "PROCEDURE_CODE_COL", "procedure_code")

    # ------------------------------------------------------------------
    # fit — learn payer-level mappings from training data only
    # ------------------------------------------------------------------
    def fit(self, X: pd.DataFrame, y=None):
        """
        Compute B01-B12 and E01-E03 payer statistics from X (training data).

        Delegates to add_payer_behaviour_features() and add_early_signal_features()
        — both already implement the leakage-safe "run on train, store lookups"
        pattern. We pass an empty test DataFrame so the lookup tables are computed
        and saved without wasting time merging onto rows we don't need.
        """
        # Apply row-level FE first (B01-B12 functions expect these columns to exist).
        X_work = self.apply_row_level_fe(X.copy())

        # An empty slice of X_work gives us the right columns with 0 rows.
        empty = X_work.iloc[:0].copy()

        # B01-B12: runs on X_work, saves payer_lookup_bundle.pkl as a side effect.
        fe.add_payer_behaviour_features(X_work.copy(), empty)

        # E01-E03: updates the same bundle with early signal lookups.
        fe.add_early_signal_features(X_work.copy(), empty)

        # Load the bundle and store lookup tables as instance attributes.
        bundle = joblib.load(str(paths_cfg.PAYER_LOOKUP_BUNDLE_PKL))
        self.payer_behaviour_lookups_    = bundle.get("payer_behaviour_lookups", [])
        self.early_signal_payer_lookups_ = bundle.get("early_signal_payer_lookups", [])
        self.cpt_drift_    = bundle.get("cpt_drift")
        self.at_risk_      = bundle.get("at_risk")
        self.top_family_   = bundle.get("top_family")
        self.payer_id_col_ = bundle.get("payer_id_col", self.payer_id_col_)
        self.cpt_col_      = bundle.get("cpt_col",      self.cpt_col_)

        return self

    # ------------------------------------------------------------------
    # transform — apply stored lookups to any data (train or inference)
    # ------------------------------------------------------------------
    def transform(self, X: pd.DataFrame) -> pd.DataFrame:
        """
        Apply feature engineering to X using only the statistics frozen at fit().

        apply_row_level_fe() is called to add FE-produced columns that the
        preprocessor expects (days_to_adjudication, denial_count, field flags, etc.).
        However, columns that already exist in X (pre-computed in the ADS, e.g.
        submission_lag_days, resubmission_indicator) are restored afterwards so that
        apply_row_level_fe() cannot overwrite correct values with NaN when the
        raw source columns (claim_received_date, bht_date, etc.) are absent at
        inference time.
        """
        # Snapshot values for every column that already exists in X.
        pre_computed = {col: X[col].copy() for col in X.columns}

        # Parse date columns to datetime before FE runs.
        # During training, load_data() did this; at inference the Excel reader
        # leaves them as strings, which causes 'str - str' errors in
        # add_temporal_features() when it tries to subtract dates.
        X_work = X.copy()
        date_cols = [
            fe_cfg.SUBMISSION_DATE_COL,   # bht_date
            fe_cfg.FINAL_STATUS_DATE_COL, # claim_final_status_date
            "claim_received_date",
            "service_date",
        ]
        if hasattr(fe_cfg, "PAYMENT_DATE_COL"):
            date_cols.append(fe_cfg.PAYMENT_DATE_COL)
        for col in date_cols:
            if col in X_work.columns:
                X_work[col] = pd.to_datetime(X_work[col], errors="coerce")

        # Run row-level FE to add new columns (may overwrite some with NaN).
        df = self.apply_row_level_fe(X_work)

        # Restore pre-computed values only where the original was NOT NaN.
        # NaN originals mean the raw source column was unavailable at inference
        # time, so the FE-computed result (even if approximate) is better than NaN.
        for col, values in pre_computed.items():
            if col in df.columns:
                mask = values.notna()
                if mask.any():
                    df.loc[mask, col] = values[mask]

        df = self.apply_payer_lookups(df)
        df = self.apply_early_signal_lookups(df)
        return df

    # ------------------------------------------------------------------
    # Private helpers
    # ------------------------------------------------------------------

    @staticmethod
    def apply_row_level_fe(df: pd.DataFrame) -> pd.DataFrame:
        """Apply the nine stateless row-level FE functions in order."""
        df = fe.add_temporal_features(df)
        df = fe.add_lifecycle_count_features(df)
        df = fe.add_financial_features(df)
        df = fe.add_field_presence_flags(df)
        df = fe.add_denial_code_features(df)
        df = fe.add_clinical_features(df)
        df = fe.add_claim_status_flags(df)
        df = fe.add_auth_and_pa_flags(df)
        df = fe.add_line_detail_flags(df)
        return df

    def apply_payer_lookups(self, df: pd.DataFrame) -> pd.DataFrame:
        """LEFT JOIN B01-B12 payer tables, then re-propagate flags by claim month."""
        PAYER_ID = self.payer_id_col_
        for payer_df, cols in (self.payer_behaviour_lookups_ or []):
            if payer_df is None or payer_df.empty:
                continue
            available = [c for c in cols if c in payer_df.columns]
            if not available or PAYER_ID not in payer_df.columns:
                continue
            lookup = payer_df[[PAYER_ID] + available].drop_duplicates(PAYER_ID)
            # Drop pre-existing columns before merging to prevent _x/_y name conflicts.
            existing = [c for c in available if c in df.columns]
            if existing:
                df = df.drop(columns=existing)
            df = df.merge(lookup, on=PAYER_ID, how="left")
            for c in available:
                if c.endswith("_flag"):
                    df[c] = df[c].fillna(False)
                else:
                    fill = lookup[c].median()
                    df[c] = df[c].fillna(fill if pd.notna(fill) else 0.0)

        # Re-propagate flags using payer_id + month + year:
        # flag = 1 only for claims whose service month >= the payer's break_month.
        # B05 (OLS trend) and B12 (cross-sectional HHI) have no break_month — skip.
        _svc_col = "service_date"
        if _svc_col in df.columns:
            _claim_m = pd.to_datetime(df[_svc_col], errors="coerce").dt.to_period("M")
            for _bk, _fl in [
                ("b01_break_month", "b01_flag"),
                ("b02_break_month", "b02_flag"),
                ("b03_break_month", "b03_flag"),
                ("b04_break_month", "b04_flag"),
                ("b06_break_month", "b06_flag"),
                ("b07_break_month", "b07_flag"),
                ("b08_break_month", "b08_flag"),
                ("b09_break_month", "b09_flag"),
                ("b10_break_month", "b10_flag"),
                ("b11_break_month", "b11_flag"),
            ]:
                if _bk not in df.columns or _fl not in df.columns:
                    continue
                _bm = df[_bk].apply(
                    lambda v: v if isinstance(v, pd.Period) else pd.NaT
                )
                _has_break = _bm.notna()
                _after_break = pd.Series(False, index=df.index, dtype=bool)
                if _has_break.any():
                    _after_break[_has_break] = (
                        _claim_m[_has_break] >= _bm[_has_break]
                    )
                df[_fl] = (_has_break & _after_break).astype(int)

        return df

    def apply_early_signal_lookups(self, df: pd.DataFrame) -> pd.DataFrame:
        """LEFT JOIN E01-E03 payer-level and line-level tables."""
        PAYER_ID = self.payer_id_col_
        cpt_col  = self.cpt_col_

        # Payer-level: E01 edv/flag, E02 pdp/confidence/flag, E03 cv/sas/flag
        for payer_df, cols in (self.early_signal_payer_lookups_ or []):
            if payer_df is None or payer_df.empty:
                continue
            available = [c for c in cols if c in payer_df.columns]
            if not available or PAYER_ID not in payer_df.columns:
                continue
            lookup = payer_df[[PAYER_ID] + available].drop_duplicates(PAYER_ID)
            existing = [c for c in available if c in df.columns]
            if existing:
                df = df.drop(columns=existing)
            df = df.merge(lookup, on=PAYER_ID, how="left")
            for c in available:
                if c.endswith("_flag"):
                    df[c] = df[c].fillna(False)
                else:
                    fill = lookup[c].median()
                    df[c] = df[c].fillna(fill if pd.notna(fill) else 0.0)

        # E01 line-level: (payer_id, CPT) → e01_line_drift
        if self.cpt_drift_ is not None and not self.cpt_drift_.empty and cpt_col in df.columns:
            lookup_e01 = self.cpt_drift_.rename(columns={"billed_cpt": cpt_col})
            if "e01_line_drift" in df.columns:
                df = df.drop(columns=["e01_line_drift"])
            df = df.merge(
                lookup_e01[[PAYER_ID, cpt_col, "e01_line_drift"]],
                on=[PAYER_ID, cpt_col], how="left",
            )
            df["e01_line_drift"] = df["e01_line_drift"].fillna(0).astype(int)

        # E02 line-level: (payer_id, CPT) → e02_line_at_risk
        if self.at_risk_ is not None and not self.at_risk_.empty and cpt_col in df.columns:
            lookup_e02 = self.at_risk_.rename(columns={"billed_cpt": cpt_col}).copy()
            lookup_e02["e02_line_at_risk"] = 1
            if "e02_line_at_risk" in df.columns:
                df = df.drop(columns=["e02_line_at_risk"])
            df = df.merge(
                lookup_e02[[PAYER_ID, cpt_col, "e02_line_at_risk"]],
                on=[PAYER_ID, cpt_col], how="left",
            )
            df["e02_line_at_risk"] = df["e02_line_at_risk"].fillna(0).astype(int)

        # E03 line-level: payer_id → _top_family, then CPT[:2] match
        if self.top_family_ is not None and not self.top_family_.empty and cpt_col in df.columns:
            if "_top_family" in df.columns:
                df = df.drop(columns=["_top_family"])
            df = df.merge(
                self.top_family_[[PAYER_ID, "_top_family"]], on=PAYER_ID, how="left"
            )
            cpt_family = df[cpt_col].astype(str).str[:2]
            if "e03_line_anomalous" in df.columns:
                df = df.drop(columns=["e03_line_anomalous"])
            df["e03_line_anomalous"] = (
                cpt_family == df["_top_family"].fillna("")
            ).astype(int)
            df = df.drop(columns=["_top_family"])

        return df
