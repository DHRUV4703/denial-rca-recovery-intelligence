"""
main.py - Pipeline Entry Point

Runs the full healthcare claims ML pipeline in sequence.

Project layout:
    Recovery_Intelligence_Modeling_v1/
    ├── main.py                             <- this file (entry point)
    ├── config/
    │   ├── paths_config.py                 <- all directory and file paths
    │   ├── data_source_config.py           <- source file location and sheet names
    │   ├── merge_config.py                 <- Stage 2 column contracts
    │   ├── preprocessing_config.py         <- Stage 3 cleaning rules
    │   ├── split_config.py                 <- Stage 4 train/test split settings
    │   ├── feature_engineering_config.py   <- Stage 5 feature definitions
    │   └── modeling_config.py              <- Stage 6-7 preprocessing and model settings
    ├── src/
    │   ├── data_understanding.py           <- Stage 1 : raw data profiling
    │   ├── data_merging.py                 <- Stage 2 : merge 837 + 277 + 835
    │   ├── data_cleaning.py                <- Stage 3 : clean and type-convert
    │   ├── train_test_split.py             <- Stage 4 : stratified train/test split
    │   ├── feature_engineering.py          <- Stage 5 : build features / ADS
    │   ├── preprocessing.py                <- Stage 6 : impute / encode / scale
    │   ├── modeling.py                     <- Stage 7 : train and evaluate models
    │   └── validation.py                   <- Stage 8 : actual vs predicted report
    ├── data/
    │   └── lifecycle_claims_1.xlsx         <- raw EDI input (place file here)
    └── output/
        ├── Data_Understanding/             <- Stage 1 HTML profiling reports
        ├── Merged_Data/                    <- Stage 2 merged data
        ├── Cleaned_Data/                   <- Stage 3 cleaned + Stage 4 train/test splits
        ├── Feature_Engineered_Data/        <- Stage 5 ADS train/test splits
        ├── Preprocessed_Data/              <- Stage 6 preprocessed train/test splits
        ├── Model/
        │   ├── PKL/                        <- champion model + preprocessing bundle PKL
        │   └── Model_output/              <- predictions, metrics, CSVs
        └── logs/                           <- pipeline.log

Usage:
    python main.py
"""

import importlib
import logging
import os
import sys
import time
from datetime import datetime

for stream in (sys.stdout, sys.stderr):
    if hasattr(stream, "reconfigure"):
        stream.reconfigure(encoding="utf-8", errors="replace")

import config.paths_config as paths_cfg

# Stage modules live under src/ — add it to the module search path
sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "src"))

# Stage filenames are numbered (e.g. "01_Data_Understanding.py"), so their
# module names start with a digit and cannot be loaded with a normal `import`
# statement (invalid Python syntax) — importlib.import_module() is used instead.
data_understanding  = importlib.import_module("01_Data_Understanding")
data_merging        = importlib.import_module("02_Data_Merging")
data_cleaning       = importlib.import_module("03_Data_Cleaning")
train_test_split    = importlib.import_module("04_Train_Test_Split")
feature_engineering = importlib.import_module("08_Feature_Engineering")
preprocessing       = importlib.import_module("09_Data_Preprocessing")
modeling            = importlib.import_module("10_Modeling")
validation          = importlib.import_module("11_Validation")

# Ensure required output directories exist before logging is set up
for dir in [
    paths_cfg.OUTPUT_DIR,
    paths_cfg.CLEANED_DATA_DIR,
    paths_cfg.PREPROCESSED_DATA_DIR,
    paths_cfg.MODELS_DIR,
    paths_cfg.PREDICTIONS_DIR,
    paths_cfg.VALIDATION_DIR,
    paths_cfg.LOGS_DIR,
    paths_cfg.DATA_DIR,
]:
    os.makedirs(dir, exist_ok=True)

# Create a new timestamped log file for every pipeline run.
# Format: pipeline_YYYYMMDD_HHMMSS.log — no run ever overwrites another.
run_timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
LOG_FILE = paths_cfg.LOGS_DIR / f"pipeline_{run_timestamp}.log"

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)s  %(name)s  %(message)s",
    datefmt="%Y-%m-%d %H:%M:%S",
    handlers=[
        logging.FileHandler(LOG_FILE, mode="w", encoding="utf-8"),
        logging.StreamHandler(sys.stdout),
    ],
)
logger = logging.getLogger("main")

STAGES = [
    ("Stage 1 — Data Understanding",  data_understanding.run),
    ("Stage 2 — Data Merging",        data_merging.run),
    ("Stage 3 — Data Cleaning",       data_cleaning.run),
    ("Stage 4 — Train/Test Split",    train_test_split.run),
    ("Stage 5 — Feature Engineering", feature_engineering.run),
    ("Stage 6 — Preprocessing",       preprocessing.run),
    ("Stage 7 — Model Training",      modeling.run),
    ("Stage 8 — Validation Report",   validation.run),
]

if __name__ == "__main__":
    logger.info("=" * 70)
    logger.info("PIPELINE STARTED")
    logger.info("=" * 70)

    pipeline_start = time.perf_counter()

    for stage_name, stage_fn in STAGES:
        logger.info("Starting : %s", stage_name)
        stage_start = time.perf_counter()

        try:
            stage_fn()
        except Exception as exc:
            logger.exception("FAILED  : %s  —  %s", stage_name, exc)
            print(f"\n[PIPELINE STOPPED] {stage_name} raised an error.")
            print(f"Check the log for details: {LOG_FILE}")
            sys.exit(1)

        stage_elapsed = time.perf_counter() - stage_start
        logger.info("Done     : %s  (%.1f s)", stage_name, stage_elapsed)

    total_elapsed = time.perf_counter() - pipeline_start

    logger.info("=" * 70)
    logger.info("PIPELINE COMPLETE  —  total time : %.1f s", total_elapsed)
    logger.info("=" * 70)

    print(f"\nPIPELINE COMPLETE")
    print(f"  Total time : {total_elapsed:.1f} s")
    print(f"  Log        : {LOG_FILE}")
    print(f"  Outputs    : {paths_cfg.OUTPUT_DIR}")
