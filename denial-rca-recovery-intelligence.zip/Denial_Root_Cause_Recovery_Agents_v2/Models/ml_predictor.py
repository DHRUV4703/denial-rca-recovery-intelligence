"""
ml_predictor.py
---------------
Thin wrapper that makes RecoveryPredictor (from the ML pipeline) available
to the agent pipeline without any code duplication.

Adds Recovery_Intelligence_Modeling_v1/src to sys.path so that
FeatureEngineerTransformer, PreprocessorTransformer, and FeatureSelector
are importable when joblib reconstructs the sklearn Pipeline inside
model_pipeline.joblib.
"""

import os
import sys

HERE   = os.path.dirname(os.path.abspath(__file__))   # .../Models/
AGENT  = os.path.dirname(HERE)                        # .../Denial_Root .../
REPO   = os.path.dirname(AGENT)                       # .../PS2_Git_Code_Base_New/
ML_SRC = os.path.join(REPO, "Recovery_Intelligence_Modeling_v2", "src", "sklearn_pipeline")

if ML_SRC not in sys.path:
    sys.path.insert(0, ML_SRC)

from Config.config import ML_PIPELINE_PATH              
from predictor import RecoveryPredictor                 

singleton = None


def get_predictor() -> RecoveryPredictor:
    """Return a cached RecoveryPredictor, loading model_pipeline.joblib on first call."""
    global singleton
    if singleton is None:
        singleton = RecoveryPredictor(ML_PIPELINE_PATH)
    return singleton
