"""
vector_store.py
---------------
Builds a FAISS vector index over all ADS service lines at startup and exposes
search functions used by nba_agent to find the most similar historical lines.

How it works
------------
1. Every service line row is converted to a short plain-English text that
   describes its denial characteristics (CARC, GROUP, procedure, payer, etc.).
2. That text is encoded into a 384-dimensional dense vector using the
   all-MiniLM-L6-v2 sentence-transformer model.
3. All vectors are L2-normalised and stored in a FAISS IndexFlatIP index.
   Inner-product on L2-normalised vectors equals cosine similarity.
4. search_similar_lines() encodes the query line on-the-fly, queries the index,
   excludes lines from the same claim, and returns the top-K matches.

Both the index and the model are module-level variables so they are loaded
once at startup (main.py -> build_vector_store) and reused for every query.
"""

import numpy as np
import faiss
from sentence_transformers import SentenceTransformer

from Config.config import (
    EMBED_MODEL_NAME, SIMILARITY_TOP_K, SIMILARITY_THRESHOLD,
    RECOVERY_CHANNEL_APPEAL, RECOVERY_CHANNEL_REBILL,
)
from Utilits.logger import get_logger

logger = get_logger(__name__)

# Module-level state — populated once by build_vector_store().
index    = None   # faiss.IndexFlatIP
metadata = []     # list[dict] — one entry per indexed row
model    = None   # SentenceTransformer


def line_to_text(row: dict) -> str:
    """
    Convert a service line's key denial fields into a short descriptive text.
    Claims with similar denial patterns produce similar vectors and cluster
    close together in the index.
    """
    parts = []
    if row.get("CARC") is not None:
        parts.append(f"denial code CARC {row['CARC']}")
    rarc = row.get("RARC")
    if rarc is not None and str(rarc) not in ("nan", "None", ""):
        parts.append(f"remark code RARC {rarc}")
    if row.get("GROUP"):
        parts.append(f"adjustment group {row['GROUP']}")
    if row.get("procedure_code"):
        parts.append(f"procedure {row['procedure_code']}")
    if row.get("payer_id"):
        parts.append(f"payer {row['payer_id']}")
    if row.get("principal_diagnosis"):
        parts.append(f"diagnosis {row['principal_diagnosis']}")
    if row.get("denied_amount") is not None:
        try:
            parts.append(f"denied {abs(float(row['denied_amount'])):.0f}")
        except (TypeError, ValueError):
            pass
    if row.get("has_prior_auth") is not None:
        parts.append(f"prior auth {'yes' if row['has_prior_auth'] else 'no'}")
    if row.get("has_modifier") is not None:
        parts.append(f"modifier {'yes' if row['has_modifier'] else 'no'}")
    if row.get("has_attachment") is not None:
        parts.append(f"attachment {'yes' if row['has_attachment'] else 'no'}")
    return " | ".join(parts) if parts else "unknown line"



def build_vector_store(df) -> None:
    """
    Encode every service line in the ADS DataFrame and load them into a FAISS
    index. Called once at startup from main.py immediately after load_ads().

    Parameters
    ----------
    df : pd.DataFrame
        The full ADS DataFrame returned by data_loader.load_ads().
        Each row is one service line.
    """
    global index, metadata, model

    logger.info("Building vector store — loading embedding model %s ...", EMBED_MODEL_NAME)
    model = SentenceTransformer(EMBED_MODEL_NAME)

    texts    = []
    metadata = []

    for _, row in df.iterrows():
        row_dict = row.to_dict()
        recovery_channel = row_dict.get("recovery_channel") or row_dict.get("recovery_method")
        recovery_action  = (
            "Appeal"   if recovery_channel == RECOVERY_CHANNEL_APPEAL else
            "Resubmit" if recovery_channel == RECOVERY_CHANNEL_REBILL else
            None
        )
        metadata.append({
            "claim_id"           : row_dict.get("claim_control_number"),
            "CARC"               : row_dict.get("CARC"),
            "RARC"               : row_dict.get("RARC"),
            "procedure_code"     : row_dict.get("procedure_code"),
            "principal_diagnosis": row_dict.get("principal_diagnosis"),
            "payer_id"           : row_dict.get("payer_id"),
            "payer_name"         : row_dict.get("payer_name"),
            "outcome"            : "Recovered" if recovery_action else "Not Recovered",
            "recovery_channel"   : recovery_channel,
        })
        texts.append(line_to_text(row_dict))

    logger.info("Encoding %d service lines — this may take a few seconds ...", len(texts))
    embeddings = model.encode(
        texts,
        normalize_embeddings=True,
        show_progress_bar=False,
        batch_size=64,
    )
    embeddings = np.array(embeddings, dtype=np.float32)

    dim   = embeddings.shape[1]
    index = faiss.IndexFlatIP(dim)
    index.add(embeddings)

    logger.info(
        "Vector store ready — %d service lines indexed, embedding dim=%d.",
        len(metadata), dim,
    )


def search_similar_lines(
    query_data: dict,
    exclude_claim_id: str = "",
    top_k: int = SIMILARITY_TOP_K,
) -> list:
    """
    Return the top_k most similar historical service lines to query_data,
    ranked by cosine similarity (highest first).

    Lines belonging to exclude_claim_id (the current claim being processed)
    are excluded from results.

    Parameters
    ----------
    query_data : dict
        Key fields of the current service line (merged_row from agents.py).
    exclude_claim_id : str
        claim_control_number to exclude from results.
    top_k : int
        Number of similar lines to return.

    Returns
    -------
    list[dict]
        Each entry has line metadata fields plus "cosine_similarity".
        Returns [] if the index has not been built.
    """
    if index is None or model is None:
        logger.warning("search_similar_lines called before build_vector_store — returning [].")
        return []

    # Encode the query line on-the-fly.
    query_text = line_to_text(query_data)
    query_vec  = model.encode([query_text], normalize_embeddings=True)
    query_vec  = np.array(query_vec, dtype=np.float32)

    # Search with a generous buffer to account for excluded rows.
    buffer       = max(top_k * 3, 30)
    scores, idxs = index.search(query_vec, buffer)

    results = []
    for score, idx in zip(scores[0], idxs[0]):
        if idx < 0:
            continue
        if float(score) < SIMILARITY_THRESHOLD:
            continue
        m = metadata[idx]
        if m.get("claim_id") == exclude_claim_id:
            continue
        entry = m.copy()
        entry["cosine_similarity"] = round(float(score), 4)
        results.append(entry)
        if len(results) >= top_k:
            break

    return results

