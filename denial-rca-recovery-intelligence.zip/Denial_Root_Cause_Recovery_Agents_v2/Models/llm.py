"""
llm.py
------
Talks to the LLM (Claude by default).

The agents call ask_llm(...). Which provider/model to use is read from
Config/config.py -> get_agent_llm_config() for each agent.

For Claude, the system prompt is sent with "prompt caching" turned on: the
prompt is cached after the first call, so later calls are cheaper and faster
(as long as the prompt text stays exactly the same).

Every call's tokens and time are logged by Utilits/token_time_tracker.py.

API keys go in a .env file:
    ANTHROPIC_API_KEY, GROQ_API_KEY, GOOGLE_API_KEY, OPENAI_API_KEY

Note: all four provider packages are imported at the top. If you only use
Claude, you can delete the other three import lines and their branches below.
"""

import os
import time

from dotenv import load_dotenv, find_dotenv
from langchain_core.messages import HumanMessage, SystemMessage
from langchain_anthropic import ChatAnthropic
from langchain_groq import ChatGroq
from langchain_google_genai import ChatGoogleGenerativeAI
from langchain_openai import ChatOpenAI

from Config.config import DEFAULT_LLM, AGENTS
from Utilits.logger import get_logger
from Utilits.token_time_tracker import track_usage

load_dotenv(find_dotenv(usecwd=True) or find_dotenv())
logger = get_logger(__name__)

# We keep each LLM client we build here so we don't rebuild it on every call.
clients = {}


def get_agent_llm_config(agent_name: str) -> dict:
    """
    Return the LLM settings for one agent: {"provider", "model", "temperature"}.
    Any key the agent does not override in AGENTS falls back to DEFAULT_LLM.
    """
    agent = AGENTS.get(agent_name, {})
    llm   = agent.get("llm") or {}
    return {**DEFAULT_LLM, **llm}


def get_client(provider, model, temperature):
    """Build (or reuse) the LLM client for a provider."""
    # If we already built this exact provider+model combo before, reuse it.
    key = (provider, model)
    if key in clients:
        return clients[key]

    # Otherwise build a new client for the requested provider.
    if provider == "claude":
        api_key = os.getenv("ANTHROPIC_API_KEY")
        if not api_key:
            raise ValueError("ANTHROPIC_API_KEY is not set. Add it to your .env file.")
        client = ChatAnthropic(api_key=api_key, model=model, temperature=temperature)
    elif provider == "groq":
        api_key = os.getenv("GROQ_API_KEY")
        if not api_key:
            raise ValueError("GROQ_API_KEY is not set. Add it to your .env file.")
        client = ChatGroq(api_key=api_key, model=model, temperature=temperature)
    elif provider == "gemini":
        api_key = os.getenv("GOOGLE_API_KEY")
        if not api_key:
            raise ValueError("GOOGLE_API_KEY is not set. Add it to your .env file.")
        client = ChatGoogleGenerativeAI(google_api_key=api_key, model=model, temperature=temperature)
    elif provider == "openai":
        api_key = os.getenv("OPENAI_API_KEY")
        if not api_key:
            raise ValueError("OPENAI_API_KEY is not set. Add it to your .env file.")
        client = ChatOpenAI(api_key=api_key, model=model, temperature=temperature)
    else:
        raise ValueError(f"Unknown provider '{provider}'. Use: claude, groq, gemini, or openai.")

    # Remember this client so we don't rebuild it next time.
    clients[key] = client
    return client


def ask_llm(system_prompt, user_content, agent_name="agent"):
    """
    Send the system prompt + claim data to the agent's LLM and return the text answer.
    The provider, model, and temperature come from Config/config.py.
    """
    # Look up which provider/model/temperature this agent should use.
    cfg = get_agent_llm_config(agent_name)
    provider = cfg["provider"]
    model = cfg["model"]
    temperature = float(cfg.get("temperature", 0))

    logger.info("LLM call — agent=%s provider=%s model=%s", agent_name, provider, model)

    # For Claude, wrap the system prompt so it gets cached ("prompt caching").
    # The prompt text must be identical across calls for the cache to be reused.
    if provider == "claude":
        system_message = SystemMessage(content=[
            {"type": "text", "text": system_prompt, "cache_control": {"type": "ephemeral"}}
        ])
    else:
        system_message = SystemMessage(content=system_prompt)

    # The system prompt (instructions) plus the actual claim data go in as two messages.
    messages = [system_message, HumanMessage(content=user_content)]

    # Time the call, then log tokens + time.
    start = time.perf_counter()
    client = get_client(provider, model, temperature)
    response = client.invoke(messages)
    seconds = time.perf_counter() - start
    track_usage(response, agent_name, seconds)

    logger.info("LLM call done — agent=%s", agent_name)

    # Claude sometimes returns the answer as a list of blocks instead of a plain
    # string. If so, join the text blocks together into one string.
    content = response.content
    if isinstance(content, list):
        content = "".join(b["text"] for b in content if isinstance(b, dict) and b.get("type") == "text")

    return content
