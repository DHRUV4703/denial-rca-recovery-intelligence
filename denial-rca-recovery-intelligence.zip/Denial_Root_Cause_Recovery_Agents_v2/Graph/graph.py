"""
graph.py
--------
Wires the six agent nodes and two conditional routing helpers into a
LangGraph pipeline. All logic lives in agents.py — this file only wires.

Flow:

    decision_agent
         |
    route_after_decision
         ├─ all CO/PR ──────────────────────────────────────────────────────► nba_agent ► END
         └─ any non-CO/PR ──► ml_agent
                                   |
                              route_after_ml
                                   ├─ no RECOVERABLE ──► evidence_agent ──► nba_agent ► END
                                   └─ any RECOVERABLE ──► retrieval_agent ──► rca_agent ──► evidence_agent ──► nba_agent ► END
"""

from langgraph.graph import END, StateGraph

from Agents.agents import (
    decision_agent,
    ml_agent,
    retrieval_node,
    rca_agent,
    evidence_agent,
    nba_agent,
    route_after_decision,
    route_after_ml,
)
from State.state import ClaimState

graph = StateGraph(ClaimState)

graph.add_node("decision",   decision_agent)
graph.add_node("ml",         ml_agent)
graph.add_node("retrieval",  retrieval_node)
graph.add_node("rca",        rca_agent)
graph.add_node("evidence",   evidence_agent)
graph.add_node("nba",        nba_agent)

graph.set_entry_point("decision")

# all CO/PR → nba directly; any non-CO/PR → ml
graph.add_conditional_edges(
    "decision",
    route_after_decision,
    {"ml": "ml", "nba": "nba"},
)

# any RECOVERABLE → retrieval → rca; none RECOVERABLE → evidence
graph.add_conditional_edges(
    "ml",
    route_after_ml,
    {"retrieval": "retrieval", "evidence": "evidence"},
)

graph.add_edge("retrieval", "rca")
graph.add_edge("rca",       "evidence")
graph.add_edge("evidence",  "nba")
graph.add_edge("nba",       END)

app = graph.compile()
