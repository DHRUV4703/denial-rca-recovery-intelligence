"""
state.py
--------
Shared state that flows through all five pipeline nodes.
Each node reads from state and writes only to its own dedicated key.

Keys by node
------------
main.py (inputs)
    claim_id         -- claim control number string, e.g. "PCN0000096"
    claim            -- full claim dict from build_claims_dict():
                        {
                          "Decision"     : { GROUP, GROUP_VALUES, claim_control_number },
                          "ML"           : [ {feature_col: value}, ... ],  # one per ADS row
                          "RCA"          : { payer_name, CARC, RARC, ... },
                          "Evidence"     : { CARC, has_prior_auth, denied_amount, ... },
                          "service_lines": [
                              {
                                "line_number": int,
                                "GROUP"      : str,
                                "ML"         : { feature_col: value },
                                "RCA"        : { rca_cols },
                                "Evidence"   : { evidence_cols },
                                "raw"        : { all_cols },
                              },
                              ...
                          ],
                        }

decision_agent
    group            -- GROUP code of the first service line ("CO", "PR", "PI", "OA", …)
    group_values     -- unique GROUP codes across ALL service lines

ml_agent
    ml_results       -- one dict per non-CO/PR line:
                        {
                          "line_number"        : int,
                          "recovery_probability": float,
                          "recovery_status"    : str,   # RECOVERABLE / NOT_RECOVERABLE / EV_WRITE_OFF
                          "ev_by_action"       : dict,  # { action_name: expected_value }
                        }

retrieval_agent
    retrieval_results -- one dict per RECOVERABLE line:
                        {
                          "line_number": int,
                          "carc"       : dict | None,  # {"description": str} or None
                          "rarc"       : dict | None,
                          "cpt"        : dict | None,
                          "modifier"   : dict | None,
                        }

rca_agent
    rca_results      -- one dict per RECOVERABLE line:
                        {
                          "line_number"       : int,
                          "carc_description"  : str,
                          "rarc_description"  : str,
                          "cpt_description"   : str,
                          "root_cause_analysis": dict,  # LLM-parsed RCA output
                        }

evidence_agent
    evidence_results -- one dict per non-CO/PR line:
                        {
                          "line_number"     : int,
                          "carc_code"       : str | int,
                          "carc_description": str,
                          "rarc_code"       : str,
                          "rarc_description": str,
                          "denial_evidence" : list[str],
                          "flag_signals"    : list[str],
                          "evidence_summary": str,
                        }

nba_agent
    line_decisions   -- one full result dict per service line (all groups);
                        includes model_output, recovery_status, root_cause_analysis,
                        evidence, next_best_action, financial_impact, similar_case_summary
    claim_details    -- claim-level metadata extracted from the first non-CO/PR service line;
                        emitted once at the output root level instead of inside each line dict
"""

from typing import Optional
from typing import TypedDict


class ClaimState(TypedDict, total=False):
    claim_id          : str
    claim             : dict
    group             : Optional[str]
    group_values      : list
    ml_results        : list
    retrieval_results : list
    rca_results       : list
    evidence_results  : list
    line_decisions    : list
    claim_details     : Optional[dict]
