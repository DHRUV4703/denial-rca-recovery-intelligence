"""
main.py
-------
Run the Denial RCA pipeline.

    python main.py
    then type a claim control number, e.g.:  PCN0000018
    (comma-separate for multiple:            PCN0000018, PCN0000001)

What happens:
    1. ADS.csv is loaded and indexed by claim_control_number.
    2. The user types a claim_control_number.
    3. The claim's data is fetched and sent through the pipeline.
    4. The pipeline processes EACH service line independently
       (see Graph/graph.py and Agents/agents.py -> process_line_decisions):
         LINE GROUP = CO    -> Write Off (rule-based, no ML)
         LINE GROUP = PR    -> Bill Patient (rule-based, LLM rationale)
         LINE GROUP = other -> ML model runs per line, then:
           - Non-Recoverable (prob < threshold)  -> Write Off, evidence only
           - EV prefers Write Off                -> Write Off, evidence only
           - Recoverable and EV actionable       -> RCA + Evidence + NBA
    5. Result is printed per line and saved to outputs/<claim_id>.json.
"""

import json
import math
import os
import sys
import textwrap
from datetime import datetime

from Agents.agents import set_action_prob_table, set_payer_kri_kpi_table
from Config.config import OUTPUT_DIR
from Models.vector_store import build_vector_store
from Graph.graph import app
from State.state import ClaimState
from Utilits.data_extractor import build_claims_dict
from Utilits.data_loader import load_ads, build_action_prob_table, build_payer_kri_kpi_table
from Utilits.graph_exporter import export_graph_mermaid, export_graph_png
from Utilits.logger import get_logger, setup_pipeline_logger

# Some Windows consoles default to a legacy code page that cannot print the
# unicode arrow (->) and warning symbols used in summary() below.
# Force UTF-8 so the console output never crashes.
if hasattr(sys.stdout, "reconfigure"):
    sys.stdout.reconfigure(encoding="utf-8")

# Make sure the outputs folder exists before we try to save anything there.
os.makedirs(OUTPUT_DIR, exist_ok=True)
# Turn on logging (console + log file) for the whole run.
setup_pipeline_logger(OUTPUT_DIR)
# A logger just for messages from this file (main.py).
logger = get_logger(__name__)

# ── Load and index the ADS once at startup ──────────────────────────────────
logger.info("Loading ADS data ...")
ads_df      = load_ads()
claims_dict = build_claims_dict(ads_df)
build_vector_store(ads_df)
set_action_prob_table(build_action_prob_table(ads_df))
set_payer_kri_kpi_table(build_payer_kri_kpi_table(ads_df))
logger.info("Pipeline ready. %d claims indexed.", len(claims_dict))

# Export graph diagram to outputs/ on every startup.
mmd_path = os.path.join(OUTPUT_DIR, "agent_graph.mmd")
png_path  = os.path.join(OUTPUT_DIR, "agent_graph.png")
export_graph_mermaid(mmd_path)
export_graph_png(png_path)


def is_valid(value) -> bool:
    """Return True if a field value should appear in the output.

    Filters out: None, float NaN, empty string, the strings 'nan'/'none',
    empty dicts, and empty lists — all indicate a missing or unresolvable field.
    Numeric zero (0, 0.0) and boolean False are kept intentionally.
    """
    if value is None:
        return False
    if isinstance(value, float) and math.isnan(value):
        return False
    if isinstance(value, str) and value.strip().lower() in ("", "nan", "none"):
        return False
    if isinstance(value, dict) and not value:
        return False
    if isinstance(value, list) and not value:
        return False
    return True


def remove_empty_fields(data: dict) -> dict:
    """Recursively remove fields whose value is None, NaN, empty, or 'nan'.

    Handles nested dicts and lists of dicts so every level of the output
    JSON is clean — not just the top-level block keys.
    """
    result = {}
    for key, value in data.items():
        if not is_valid(value):
            continue
        if isinstance(value, dict):
            cleaned = remove_empty_fields(value)
            if cleaned:
                result[key] = cleaned
        elif isinstance(value, list):
            cleaned_list = [
                remove_empty_fields(item) if isinstance(item, dict) else item
                for item in value
                if is_valid(item)
            ]
            if cleaned_list:
                result[key] = cleaned_list
        else:
            result[key] = value
    return result


def run_pipeline(claim_ids: list[str]) -> None:
    """Run each claim ID through the pipeline and save one JSON file per claim."""
    for claim_id in claim_ids:

        claim = claims_dict.get(claim_id)
        if claim is None:
            logger.warning("Claim '%s' not found in ADS. Skipping.", claim_id)
            print(f"\n[!] Claim '{claim_id}' not found in ADS.\n")
            continue

        logger.info("--- Processing %s ---", claim_id)
        try:
            state: ClaimState = {"claim_id": claim_id, "claim": claim}
            result = app.invoke(state)

            # ── Build the final output dict ──────────────────────────────
            output: dict = {
                "claim_id"     : claim_id,
                "group"        : result.get("group", ""),
                "run_timestamp": datetime.now().isoformat(),
            }

            # Claim-level details (service, procedure, diagnoses) — emitted once at
            # the top level rather than repeated inside every line decision.
            cd = result.get("claim_details")
            if cd:
                output["claim_details"] = remove_empty_fields(cd)

            # Line-level decisions — one cleaned dict per service line.
            line_decisions = result.get("line_decisions", [])
            if line_decisions:
                cleaned = []
                for ld in line_decisions:
                    if isinstance(ld, dict):
                        cleaned.append(remove_empty_fields(ld))
                    elif is_valid(ld):
                        cleaned.append(ld)
                if cleaned:
                    output["line_decisions"] = cleaned

            # ── Print a human-readable summary ───────────────────────────
            summary(claim_id, output)

            # ── Save to disk ─────────────────────────────────────────────
            out_path = os.path.join(OUTPUT_DIR, f"{claim_id}.json")
            with open(out_path, "w", encoding="utf-8") as f:
                json.dump(output, f, indent=2, default=str)
            logger.info("Saved → %s", out_path)

        except Exception:
            logger.exception("Error while processing '%s'.", claim_id)


def summary(claim_id: str, output: dict) -> None:
    """Print a clean, readable per-line summary to the console."""
    sep  = "=" * 60
    dash = "-" * 56
    print(f"\n{sep}")
    print(f"  CLAIM: {claim_id}")
    print(sep)

    line_decisions = output.get("line_decisions", [])
    if not line_decisions:
        print(f"\n  No service line decisions available.\n{sep}\n")
        return

    print(f"\n  SERVICE LINE DECISIONS  ({len(line_decisions)} line(s)):")

    for ld in line_decisions:
        line_num   = ld.get("line_number", "?")
        group      = ld.get("group", "?")
        action     = ld.get("final_action", "Unknown")
        status     = ld.get("recovery_status", "")
        status_str = f"  [{status}]" if status else ""
        print(f"\n  {dash}")
        print(f"  Line {line_num}  |  Decision → {action}{status_str}")
        print(f"  {dash}")

        # CO/PR: group reason
        if ld.get("group_reason"):
            print(f"    {ld['group_reason']}")

        # Claim details — prefer top-level key, fall back to per-line (legacy)
        cd = output.get("claim_details") or ld.get("claim_details", {})
        if cd:
            print(f"\n    CLAIM DETAILS")
            print(f"      CPT     : {cd.get('procedure_code') or 'Unknown'}")
            print(f"      Dx      : {cd.get('principal_diagnosis') or 'Unknown'}")
            print(f"      Date    : {cd.get('service_date') or 'Unknown'}")

        # EV Write-Off explanation
        od = ld.get("outcome_decision", {})
        if od:
            ev_str = "  ".join(
                f"{a}=${v:,.2f}"
                for a, v in (od.get("ev_by_action") or {}).items()
            )
            print(f"\n    EV WRITE-OFF:  {ev_str}")
            justification = od.get("justification", "")
            if justification:
                for ln in textwrap.wrap(justification, width=72):
                    print(f"      {ln}")

        # Denial reason (from denial_reason block)
        dr = ld.get("denial_reason", {})
        if dr:
            carc_str = f"CARC {dr.get('carc_code')}: {dr.get('carc_description') or ''}"
            rarc_str = f"  |  RARC {dr.get('rarc_code')}" if is_valid(dr.get("rarc_code")) else ""
            print(f"\n    DENIAL REASON  |  Group: {ld.get('group', '?')}")
            print(f"      {carc_str}{rarc_str}")

        # Authorization status
        auth = ld.get("authorization_status", {})
        if auth:
            pa_present = auth.get("prior_authorization_present")
            pa_num     = auth.get("prior_authorization_number")
            pa_str     = (f"Present ({pa_num})" if pa_present and pa_num
                          else ("Present" if pa_present else "Absent"))
            att_str    = auth.get("attachment_present", "Unknown")
            print(f"\n    AUTHORIZATION  |  Prior Auth: {pa_str}  |  Attachment: {att_str}")

        # RCA
        rca = ld.get("root_cause_analysis", {})
        if rca:
            rarc_val  = ld.get("denial_codes", {}).get("rarc_code")
            rarc_part = f"RARC: {rarc_val}" if is_valid(rarc_val) else "No RARC Code"
            print(f"\n    ROOT CAUSE  |  {rarc_part}")
            if is_valid(rca.get("summary")):
                for ln in textwrap.wrap(rca["summary"], width=72):
                    print(f"      {ln}")

        # Evidence
        ev = ld.get("evidence", {})
        if ev:
            print(f"\n    EVIDENCE")
            for pt in ev.get("denial_evidence", []):
                print(f"      • {pt}")
            for sig in ev.get("flag_signals", []):
                print(f"      ⚠ {sig}")

        # Financial impact
        fi = ld.get("financial_impact", {})
        if fi:
            print(f"\n    FINANCIAL IMPACT  |  Denied: ${fi.get('denied_amount', 0):,.2f}")
            ev_by_action = fi.get("expected_value_by_action", {})
            if ev_by_action:
                print(f"    EXPECTED VALUE BY ACTION")
                for act, val in sorted(ev_by_action.items(), key=lambda kv: kv[1], reverse=True):
                    print(f"      {act:<15}: ${val:,.2f}")

        # NBA
        nba = ld.get("next_best_action", {})
        if nba:
            print(f"\n    NEXT BEST ACTION  →  {nba.get('recommended_action')}")
            pb = nba.get("payer_behavior", "")
            if pb:
                print(f"\n    PAYER BEHAVIOUR")
                for ln in textwrap.wrap(str(pb), width=72):
                    print(f"      {ln}")
            steps = nba.get("action_steps", [])
            if steps:
                print(f"\n    ACTION STEPS:")
                for i, step in enumerate(steps, 1):
                    lines = textwrap.wrap(str(step), width=70)
                    print(f"      {i}. {lines[0]}")
                    for continuation in lines[1:]:
                        print(f"         {continuation}")

    print(f"\n{sep}\n")


# This part only runs when you start the file directly with "python main.py"
# (not when this file is imported by another file).
if __name__ == "__main__":
    # Ask the user to type one or more claim IDs.
    typed = input("Enter claim_control_number(s) [comma-separated]: ").strip()
    # Split the typed text on commas and drop any empty/blank entries.
    ids   = [c.strip() for c in typed.split(",") if c.strip()]
    if not ids:
        print("No claim IDs entered. Exiting.")
    else:
        run_pipeline(ids)
