"""
config.py
---------
Single source of truth for the entire pipeline.

If you want to change ANYTHING — file paths, column names, routing rules,
agent messages, ML threshold — do it here. No other file needs to change.
"""

import os

# 1. DATA PATHS

# Repo root = two levels above this file (Config/ -> agent dir -> repo root).
REPO_ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

ADS_FILE_PATH  = "Data/merged_cleaned.xlsx"  # Merged data file

# Sklearn pipeline produced by Recovery_Intelligence_Modeling_v1/src/build_pipeline.py.
ML_PIPELINE_PATH = os.path.join(
    REPO_ROOT,
    "Recovery_Intelligence_Modeling_v2",
    "output", "Model", "PKL", "model_pipeline.joblib",
)

# 2. COLUMN NAMES  (what they are called inside ADS.csv)

# The column a user types when searching for a claim.
CLAIM_ID_COLUMN = "claim_control_number"
INT_COLUMNS = {"CARC", "procedure_code"}
# The column that tells us which adjustment group the claim belongs to.
GROUP_COLUMN = "GROUP"
# Key used inside the "Decision" view for the list of unique GROUP values
# found across every service line of a claim (claim-level routing).
GROUP_VALUES_KEY = "GROUP_VALUES"

# Denial code columns shown in RCA / Evidence outputs.
CARC_COLUMN = "CARC"
RARC_COLUMN = "RARC"

# 3. ROUTING RULES  (which GROUP codes trigger which path in process_line_decisions)

# Routing is evaluated per service line inside process_line_decisions:
#   GROUP = CO  →  Write Off  (rule-based, no ML)
#   GROUP = PR  →  Bill Patient  (rule-based, LLM rationale)
#   GROUP = other (PI, OA, …)  →  ML → EV → NBA full path

# Named constants for the two directly-routed group codes.
GROUP_CODE_CO = "CO"    # Contractual Obligation  →  Write Off
GROUP_CODE_PR = "PR"    # Patient Responsibility   →  Bill Patient

# 5. ML AGENT — columns sent to the model and output settings

# Exactly the feature columns the pkl model was trained on.
# Change this list only if you retrain the model with different features.
ML_FEATURE_COLUMNS = [
    # Raw binary / numeric columns from merged_data passed to the inference pipeline.
    "is_oa_denial",
    "is_pi_denial",
    "has_rarc",
    "submission_lag_days",
    "total_claim_charge",
    "total_paid_amount",
    "units",
    "num_diagnoses",
    "has_attachment",
    "resubmission_indicator",
    "resubmission_count_per_claim",
    "denial_count",
    "prior_auth_present",
    "has_diagnosis_3",
    "is_inpatient",
    # payer_recovery_rate is added by the frozen payer lookup tables inside
    # the sklearn pipeline — not extracted from raw data.
    # Categorical source columns used by preprocessing.
    "billing_provider_taxonomy",
    "billing_provider_state",
    "facility_code_value",
    "subscriber_state",
]

# Recovery status labels written to the line_decisions output.
RECOVERY_STATUS_NOT_RECOVERABLE = "Not Recoverable"
RECOVERY_STATUS_RECOVERABLE     = "Recoverable"
RECOVERY_STATUS_EV_WRITE_OFF    = "Recoverable (EV: Write Off)"

# 6. RCA AGENT — columns it is allowed to see

RCA_COLUMNS = [
    "claim_control_number",
    "payer_name",
    "payer_id",
    "GROUP",
    "CARC",
    "RARC",
    "procedure_code",
    "procedure_modifier_1",
    "line_procedure_modifier_1",
    "principal_diagnosis",
    "diagnosis_2",
    "diagnosis_3",
    "diagnosis_4",
    "prior_authorization_number",
    "total_claim_charge",
    "total_paid_amount",
    "units",
    "claim_filing_indicator",
    "has_prior_auth",
    "has_modifier",
    "has_secondary_diagnosis",
    "has_attachment",
    "has_billing_provider_npi",
    "has_rendering_provider_npi",
    "is_co_denial",
    "is_pr_denial",
    "is_oa_denial",
    "is_pi_denial",
    "place_of_service",
    "type_of_bill",
    "service_date",
    "statement_from_date",
    "statement_to_date",
    "revenue_code",
    # Raw source columns needed by the FE transformer at inference time.
    # These allow apply_row_level_fe() to compute the same features it
    # produced during training instead of falling back to NaN or defaults.
    "bht_date",                   # → days_to_adjudication
    "claim_final_status_date",    # → days_to_adjudication
    "claim_frequency_code",       # → resubmission_indicator
    "original_reference_number",  # → resubmission_indicator
    "billing_provider_npi",       # → has_billing_provider_npi
    "rendering_provider_npi",     # → has_rendering_provider_npi
    "attachment_report_type_code",# → has_attachment
    "initial_outcome",            # → denial_flag_beh (payer behaviour input)
    "line_paid_amount",           # → denial_flag (auth/PA flags input)
    "units_paid",                 # → line_qty_shave_flag, line_unit_shortfall
    "billing_provider_taxonomy",
    "billing_provider_state",
    "facility_code_value",
    "subscriber_state",
    "resubmission_indicator",
    "claim_final_status",
    "claim_received_date",
]

# 7. EVIDENCE AGENT — columns it is allowed to see

EVIDENCE_COLUMNS = [
    "claim_control_number",
    "payer_name",
    "payer_id",
    "GROUP",
    "CARC",
    "RARC",
    "procedure_code",
    "procedure_modifier_1",
    "line_procedure_modifier_1",
    "principal_diagnosis",
    "diagnosis_2",
    "diagnosis_3",
    "prior_authorization_number",
    "total_claim_charge",
    # "adjustment_amount",          # post-adjudication — removed to avoid data leakage
    "denied_amount",
    # "total_paid_amount",          # post-outcome — removed to avoid data leakage
    # "patient_responsibility_amount", # post-adjudication — removed to avoid data leakage
    # "claim_payment_amount",       # post-outcome — removed to avoid data leakage
    "has_prior_auth",
    "has_modifier",
    "has_secondary_diagnosis",
    "has_attachment",
    "has_billing_provider_npi",
    "has_rendering_provider_npi",
    "is_co_denial",
    "is_pr_denial",
    "is_oa_denial",
    "is_pi_denial",
    "service_date",
    "statement_from_date",
    "statement_to_date",
    "claim_filing_indicator",
    "place_of_service",
    "type_of_bill",
    "revenue_code",
    "total_paid_amount",
]

# 8. RECOVERY CHANNEL LABELS
# The two recovery channel values recorded in ADS.csv for successfully recovered
# claims. Used by nba_agent to count similar-claim outcomes (historical vote)
# and by data_loader to build the per-CARC action probability table.

RECOVERY_CHANNEL_APPEAL  = "Recovered via Appeal"
RECOVERY_CHANNEL_REBILL  = "Recovered via Resubmission"

# Column in ADS.csv that records how a recovered claim was resolved.
RECOVERY_CHANNEL_COLUMN  = "recovery_method"

# Minimum ADS rows per CARC before its appeal/resubmit rates are trusted.
# CARCs below this threshold fall back to the ML model's overall probability.
ACTION_PROB_MIN_SAMPLES      = 10

# Minimum ADS rows per CARC+RARC combination before those specific rates are
# used. Set lower than ACTION_PROB_MIN_SAMPLES because CARC+RARC combos are
# naturally rarer — each CARC may have only a handful of RARC variants.
CARC_RARC_PROB_MIN_SAMPLES   = 5

# Payer ID column used to compute Payer+CARC+RARC historical success rates.
PAYER_ID_COLUMN = "payer_id"

# Minimum ADS rows for a Payer+CARC+RARC combination to be trusted.
# Set even lower than CARC_RARC because the 3-way combo is naturally rare.
PAYER_CARC_RARC_MIN_SAMPLES = 3

# 9. NBA AGENT — recommended actions and costs

# The three actions the pipeline can recommend.
NBA_ACTION_APPEAL      = "Appeal"       # Payer-denied lines with positive EV for appeal
NBA_ACTION_REBILL      = "Resubmit"     # Payer-denied lines with positive EV for resubmission
NBA_ACTION_WRITE_OFF   = "Write Off"    # CO path, EV-negative lines, non-recoverable ML lines
NBA_ACTION_BILL_PATIENT = "Bill Patient" # PR path — patient is responsible, not the payer

# Staff/operational cost per action, used in the EV formula:
#   EV(action) = P(recover | action) × denied_amount − cost(action)
# "Bill Patient" is excluded from EV computation (it is only valid on the PR
# direct path, not a recoverable-denial pursuit action).
# Tune these numbers to your organisation's actual cost rates — no code changes needed.
NBA_ACTION_COSTS = {
    NBA_ACTION_APPEAL    : 25,   # staff time to prepare and file a formal appeal
    NBA_ACTION_REBILL    : 50,   # staff time to correct and resubmit the claim
    NBA_ACTION_WRITE_OFF : 0,    # no further effort required
}

# 9. SIMILARITY SEARCH

# Sentence-transformer model used to embed claims for cosine similarity search.
# all-MiniLM-L6-v2 is small (80 MB), fast, and already available via
# the sentence-transformers package installed in this environment.
EMBED_MODEL_NAME = "all-MiniLM-L6-v2"

# Number of similar historical claims to retrieve for each input claim.
SIMILARITY_TOP_K = 15

# Minimum cosine similarity score (0–1) for a historical claim to be included.
# Claims scoring below this threshold are excluded even if they are in the top-K.
SIMILARITY_THRESHOLD = 0.80

# 10. OUTPUT SETTINGS


# 11. FEATURE ENGINEERING CONFIG  (row-level inference)
# Used by Utilits/fe_steps.py.  Update here if the ML repo's FE logic changes.

FE_SUBMISSION_DATE_COL       = "bht_date"
FE_FINAL_STATUS_DATE_COL     = "claim_final_status_date"
FE_PAYMENT_DATE_COL          = "payment_effective_date"
FE_CLAIM_CONTROL_NUMBER_COL  = "claim_control_number"
FE_INITIAL_OUTCOME_COL       = "initial_outcome"
FE_CLAIM_DENIED_LABEL        = "Denied"
FE_CORRECTED_SUBMISSION_CODE = 7
FE_PEND_STATUS_CODE          = "P1"

FE_GROUP_COL          = "GROUP"
FE_CARC_COL           = "CARC"
FE_RARC_COL           = "RARC"
FE_RARC_ABSENT_VALUE  = "NO_CODE"
FE_DENIAL_GROUP_CODES = {"CO", "PR", "OA", "PI"}

FE_MISSING_FLAG_FEATURES = {
    "has_prior_auth":             ("prior_authorization_number", "NO_AUTH"),
    "has_modifier":               ("procedure_modifier_1",       "NO_MOD"),
    "has_secondary_diagnosis":    ("diagnosis_2",                "NONE"),
    "has_billing_provider_npi":   ("billing_provider_npi",       None),
    "has_rendering_provider_npi": ("rendering_provider_npi",     None),
    "has_attachment":             ("attachment_report_type_code", None),
    "has_line_modifier":          ("line_procedure_modifier_1",  "NO_MOD"),
}

FE_DENIAL_GROUP_FLAGS = {
    "is_oa_denial": "OA",
    "is_pi_denial": "PI",
}

FE_DIAGNOSIS_COLUMNS      = ["principal_diagnosis", "diagnosis_2", "diagnosis_3", "diagnosis_4"]
FE_DIAGNOSIS_ABSENT_VALUE = "NONE"
FE_BUNDLING_CARCS         = ["97", "236"]

OUTPUT_DIR = "outputs"   # Where pipeline result JSON files are saved

# 13. PAYER SIGNAL MAPPINGS — all payer-behaviour, EBS, KPI, KRI label maps live here.
#     agents.py imports these instead of defining inline dicts.

# B01-B12 flag groupings used to categorise active payer behaviour signals.
PAYER_BEHAVIOR_CATEGORIES = {
    "Rule Shift"      : ["b01_flag", "b02_flag", "b03_flag", "b12_flag"],
    "Downcoding"      : ["b04_flag", "b05_flag", "b06_flag"],
    "Auth Anomalies"  : ["b07_flag", "b08_flag"],
    "Filing Anomalies": ["b09_flag", "b10_flag", "b11_flag"],
}

# E01-E03 early-behaviour-signal (EBS) field definitions.
# Each entry maps an EBS key to a display label and the payer_signals columns
# (col_name, display_alias) that carry its quantitative values.
EBS_SIGNAL_METRICS = {
    "e01": {
        "label" : "E01 — Denial Volume Drift",
        "fields": [("e01_edv", "edv"), ("e01_line_drift", "line_drift"), ("e01_flag", "flag")],
    },
    "e02": {
        "label" : "E02 — CPT Denial Pressure",
        "fields": [
            ("e02_pdp", "pdp"), ("e02_line_at_risk", "lines_at_risk"),
            ("e02_confidence", "confidence"), ("e02_flag", "flag"),
        ],
    },
    "e03": {
        "label" : "E03 — Structural Anomaly",
        "fields": [("e03_sas", "sas"), ("e03_line_anomalous", "lines_anomalous"), ("e03_flag", "flag")],
    },
}

# Human-readable messages shown in the early_signals output field per active E-flag.
EARLY_SIGNAL_MESSAGES = {
    "e01_flag": "Increasing denial frequency may indicate future claim risk.",
    "e02_flag": "At-risk CPT codes identified — denial pressure may increase.",
    "e03_flag": "Structural anomaly detected — payer denial pattern is unusually uneven.",
}

# KRI indicator column mappings (KRI-1 through KRI-4) from ADS raw data.
# Each key is a display label; each value is a list of (col_name, alias) pairs
# read from the raw claim row produced by feature engineering.
KRI_FIELD_MAPPINGS = {
    "KRI-1 PCI (Policy Concentration)": [
        ("pci", "pci"), ("pciconfidence", "confidence"), ("pci_flag", "flag"),
    ],
    "KRI-2 FCR (Family Capture Ratio)": [
        ("fcr", "fcr"), ("fcrconfidence", "confidence"), ("fcr_flag", "flag"),
    ],
    "KRI-3 CD (Contradiction Density)": [
        ("cd", "cd"), ("cdconfidence", "confidence"), ("cd_flag", "flag"),
    ],
    "KRI-4 PBR (Provider Blast Radius)": [
        ("pbr_cnt", "cnt"), ("pbr_pct", "pct"), ("pbrconfidence", "confidence"), ("pbr_flag", "flag"),
    ],
}

# KPI operational metric column mappings (KPI-01 through KPI-05) from ADS raw data.
KPI_FIELD_MAPPINGS = {
    "KPI-01 QoQ Denial Risk"  : [
        ("kpi01_latest_denial_rate", "denial_rate"),
        ("kpi01_max_consecutive_rising", "consecutive_rising"),
        ("kpi01_band", "band"), ("kpi01_flag", "flag"),
    ],
    "KPI-02 Recovery Rate"    : [
        ("kpi02_win_rate", "win_rate"), ("kpi02_recovery_rate", "recovery_rate"),
        ("kpi02_band", "band"), ("kpi02_flag", "flag"),
    ],
    "KPI-03 Resubmission Rate": [
        ("kpi03_resub_rate", "resub_rate"), ("kpi03_band", "band"), ("kpi03_flag", "flag"),
    ],
    "KPI-04 Time-to-Pay"      : [
        ("kpi04_avg_ttp", "avg_ttp_days"), ("kpi04_band", "band"), ("kpi04_flag", "flag"),
    ],
    "KPI-05 Payer Mix"        : [
        ("kpi05_flag", "flag"), ("kpi05_band", "band"),
    ],
}

# Submission flag columns → display labels used in the evidence LLM context.
SUBMISSION_FLAG_LABELS = {
    "has_prior_auth"            : "Prior authorization",
    "has_modifier"              : "Procedure modifier",
    "has_secondary_diagnosis"   : "Secondary diagnosis",
    "has_attachment"            : "Supporting attachment",
    "has_billing_provider_npi"  : "Billing provider NPI",
    "has_rendering_provider_npi": "Rendering provider NPI",
}

# Denial group flag columns → human-readable denial group label.
# Used in both the RCA and evidence LLM contexts.
DENIAL_GROUP_LABELS = {
    "is_co_denial": "CO (Contractual Obligation)",
    "is_pr_denial": "PR (Patient Responsibility)",
    "is_oa_denial": "OA (Other Adjustment)",
    "is_pi_denial": "PI (Payer Initiated)",
}

# Claim final status raw values → display labels.
CLAIM_STATUS_LABELS = {
    "F1"    : "F1 - Paid",
    "PAID"  : "F1 - Paid",
    "F2"    : "F2 - Denied",
    "DENIED": "F2 - Denied",
}

# 12. LLM SETTINGS  (per-agent provider/model selection)

# The default LLM settings. An agent can override any of these in its own "llm".
DEFAULT_LLM = {
    "provider"   : "claude",
    "model"      : "claude-sonnet-4-6",
    "temperature": 0,
}

# One entry per agent.
#   "llm" = that agent's own {"provider", "model", "temperature"} — a
#            standalone dict, NOT a shared reference, so editing one
#            agent's provider/model never affects another agent.
#            Leave any key out to fall back to DEFAULT_LLM for that key
#            (see get_agent_llm_config in Models/llm.py).
AGENTS = {
    "decision": {},
    "ml": {
        "llm": None,   # ML agent scores best_model.pkl — no LLM involved.
    },
    "rca": {
        "llm": {"provider": "claude", "model": "claude-sonnet-4-6", "temperature": 0},
    },
    "evidence": {
        "llm": {"provider": "claude", "model": "claude-sonnet-4-6", "temperature": 0},
    },
    "nba": {
        "llm": {"provider": "claude", "model": "claude-sonnet-4-6", "temperature": 0},
    },
    "retrieval": {
        "llm": {"provider": "claude", "model": "claude-sonnet-4-6", "temperature": 0},
    },
}
