"""
data_loader.py
--------------
Reads merged_cleaned.xlsx and returns a clean DataFrame ready for the pipeline.
Also builds the per-CARC (and per-CARC+RARC) action probability table
used by the NBA agent.

The file path comes from Config/config.py -> ADS_FILE_PATH.
If you move or rename the file, change that one setting — nothing else needs updating.
"""

import numpy as np
import pandas as pd

from Config.config import (
    ADS_FILE_PATH,
    CARC_COLUMN,
    RARC_COLUMN,
    RECOVERY_CHANNEL_COLUMN,
    RECOVERY_CHANNEL_APPEAL,
    RECOVERY_CHANNEL_REBILL,
    ACTION_PROB_MIN_SAMPLES,
    CARC_RARC_PROB_MIN_SAMPLES,
    PAYER_ID_COLUMN,
    PAYER_CARC_RARC_MIN_SAMPLES,
)
from Utilits.logger import get_logger
from Utilits.apply_fe import apply_inference_fe

logger = get_logger(__name__)


def load_ads() -> pd.DataFrame:
    """
    Read merged_cleaned.xlsx, apply row-level feature engineering on the
    full dataset, and return the enriched DataFrame.

    Running FE on the full dataset ensures groupby-based features
    (denial_count, resubmission_count_per_claim) match the values computed
    during training.  Payer lookup joins are applied later by the sklearn
    pipeline using frozen training-time tables.

    Returns
    -------
    pd.DataFrame
        All rows with row-level FE columns added, one row per claim line.
    """
    logger.info("Reading merged data file — %s", ADS_FILE_PATH)
    df = pd.read_excel(ADS_FILE_PATH)
    logger.info("Loaded %d rows, %d columns from merged data.", len(df), len(df.columns))

    # Drop payer_recovery_rate from the raw file — it is added by the frozen
    # payer lookup tables inside the sklearn pipeline.  Keeping it here causes
    # a merge conflict (_x / _y suffixes) that corrupts the feature for the model.
    if "payer_recovery_rate" in df.columns:
        df = df.drop(columns=["payer_recovery_rate"])
        logger.info("Dropped payer_recovery_rate from raw data (will be applied via payer lookup).")

    df = apply_inference_fe(df)
    logger.info("Post-FE shape: %d rows, %d columns.", len(df), len(df.columns))
    return df


def build_action_prob_table(df: pd.DataFrame) -> dict:
    """
    Compute per-CARC (and per-CARC+RARC) action recovery probabilities
    from the full ADS DataFrame.

    For each CARC with >= ACTION_PROB_MIN_SAMPLES rows, calculates what
    fraction of claims recovered via Appeal vs Resubmission.  Within each
    CARC, also computes the same breakdown for every RARC sub-group that
    has >= CARC_RARC_PROB_MIN_SAMPLES rows.

    nba_agent uses the CARC+RARC rate when available (more specific) and
    falls back to the CARC-only rate otherwise.

    Returns
    -------
    dict
        {
            carc_int: {
                "appeal":       float,          # CARC-level appeal rate
                "resubmit":     float,          # CARC-level resubmit rate
                "sample_count": int,            # rows used for CARC-level rates
                "by_rarc": {                    # per-RARC breakdown (may be empty)
                    rarc_str: {
                        "appeal":       float,
                        "resubmit":     float,
                        "sample_count": int,
                    }, ...
                },
                "by_payer": {                   # per-payer breakdown (may be empty)
                    payer_id_str: {
                        "appeal":       float,
                        "resubmit":     float,
                        "sample_count": int,
                        "by_rarc": {            # payer+RARC breakdown (may be empty)
                            rarc_str: {
                                "appeal":       float,
                                "resubmit":     float,
                                "sample_count": int,
                            }, ...
                        }
                    }, ...
                }
            }
        }
        Only CARCs with >= ACTION_PROB_MIN_SAMPLES rows are included.
    """
    if CARC_COLUMN not in df.columns or RECOVERY_CHANNEL_COLUMN not in df.columns:
        logger.warning(
            "build_action_prob_table: '%s' or '%s' column not found in ADS — "
            "action-specific probabilities unavailable.",
            CARC_COLUMN, RECOVERY_CHANNEL_COLUMN,
        )
        return {}

    has_rarc  = RARC_COLUMN in df.columns
    has_payer = PAYER_ID_COLUMN in df.columns
    table     = {}

    for carc, carc_group in df.groupby(CARC_COLUMN):
        if len(carc_group) < ACTION_PROB_MIN_SAMPLES:
            continue
        try:
            carc_int = int(carc)
        except (ValueError, TypeError):
            continue

        total          = len(carc_group)
        appeal_count   = (carc_group[RECOVERY_CHANNEL_COLUMN] == RECOVERY_CHANNEL_APPEAL).sum()
        resubmit_count = (carc_group[RECOVERY_CHANNEL_COLUMN] == RECOVERY_CHANNEL_REBILL).sum()

        carc_entry = {
            "appeal"      : round(appeal_count   / total, 4),
            "resubmit"    : round(resubmit_count / total, 4),
            "sample_count": int(total),
            "by_rarc"     : {},
            "by_payer"    : {},
        }

        # Build CARC+RARC breakdown for rows that have a RARC value.
        if has_rarc:
            rarc_subset = carc_group[carc_group[RARC_COLUMN].notna()]
            for rarc_val, rarc_group in rarc_subset.groupby(RARC_COLUMN):
                if len(rarc_group) < CARC_RARC_PROB_MIN_SAMPLES:
                    continue
                rarc_total    = len(rarc_group)
                rarc_appeal   = (rarc_group[RECOVERY_CHANNEL_COLUMN] == RECOVERY_CHANNEL_APPEAL).sum()
                rarc_resubmit = (rarc_group[RECOVERY_CHANNEL_COLUMN] == RECOVERY_CHANNEL_REBILL).sum()
                carc_entry["by_rarc"][str(rarc_val)] = {
                    "appeal"      : round(rarc_appeal   / rarc_total, 4),
                    "resubmit"    : round(rarc_resubmit / rarc_total, 4),
                    "sample_count": int(rarc_total),
                }

        # Build Payer+CARC (and Payer+CARC+RARC) breakdown.
        if has_payer:
            payer_subset = carc_group[carc_group[PAYER_ID_COLUMN].notna()]
            for payer_val, payer_group in payer_subset.groupby(PAYER_ID_COLUMN):
                if len(payer_group) < PAYER_CARC_RARC_MIN_SAMPLES:
                    continue
                p_total    = len(payer_group)
                p_appeal   = (payer_group[RECOVERY_CHANNEL_COLUMN] == RECOVERY_CHANNEL_APPEAL).sum()
                p_resubmit = (payer_group[RECOVERY_CHANNEL_COLUMN] == RECOVERY_CHANNEL_REBILL).sum()
                payer_entry = {
                    "appeal"      : round(p_appeal   / p_total, 4),
                    "resubmit"    : round(p_resubmit / p_total, 4),
                    "sample_count": int(p_total),
                    "by_rarc"     : {},
                }
                # Payer+CARC+RARC breakdown
                if has_rarc:
                    pr_subset = payer_group[payer_group[RARC_COLUMN].notna()]
                    for rarc_val, pr_group in pr_subset.groupby(RARC_COLUMN):
                        if len(pr_group) < PAYER_CARC_RARC_MIN_SAMPLES:
                            continue
                        pr_total    = len(pr_group)
                        pr_appeal   = (pr_group[RECOVERY_CHANNEL_COLUMN] == RECOVERY_CHANNEL_APPEAL).sum()
                        pr_resubmit = (pr_group[RECOVERY_CHANNEL_COLUMN] == RECOVERY_CHANNEL_REBILL).sum()
                        payer_entry["by_rarc"][str(rarc_val)] = {
                            "appeal"      : round(pr_appeal   / pr_total, 4),
                            "resubmit"    : round(pr_resubmit / pr_total, 4),
                            "sample_count": int(pr_total),
                        }
                carc_entry["by_payer"][str(payer_val)] = payer_entry

        table[carc_int] = carc_entry

    rarc_combo_count  = sum(len(v["by_rarc"])  for v in table.values())
    payer_combo_count = sum(len(v["by_payer"]) for v in table.values())
    logger.info(
        "Action probability table built — %d CARC codes, %d CARC+RARC combinations, "
        "%d Payer+CARC combinations.",
        len(table), rarc_combo_count, payer_combo_count,
    )
    return table


def build_payer_kri_kpi_table(df: pd.DataFrame) -> dict:
    """
    Compute payer-level KRI-1..4 and KPI-01..05 from the FE-enriched ADS DataFrame.

    All inputs are derived from columns already present after apply_inference_fe()
    runs at load_ads() time — no new columns are added to merged_cleaned.xlsx.

    Returns
    -------
    dict
        {payer_id_str: {metric_col: value, ...}}
        Column names match KRI_FIELD_MAPPINGS and KPI_FIELD_MAPPINGS in config.py
        so nba_agent can look up by payer_id without any row-level joins.
    """
    if "payer_id" not in df.columns:
        logger.warning("build_payer_kri_kpi_table: 'payer_id' column missing — returning empty table.")
        return {}

    # Rename FE-produced / raw column names to the standard KRI/KPI input names.
    w = df.rename(columns={
        "claim_control_number"     : "claim_id",
        "total_claim_charge"       : "billed_charge",
        "procedure_code"           : "billed_cpt",
        "billing_provider_npi"     : "provider_id",
        "claim_final_status"       : "terminal_status_277",
        "total_paid_amount"        : "claim_total_paid",
        "resubmission_indicator"   : "is_resubmitted",
        "denial_flag_beh"          : "claim_denial_flag",
        "denial_flag"              : "line_denied_flag",
        "post_approved_then_denied": "pa_related_denial_flag",
    }).copy()

    # Derive payment_received and time_to_payment_days — not produced by fe_steps.
    w["payment_received"] = (
        w["claim_total_paid"].fillna(0) > 0
    ).astype(int) if "claim_total_paid" in w.columns else 0

    for col in ("payment_effective_date", "bht_date"):
        if col in w.columns:
            w[col] = pd.to_datetime(w[col], errors="coerce")
    if "payment_effective_date" in w.columns and "bht_date" in w.columns:
        w["time_to_payment_days"] = (
            w["payment_effective_date"] - w["bht_date"]
        ).dt.days
    else:
        w["time_to_payment_days"] = np.nan

    # CPT family: 2-char prefix (e.g. "99" for E&M, "70" for radiology).
    w["cpt_family"] = (
        w["billed_cpt"].astype(str).str[:2]
        if "billed_cpt" in w.columns else "XX"
    )

    def _claims(frame):
        """One row per claim — drop line-level duplicates."""
        return frame.drop_duplicates("claim_id") if "claim_id" in frame.columns else frame

    # ── KRI-1: Policy Concentration Index (PCI) ──────────────────────────────
    pci_rows = []
    try:
        if all(c in w.columns for c in ("claim_denial_flag", "carc_code", "billed_charge")):
            denied = _claims(w[w["claim_denial_flag"] == 1])
            payer_total = denied.groupby("payer_id")["billed_charge"].sum()
            by_grp = (
                denied.groupby(["payer_id", "carc_code"])["billed_charge"]
                .sum().reset_index(name="grp_dollars")
            )
            by_grp["total_denial_dollars"] = by_grp["payer_id"].map(payer_total)
            by_grp["pci"] = (by_grp["grp_dollars"] / by_grp["total_denial_dollars"]).fillna(0)
            top = by_grp.sort_values("pci", ascending=False).drop_duplicates("payer_id")
            for _, r in top.iterrows():
                p = float(r["pci"]); t = float(r.get("total_denial_dollars", 0))
                c1 = min(p, 1.0)
                c2 = min((p - 0.40) / max(0.60, 1e-9), 1.0) if p > 0.40 else 0.0
                c3 = min(t / 50000, 1.0)
                c4 = 0.1 if p > 0.40 else 0.0
                conf = round(min(c1*0.4 + c2*0.3 + c3*0.2 + c4, 1.0), 4)
                pci_rows.append({
                    "payer_id"     : str(r["payer_id"]),
                    "pci"          : round(p, 4),
                    "pciconfidence": conf,
                    "pci_flag"     : int(p > 0.40 and conf >= 0.80),
                })
    except Exception as exc:
        logger.warning("KRI-1 PCI failed: %s", exc)

    # ── KRI-2: Family Capture Ratio (FCR) ────────────────────────────────────
    fcr_rows = []
    try:
        if all(c in w.columns for c in ("line_denied_flag", "billed_charge", "cpt_family")):
            total_fam = (
                w.groupby(["payer_id", "cpt_family"])["billed_charge"]
                .sum().rename("total_dollars")
            )
            denied_fam = (
                w[w["line_denied_flag"] == 1]
                .groupby(["payer_id", "cpt_family"])["billed_charge"]
                .sum().rename("denied_dollars")
            )
            fam = pd.concat([total_fam, denied_fam], axis=1).fillna(0).reset_index()
            fam["fcr"] = (fam["denied_dollars"] / fam["total_dollars"]).fillna(0)
            top = fam.sort_values("fcr", ascending=False).drop_duplicates("payer_id")
            for _, r in top.iterrows():
                f = float(r["fcr"]); td = float(r.get("total_dollars", 0))
                c1 = min(f, 1.0)
                c2 = min((f - 0.60) / max(0.40, 1e-9), 1.0) if f > 0.60 else 0.0
                c3 = min(td / 100000, 1.0)
                c4 = 0.1 if f > 0.60 else 0.0
                conf = round(min(c1*0.4 + c2*0.3 + c3*0.2 + c4, 1.0), 4)
                fcr_rows.append({
                    "payer_id"     : str(r["payer_id"]),
                    "fcr"          : round(f, 4),
                    "fcrconfidence": conf,
                    "fcr_flag"     : int(f > 0.60 and conf >= 0.80),
                })
    except Exception as exc:
        logger.warning("KRI-2 FCR failed: %s", exc)

    # ── KRI-3: Contradiction Density (CD) ────────────────────────────────────
    cd_rows = []
    try:
        if "pa_related_denial_flag" in w.columns:
            claims = _claims(w)
            cd_df = (
                claims[claims["pa_related_denial_flag"] == 1]
                .groupby("payer_id")
                .agg(cd=("claim_id", "count"), cd_dollars=("billed_charge", "sum"))
                .reset_index()
            )
            for _, r in cd_df.iterrows():
                cnt = int(r["cd"]); dol = float(r.get("cd_dollars", 0))
                c1 = min(cnt / 10, 1.0)
                c2 = min(dol / 100000, 1.0)
                c3 = min(cnt / 5, 1.0)
                c4 = 0.1 if cnt > 0 else 0.0
                conf = round(min(c1*0.4 + c2*0.3 + c3*0.2 + c4, 1.0), 4)
                cd_rows.append({
                    "payer_id"    : str(r["payer_id"]),
                    "cd"          : cnt,
                    "cdconfidence": conf,
                    "cd_flag"     : int(cnt > 0 and conf >= 0.80),
                })
    except Exception as exc:
        logger.warning("KRI-3 CD failed: %s", exc)

    # ── KRI-4: Provider Blast Radius (PBR) ───────────────────────────────────
    pbr_rows = []
    try:
        if all(c in w.columns for c in ("claim_denial_flag", "provider_id", "carc_code")):
            claims = _claims(w)
            denied = claims[claims["claim_denial_flag"] == 1]
            dominant = (
                denied.groupby(["payer_id", "carc_code"])["billed_charge"]
                .sum().reset_index()
                .sort_values("billed_charge", ascending=False)
                .drop_duplicates("payer_id")
                [["payer_id", "carc_code"]].rename(columns={"carc_code": "dominant_carc"})
            )
            merged_d = denied.merge(dominant, on="payer_id")
            pbr_cnt = (
                merged_d[merged_d["carc_code"] == merged_d["dominant_carc"]]
                .groupby("payer_id")["provider_id"].nunique()
                .reset_index(name="pbr_cnt")
            )
            total_prov = (
                claims.groupby("payer_id")["provider_id"].nunique()
                .reset_index(name="total_providers")
            )
            pbr_df = pbr_cnt.merge(total_prov, on="payer_id")
            pbr_df["pbr_pct"] = (pbr_df["pbr_cnt"] / pbr_df["total_providers"]).round(4)
            for _, r in pbr_df.iterrows():
                cnt = int(r["pbr_cnt"]); pct = float(r["pbr_pct"])
                c1 = min(cnt / 50, 1.0)
                c2 = min(pct, 1.0)
                c3 = min(cnt / 20, 1.0)
                c4 = 0.1 if cnt > 20 else 0.0
                conf = round(min(c1*0.4 + c2*0.3 + c3*0.2 + c4, 1.0), 4)
                pbr_rows.append({
                    "payer_id"     : str(r["payer_id"]),
                    "pbr_cnt"      : cnt,
                    "pbr_pct"      : pct,
                    "pbrconfidence": conf,
                    "pbr_flag"     : int(cnt > 20 and pct > 0.50 and conf >= 0.80),
                })
    except Exception as exc:
        logger.warning("KRI-4 PBR failed: %s", exc)

    # ── KPI-01: QoQ Denial Risk ───────────────────────────────────────────────
    kpi01_rows = []
    try:
        if "claim_denial_flag" in w.columns:
            claims = _claims(w).copy()
            date_col = next(
                (c for c in ("claim_final_status_date", "service_date") if c in claims.columns),
                None,
            )
            if date_col:
                claims["_qtr"] = pd.to_datetime(claims[date_col], errors="coerce").dt.to_period("Q")
                qtr = (
                    claims.groupby(["payer_id", "_qtr"])
                    .agg(n_claims=("claim_id", "size"), n_denied=("claim_denial_flag", "sum"))
                    .reset_index()
                )
                qtr["denial_rate"] = qtr["n_denied"] / qtr["n_claims"]
                for payer, g in qtr.groupby("payer_id"):
                    g = g.sort_values("_qtr")
                    rates = g["denial_rate"].values
                    max_run = run = 0
                    for i in range(1, len(rates)):
                        if rates[i] > rates[i - 1]:
                            run += 1; max_run = max(max_run, run)
                        else:
                            run = 0
                    diffs = [rates[i] - rates[i - 1] for i in range(1, len(rates))]
                    max_jump = max(diffs) if diffs else 0
                    band = "Act" if max_run >= 3 else ("Watch" if max_jump > 0.03 else "Good")
                    c1 = min(max_run / 5, 1.0)
                    c2 = min(max_jump / 0.10, 1.0)
                    c3 = min(len(g) / 8, 1.0)
                    c4 = 0.1 if band == "Act" else 0.0
                    conf = round(min(c1*0.4 + c2*0.3 + c3*0.2 + c4, 1.0), 4)
                    kpi01_rows.append({
                        "payer_id"                    : str(payer),
                        "kpi01_latest_denial_rate"    : round(float(rates[-1]), 4),
                        "kpi01_max_consecutive_rising": int(max_run),
                        "kpi01_band"                  : band,
                        "kpi01_flag"                  : int(band == "Act" and conf >= 0.80),
                    })
    except Exception as exc:
        logger.warning("KPI-01 QoQ Denial Risk failed: %s", exc)

    # ── KPI-02: Recovery Rate ─────────────────────────────────────────────────
    kpi02_rows = []
    try:
        if all(c in w.columns for c in ("terminal_status_277", "is_resubmitted")):
            claims = _claims(w)
            paid_vals   = {"F1", "PAID"}
            denied_vals = {"F2", "DENIED"}
            for payer, g in claims.groupby("payer_id"):
                status_upper = g["terminal_status_277"].astype(str).str.strip().str.upper()
                n_denied     = int((g.get("claim_denial_flag", pd.Series(0, index=g.index)) == 1).sum())
                resub        = g[g["is_resubmitted"] == 1]
                n_won        = int(status_upper[resub.index].isin(paid_vals).sum())
                n_lost       = int(status_upper[resub.index].isin(denied_vals).sum())
                recovery_rate = n_won / n_denied if n_denied > 0 else 0
                win_rate      = n_won / (n_won + n_lost) if (n_won + n_lost) > 0 else 0
                band = "Act" if win_rate < 0.40 else (
                    "Watch" if win_rate >= 0.50 and recovery_rate < 0.25 else "Good"
                )
                c1 = min((0.40 - win_rate) / 0.40, 1.0) if win_rate < 0.40 else 0.0
                c2 = min(1.0 - recovery_rate, 1.0)
                c3 = min(n_denied / 50, 1.0)
                c4 = 0.1 if band == "Act" else 0.0
                conf = round(min(c1*0.4 + c2*0.3 + c3*0.2 + c4, 1.0), 4)
                kpi02_rows.append({
                    "payer_id"            : str(payer),
                    "kpi02_win_rate"      : round(win_rate, 4),
                    "kpi02_recovery_rate" : round(recovery_rate, 4),
                    "kpi02_band"          : band,
                    "kpi02_flag"          : int(band == "Act" and conf >= 0.80),
                })
    except Exception as exc:
        logger.warning("KPI-02 Recovery Rate failed: %s", exc)

    # ── KPI-03: Resubmission Rate ─────────────────────────────────────────────
    kpi03_rows = []
    try:
        if "is_resubmitted" in w.columns:
            claims = _claims(w)
            for payer, g in claims.groupby("payer_id"):
                n_total   = len(g)
                n_resub   = int((g["is_resubmitted"] == 1).sum())
                resub_rate = n_resub / n_total if n_total > 0 else 0
                band = "Watch" if resub_rate >= 0.30 else "Good"
                c1 = min((resub_rate - 0.30) / max(0.70, 1e-9), 1.0) if resub_rate >= 0.30 else 0.0
                c2 = min(n_resub / 50, 1.0)
                c4 = 0.1 if band == "Watch" else 0.0
                conf = round(min(c1*0.4 + c2*0.3 + c4, 1.0), 4)
                kpi03_rows.append({
                    "payer_id"       : str(payer),
                    "kpi03_resub_rate": round(resub_rate, 4),
                    "kpi03_band"     : band,
                    "kpi03_flag"     : int(band == "Watch" and conf >= 0.80),
                })
    except Exception as exc:
        logger.warning("KPI-03 Resubmission Rate failed: %s", exc)

    # ── KPI-04: Time-to-Pay ───────────────────────────────────────────────────
    kpi04_rows = []
    try:
        if all(c in w.columns for c in ("time_to_payment_days", "payment_received")):
            claims = _claims(w)
            for payer, g in claims.groupby("payer_id"):
                paid = g[g["payment_received"] == 1].dropna(subset=["time_to_payment_days"])
                if paid.empty:
                    continue
                avg_days = float(paid["time_to_payment_days"].mean())
                band = "Act" if avg_days > 30 else ("Watch" if avg_days > 24 else "Good")
                c1 = min((avg_days - 30) / 30, 1.0) if avg_days > 30 else 0.0
                c2 = min(avg_days / 60, 1.0)
                c3 = min(len(paid) / 50, 1.0)
                c4 = 0.1 if band == "Act" else 0.0
                conf = round(min(c1*0.4 + c2*0.3 + c3*0.2 + c4, 1.0), 4)
                kpi04_rows.append({
                    "payer_id"   : str(payer),
                    "kpi04_avg_ttp": round(avg_days, 2),
                    "kpi04_band" : band,
                    "kpi04_flag" : int(band == "Act" and conf >= 0.80),
                })
    except Exception as exc:
        logger.warning("KPI-04 Time-to-Pay failed: %s", exc)

    # ── KPI-05: Billed vs Paid Gap (informational) ────────────────────────────
    kpi05_rows = []
    try:
        if "billed_charge" in w.columns:
            claims = _claims(w)
            for payer, g in claims.groupby("payer_id"):
                total_billed = float(g["billed_charge"].fillna(0).sum())
                total_paid   = float(g["claim_total_paid"].fillna(0).sum()) if "claim_total_paid" in g.columns else 0.0
                gap_pct = (total_billed - total_paid) / total_billed if total_billed > 0 else 0.0
                kpi05_rows.append({
                    "payer_id"    : str(payer),
                    "kpi05_gap_pct": round(gap_pct, 4),
                    "kpi05_band"  : "Info",
                    "kpi05_flag"  : 0,
                })
    except Exception as exc:
        logger.warning("KPI-05 BvP Gap failed: %s", exc)

    # ── Merge all payer-level results into one lookup dict ────────────────────
    merged: dict = {}
    for row_list in (pci_rows, fcr_rows, cd_rows, pbr_rows,
                     kpi01_rows, kpi02_rows, kpi03_rows, kpi04_rows, kpi05_rows):
        for row in row_list:
            pid = str(row.get("payer_id", ""))
            if not pid:
                continue
            if pid not in merged:
                merged[pid] = {}
            merged[pid].update({k: v for k, v in row.items() if k != "payer_id"})

    logger.info(
        "Payer KRI/KPI table built — %d payers | "
        "KRI-1:%d KRI-2:%d KRI-3:%d KRI-4:%d | "
        "KPI-01:%d KPI-02:%d KPI-03:%d KPI-04:%d KPI-05:%d",
        len(merged),
        len(pci_rows), len(fcr_rows), len(cd_rows), len(pbr_rows),
        len(kpi01_rows), len(kpi02_rows), len(kpi03_rows), len(kpi04_rows), len(kpi05_rows),
    )
    return merged
