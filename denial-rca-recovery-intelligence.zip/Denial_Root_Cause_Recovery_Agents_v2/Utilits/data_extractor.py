"""
data_extractor.py
-----------------
Builds a dict keyed by claim_control_number. Each entry contains
per-agent views of that claim's data.

Because one claim can have multiple rows in merged_data.xlsx (one per claim line),
we take the FIRST row for single-value header fields (payer, provider, CARC,
etc. are repeated identically across lines) but keep ALL rows for the ML
agent, and collect the UNIQUE GROUP values across every line into the
Decision view so routing is claim-level rather than row-level — a claim
with a mix of GROUP codes (e.g. CO on one line, PI on another) is routed
using the full set, not just whichever row happens to come first.

Column lists for each agent come from Config/config.py.
Change the lists there — this file never needs to change.

Usage
-----
    from Utilits.data_extractor import build_claims_dict
    claims = build_claims_dict(df)
    claim = claims.get("PCN0000018")   # -> {"Decision": {...}, "ML": [...], "RCA": {...}, "Evidence": {...}}
"""

import math

import pandas as pd

from Config.config import (
    CLAIM_ID_COLUMN,
    INT_COLUMNS,
    GROUP_COLUMN,
    GROUP_VALUES_KEY,
    ML_FEATURE_COLUMNS,
    RCA_COLUMNS,
    EVIDENCE_COLUMNS,
)
from Utilits.logger import get_logger

logger = get_logger(__name__)


def clean_value(v):
    """Convert a cell value to a JSON-safe Python type. NaN/None become None."""
    if v is None:
        return None
    if isinstance(v, float) and math.isnan(v):
        # Empty cells in the CSV show up as NaN — treat them as "no value".
        return None
    # Convert numpy int/float to plain Python types so json.dump works.
    if hasattr(v, "item"):
        return v.item()
    return v


def row_to_dict(row: pd.Series, columns: list) -> dict:
    """Extract `columns` from a row and return a clean dict (no NaN values)."""
    available = [c for c in columns if c in row.index]
    result = {}
    for c in available:
        v = clean_value(row[c])
        if v is not None:
            result[c] = int(v) if c in INT_COLUMNS and isinstance(v, float) else v
    return result


def build_claims_dict(df: pd.DataFrame) -> dict:
    """
    Build and return a dict like:
        {
            "PCN0000001": {
                "Decision" : { "GROUP": "CO", ... },   # single-row view for routing
                "ML"       : [{ feature_col: value, ... }, ...],  # one dict per ADS line
                "RCA"      : { "payer_name": "...", "CARC": 55, ... },
                "Evidence" : { "CARC": 55, "has_prior_auth": 1, ... },
            },
            ...
        }

    Parameters
    ----------
    df : pd.DataFrame
        The full merged data DataFrame returned by data_loader.load_ads().

    Returns
    -------
    dict
        Claims dict. Keys are claim_control_number strings.
    """
    claims = {}

    # Group all the rows that share the same claim ID together, then
    # build one entry in the final dict per claim.
    for claim_id, group_df in df.groupby(CLAIM_ID_COLUMN):
        # Use the first row for all single-value views (payer, provider, etc.
        # are repeated identically across every line of the same claim).
        first_row = group_df.iloc[0]

        # Unique GROUP values across EVERY line of this claim, in the order
        # first seen, with duplicates and missing values dropped. This is
        # what routing decisions must use — a single row is not enough when
        # a claim's service lines carry different GROUP codes.
        group_values = list(dict.fromkeys(
            v for v in (clean_value(x) for x in group_df.get(GROUP_COLUMN, []))
            if v is not None
        ))

        # Decision view — GROUP (first row, kept for backward-compatible
        # single-value use) plus GROUP_VALUES (the full unique set) for
        # claim-level routing.
        decision_view = {
            GROUP_COLUMN     : clean_value(first_row.get(GROUP_COLUMN)),
            GROUP_VALUES_KEY : group_values,
            CLAIM_ID_COLUMN  : claim_id,
        }

        # ML view — one dict per ADS row (all lines for this claim).
        ml_view = []
        for _, row in group_df.iterrows():
            available_ml_cols = [c for c in ML_FEATURE_COLUMNS if c in row.index]
            row_dict = {c: clean_value(row[c]) for c in available_ml_cols}
            ml_view.append(row_dict)

        # RCA view — first row, RCA columns only.
        rca_view = row_to_dict(first_row, RCA_COLUMNS)

        # Evidence view — first row, Evidence columns only.
        evidence_view = row_to_dict(first_row, EVIDENCE_COLUMNS)

        # Service lines — one dict per ADS row, containing GROUP plus the
        # per-row ML, RCA, and Evidence views for that specific line.
        # Used by process_line_decisions to route and score each denied line
        # independently (CO/PR/Other logic, ML scoring, EV, NBA).
        service_lines = []
        for idx, (_, row) in enumerate(group_df.iterrows()):
            ln = clean_value(row.get("line_number"))
            service_lines.append({
                "line_number": int(ln) if ln is not None else (idx + 1),
                "GROUP"      : clean_value(row.get(GROUP_COLUMN)),
                "ML"         : {
                    c: clean_value(row[c])
                    for c in ML_FEATURE_COLUMNS
                    if c in row.index
                },
                "RCA"        : row_to_dict(row, RCA_COLUMNS),
                "Evidence"   : row_to_dict(row, EVIDENCE_COLUMNS),
                "raw"        : {c: clean_value(row[c]) for c in row.index},
            })

        # Store all views together under this claim's ID.
        claims[claim_id] = {
            "Decision"     : decision_view,
            "ML"           : ml_view,
            "RCA"          : rca_view,
            "Evidence"     : evidence_view,
            "service_lines": service_lines,
        }

    logger.info("Built claim dict for %d unique claims.", len(claims))
    return claims
