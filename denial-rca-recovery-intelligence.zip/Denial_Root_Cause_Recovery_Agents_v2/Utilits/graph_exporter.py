"""
graph_exporter.py
-----------------
Utility for exporting the compiled LangGraph agent pipeline to visual formats.

Supports:
  - PNG  via draw_mermaid_png()  (requires graphviz / playwright in the environment)
  - Raw Mermaid source (.mmd)    (always saved alongside the PNG, no dependencies needed)

Both files are written to the outputs/ folder on every run.

Usage — import:
    from Utilits.graph_exporter import export_graph_png, export_graph_mermaid

Usage — CLI (from project root):
    python -m Utilits.graph_exporter
    python -m Utilits.graph_exporter --output outputs/agent_graph.png
    python -m Utilits.graph_exporter --mermaid-only
"""

from __future__ import annotations

import argparse
import os

from Graph.graph import app
from Utilits.logger import get_logger

logger = get_logger(__name__)


def export_graph_png(output_path: str = "outputs/agent_graph.png") -> bool:
    """
    Render the compiled LangGraph pipeline as a PNG and write it to disk.

    Uses LangGraph's draw_mermaid_png() internally, which requires either
    the ``playwright`` or ``graphviz`` backend to be available.  Falls back
    to writing the raw Mermaid source alongside the requested path when the
    PNG render fails so that the graph can still be inspected.

    Parameters
    ----------
    output_path : str
        Destination file path for the PNG.  Parent directories are created
        automatically if they do not exist.

    Returns
    -------
    bool
        True if the PNG was written successfully, False if the fallback
        Mermaid source was written instead.
    """
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)

    try:
        png_bytes = app.get_graph().draw_mermaid_png()
        with open(output_path, "wb") as fh:
            fh.write(png_bytes)
        logger.info("Agent graph exported as PNG → %s", output_path)
        return True

    except Exception as exc:  # noqa: BLE001
        logger.warning("draw_mermaid_png() failed (%s) — falling back to Mermaid source.", exc)
        mermaid_path = os.path.splitext(output_path)[0] + ".mmd"
        export_graph_mermaid(mermaid_path)
        return False


def export_graph_mermaid(output_path: str = "outputs/agent_graph.mmd") -> None:
    """
    Write the compiled LangGraph pipeline's Mermaid diagram source to a file.

    The output file can be pasted into https://mermaid.live for interactive
    rendering without any local dependencies.

    Parameters
    ----------
    output_path : str
        Destination file path for the ``.mmd`` source.  Parent directories
        are created automatically if they do not exist.
    """
    os.makedirs(os.path.dirname(output_path) or ".", exist_ok=True)

    mermaid_src = app.get_graph().draw_mermaid()
    with open(output_path, "w", encoding="utf-8") as fh:
        fh.write(mermaid_src)
    logger.info("Agent graph exported as Mermaid source → %s", output_path)
    logger.info("Paste the file contents into https://mermaid.live to view interactively.")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Export the Denial RCA agent pipeline graph to PNG or Mermaid source."
    )
    parser.add_argument(
        "--output", "-o",
        default="outputs/agent_graph.png",
        metavar="PATH",
        help="Destination path for the exported PNG (default: outputs/agent_graph.png).",
    )
    parser.add_argument(
        "--mermaid-only",
        action="store_true",
        help="Skip PNG rendering and write only the Mermaid source (.mmd).",
    )
    return parser.parse_args()


if __name__ == "__main__":
    args = parse_args()
    png_path = args.output
    mmd_path = os.path.splitext(png_path)[0] + ".mmd"

    # Always write the Mermaid source — no external dependencies required.
    export_graph_mermaid(mmd_path)

    # Attempt the PNG render unless the user explicitly skipped it.
    if not args.mermaid_only:
        export_graph_png(png_path)
