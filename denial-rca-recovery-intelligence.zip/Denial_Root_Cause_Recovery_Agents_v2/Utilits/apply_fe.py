"""
apply_fe.py
-----------
Applies the same row-level feature engineering steps used during training
(feature_engineering.py Steps 1-6 + claim/auth/line detail flags) to the
full ADS DataFrame at load time.

Why on the full dataset, not per-claim at scoring time:
  add_lifecycle_count_features() uses groupby('claim_control_number') to
  compute denial_count and resubmission_count_per_claim.  Running on the
  full dataset gives the same per-claim counts as training.  Once these
  values are stored in the DataFrame, the sklearn pipeline's
  FeatureEngineerTransformer snapshot/restore preserves them even when the
  pipeline receives only a single claim's rows at scoring time.

Payer lookup joins (B01-B12, E01-E03) are intentionally left to the
sklearn pipeline so they use the frozen training-time lookup tables.
"""

import pandas as pd

from Utilits import fe_steps as fe
from Config.config import (
    FE_SUBMISSION_DATE_COL    as SUBMISSION_DATE_COL,
    FE_FINAL_STATUS_DATE_COL  as FINAL_STATUS_DATE_COL,
    FE_PAYMENT_DATE_COL       as PAYMENT_DATE_COL,
)
from Utilits.logger import get_logger

logger = get_logger(__name__)


def apply_inference_fe(df: pd.DataFrame) -> pd.DataFrame:
    """
    Run all nine stateless row-level FE functions on the full ADS DataFrame.

    This mirrors FeatureEngineerTransformer.apply_row_level_fe() but runs on
    the complete dataset so that groupby-based features (denial_count,
    resubmission_count_per_claim) reflect the full claim history.

    Parameters
    ----------
    df : pd.DataFrame
        Raw ADS DataFrame loaded from merged_cleaned.xlsx.

    Returns
    -------
    pd.DataFrame
        Same DataFrame with all row-level FE columns added.
    """
    logger.info("Inference FE: applying row-level FE to full dataset (%d rows).", len(df))

    # Parse date columns exactly as load_data() does in feature_engineering.py.
    date_cols = [
        SUBMISSION_DATE_COL,    # bht_date
        FINAL_STATUS_DATE_COL,  # claim_final_status_date
        "claim_received_date",
        "service_date",
        PAYMENT_DATE_COL,
    ]

    for col in date_cols:
        if col in df.columns:
            df[col] = pd.to_datetime(df[col], errors="coerce")

    # Run the same nine stateless FE steps as FeatureEngineerTransformer.
    df = fe.add_temporal_features(df)
    df = fe.add_lifecycle_count_features(df)
    df = fe.add_financial_features(df)
    df = fe.add_field_presence_flags(df)
    df = fe.add_denial_code_features(df)
    df = fe.add_clinical_features(df)
    df = fe.add_claim_status_flags(df)
    df = fe.add_auth_and_pa_flags(df)
    df = fe.add_line_detail_flags(df)

    logger.info(
        "Inference FE complete — %d rows, %d columns (was raw input).", len(df), len(df.columns)
    )
    return df
