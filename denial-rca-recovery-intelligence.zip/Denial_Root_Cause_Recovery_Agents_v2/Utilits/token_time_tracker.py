"""
token_time_tracker.py
----------------------
Logs how many tokens and how long each LLM call took.
Called by Models/llm.py -> ask_llm() after every provider response.
"""

from Utilits.logger import get_logger

logger = get_logger(__name__)


def track_usage(response, agent_name: str, seconds: float) -> None:
    """Log token usage and elapsed time for one LLM call."""
    # Some providers may not report usage — fall back to an empty dict then.
    usage = getattr(response, "usage_metadata", None) or {}

    # Prompt-caching detail (Claude only): cache_write > 0 means this call
    # wrote a NEW cache entry for the system prompt. cache_read > 0 means it
    # reused an existing cache entry instead of reprocessing the prompt.
    # LangChain puts the raw Anthropic usage (with cache token counts) in
    # response_metadata["usage"], not in usage_metadata — so we read it there.
    raw_usage   = getattr(response, "response_metadata", {}).get("usage", {}) or {}
    cache_write = raw_usage.get("cache_creation_input_tokens", 0)
    cache_read  = raw_usage.get("cache_read_input_tokens", 0)

    logger.info(
        "[%s] LLM usage — input_tokens=%s output_tokens=%s total_tokens=%s "
        "cache_write=%s cache_read=%s time=%.2fs",
        agent_name,
        usage.get("input_tokens"),
        usage.get("output_tokens"),
        usage.get("total_tokens"),
        cache_write,
        cache_read,
        seconds,
    )
