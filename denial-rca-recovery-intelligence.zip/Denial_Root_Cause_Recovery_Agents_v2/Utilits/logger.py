"""
logger.py
---------
Simple logging setup for the whole pipeline.

Call setup_pipeline_logger() ONCE at the start (in main.py).
After that, every file just does:

    from Utilits.logger import get_logger
    logger = get_logger(__name__)

Messages show up on the console and are also saved to
outputs/pipeline_<timestamp>.log.
"""

import logging
import os
from datetime import datetime


def setup_pipeline_logger(output_dir="outputs"):
    """Set up console + file logging. Call once at startup. Returns the log file path."""
    # Make sure the folder for log files exists.
    os.makedirs(output_dir, exist_ok=True)
    # Build a log file name that includes today's date and time.
    log_path = os.path.join(output_dir, f"pipeline_{datetime.now():%Y%m%d_%H%M%S}.log")

    logger = logging.getLogger("denial_rca")
    logger.setLevel(logging.DEBUG)

    # If we already added handlers once, don't add them again.
    if logger.handlers:
        return log_path

    # Save everything (DEBUG and up) to the log file.
    file_handler = logging.FileHandler(log_path, encoding="utf-8")
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(logging.Formatter("%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"))
    logger.addHandler(file_handler)

    # Show the important messages (INFO and up) on the console — same format as file.
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.INFO)
    console_handler.setFormatter(logging.Formatter("%(asctime)s | %(levelname)-8s | %(name)s | %(message)s"))
    logger.addHandler(console_handler)

    logger.info("Logger ready — writing to %s", log_path)
    return log_path


def get_logger(name):
    """Get a logger for one file. Use it like: logger = get_logger(__name__)."""
    return logging.getLogger(f"denial_rca.{name}")
