"""
fe_steps.py
-----------
Nine stateless row-level feature-engineering functions used at inference time.
Config constants live in Config/config.py (FE_* variables) —
update them there if the ML repo's FE logic changes.

Functions are identical to Recovery_Intelligence_Modeling_v1/src/
feature_engineering.py (Steps 1-9).  Payer-behaviour lookups (B01-B12) and
early-signal features (E01-E03) are NOT included — those are handled by the
frozen lookup tables inside model_pipeline.joblib.
"""

import numpy as np
import pandas as pd

from Config.config import (
    FE_SUBMISSION_DATE_COL       as SUBMISSION_DATE_COL,
    FE_FINAL_STATUS_DATE_COL     as FINAL_STATUS_DATE_COL,
    FE_CLAIM_CONTROL_NUMBER_COL  as CLAIM_CONTROL_NUMBER_COL,
    FE_INITIAL_OUTCOME_COL       as INITIAL_OUTCOME_COL,
    FE_CLAIM_DENIED_LABEL        as CLAIM_DENIED_LABEL,
    FE_CORRECTED_SUBMISSION_CODE as CORRECTED_SUBMISSION_CODE,
    FE_PEND_STATUS_CODE          as PEND_STATUS_CODE,
    FE_GROUP_COL                 as GROUP_COL,
    FE_CARC_COL                  as CARC_COL,
    FE_RARC_COL                  as RARC_COL,
    FE_RARC_ABSENT_VALUE         as RARC_ABSENT_VALUE,
    FE_DENIAL_GROUP_CODES        as DENIAL_GROUP_CODES,
    FE_MISSING_FLAG_FEATURES     as MISSING_FLAG_FEATURES,
    FE_DENIAL_GROUP_FLAGS        as DENIAL_GROUP_FLAGS,
    FE_DIAGNOSIS_COLUMNS         as DIAGNOSIS_COLUMNS,
    FE_DIAGNOSIS_ABSENT_VALUE    as DIAGNOSIS_ABSENT_VALUE,
    FE_BUNDLING_CARCS            as BUNDLING_CARCS,
)


# STEP 1 — TEMPORAL FEATURES

def add_temporal_features(df):
    print("\nStep 1: Temporal features")

    if SUBMISSION_DATE_COL in df.columns and FINAL_STATUS_DATE_COL in df.columns:
        raw_days = (df[FINAL_STATUS_DATE_COL] - df[SUBMISSION_DATE_COL]).dt.days
        df["days_to_adjudication"] = raw_days.clip(lower=0)
        print("  days_to_adjudication     : OK")

    if "claim_received_date" in df.columns and "service_date" in df.columns:
        received = pd.to_datetime(df["claim_received_date"], errors="coerce")
        service  = pd.to_datetime(df["service_date"],        errors="coerce")
        df["submission_lag_days"] = (received - service).dt.days.clip(lower=0)
        print("  submission_lag_days      : OK")
    else:
        df["submission_lag_days"] = np.nan
        print("  submission_lag_days      : NaN (claim_received_date or service_date not found)")

    return df


# STEP 2 — LIFECYCLE COUNT FEATURES

def add_lifecycle_count_features(df):
    print("\nStep 2: Lifecycle count features")

    is_resub = pd.Series(False, index=df.index)

    if "is_resubmitted" in df.columns:
        is_resub = is_resub | df["is_resubmitted"].astype(str).isin(["1", "True", "true"])

    if "claim_frequency_code" in df.columns:
        is_resub = is_resub | (df["claim_frequency_code"] == CORRECTED_SUBMISSION_CODE)

    if "original_reference_number" in df.columns:
        ref_clean = df["original_reference_number"].astype(str).str.strip()
        has_ref   = df["original_reference_number"].notna() & ref_clean.ne("") & ref_clean.ne("nan")
        is_resub  = is_resub | has_ref

    df["resubmission_indicator"] = is_resub.astype(int)
    print(f"  resubmission_indicator       : OK  ({df['resubmission_indicator'].sum():,} claims flagged)")

    if CLAIM_CONTROL_NUMBER_COL in df.columns:
        df["resubmission_count_per_claim"] = (
            df.groupby(CLAIM_CONTROL_NUMBER_COL)["resubmission_indicator"].transform("sum")
        )
        print("  resubmission_count_per_claim : OK")

    if GROUP_COL in df.columns and CLAIM_CONTROL_NUMBER_COL in df.columns:
        df["denial_count"] = (
            df.groupby(CLAIM_CONTROL_NUMBER_COL)[GROUP_COL]
              .transform(lambda x: x.isin(DENIAL_GROUP_CODES).sum())
        )
        print("  denial_count                 : OK")

    return df


# STEP 3 — FINANCIAL FEATURES

def add_financial_features(df):
    print("\nStep 3: Financial features")

    if "total_claim_charge" in df.columns and "total_paid_amount" in df.columns:
        billed = df["total_claim_charge"].fillna(0)
        paid   = df["total_paid_amount"].fillna(0)
        df["denied_amount"] = (billed - paid).clip(lower=0)
        print("  denied_amount                : OK")
    else:
        print("  denied_amount                : skipped (columns not found)")

    return df


# STEP 4 — FIELD PRESENCE FLAGS

def add_field_presence_flags(df):
    print("\nStep 4: Field presence flags")

    for flag_name, (source_col, absent_value) in MISSING_FLAG_FEATURES.items():

        if source_col not in df.columns:
            df[flag_name] = 0
            print(f"  {flag_name:40s}: 0  (column '{source_col}' not found)")
            continue

        if absent_value is None:
            df[flag_name] = df[source_col].notna().astype(int)
        else:
            df[flag_name] = (df[source_col] != absent_value).astype(int)

        n_filled = df[flag_name].sum()
        print(f"  {flag_name:40s}: OK  ({n_filled:,} rows filled)")

    return df


# STEP 5 — DENIAL CODE FEATURES

def add_denial_code_features(df):
    print("\nStep 5: Denial code features")

    if GROUP_COL in df.columns:
        for flag_name, group_code in DENIAL_GROUP_FLAGS.items():
            df[flag_name] = (df[GROUP_COL] == group_code).astype(int)
            print(f"  {flag_name:40s}: OK")

    if RARC_COL in df.columns:
        rarc_str = df[RARC_COL].astype(str).str.strip()
        df["has_rarc"] = (
            df[RARC_COL].notna()
            & rarc_str.ne("")
            & rarc_str.ne(RARC_ABSENT_VALUE)
            & rarc_str.ne("nan")
        ).astype(int)
        print(f"  has_rarc : OK  ({df['has_rarc'].sum():,} rows with RARC)")

    return df


# STEP 6 — CLINICAL FEATURES

def add_clinical_features(df):
    print("\nStep 6: Clinical features")

    diag_cols = [col for col in DIAGNOSIS_COLUMNS if col in df.columns]

    if diag_cols:
        def count_filled_diagnoses(row):
            count = 0
            for value in row:
                if pd.notna(value) and value != DIAGNOSIS_ABSENT_VALUE:
                    count += 1
            return count

        df["num_diagnoses"] = df[diag_cols].apply(count_filled_diagnoses, axis=1)
        print(f"  num_diagnoses                : OK  ({len(diag_cols)} diagnosis columns used)")

    return df


# STEP 7 — CLAIM STATUS FLAGS

def add_claim_status_flags(df):
    print("\nStep 7: Claim status flags")

    if INITIAL_OUTCOME_COL in df.columns:
        df["denial_flag_beh"] = (df[INITIAL_OUTCOME_COL] == CLAIM_DENIED_LABEL).astype(int)
        print(f"  denial_flag_beh              : OK  ({df['denial_flag_beh'].sum():,} denied)")
    else:
        df["denial_flag_beh"] = 0
        print("  denial_flag_beh              : 0   (initial_outcome not found)")

    if "claim_final_status" in df.columns:
        df["pend_flag_beh"] = (
            df["claim_final_status"].astype(str).str.strip() == PEND_STATUS_CODE
        ).astype(int)
        print(f"  pend_flag_beh                : OK  ({df['pend_flag_beh'].sum():,} pended)")
    else:
        df["pend_flag_beh"] = 0
        print("  pend_flag_beh                : 0   (claim_final_status not found)")

    return df


# STEP 8 — AUTH AND PRIOR-AUTHORISATION FLAGS

def add_auth_and_pa_flags(df):
    print("\nStep 8: Auth and prior-auth flags")

    denial = pd.Series(False, index=df.index)
    if "is_denied" in df.columns:
        denial = denial | (df["is_denied"] == 1)
    if "line_paid_amount" in df.columns:
        paid_zero = df["line_paid_amount"].notna() & (df["line_paid_amount"] <= 0)
        denial = denial | paid_zero
    df["denial_flag"] = denial.astype(int)
    print(f"  denial_flag                  : OK  ({df['denial_flag'].sum():,} denied lines)")

    if CARC_COL in df.columns:
        carc = df[CARC_COL].astype(str).str.strip()
        carc = carc.replace({"nan": "NONE", "None": "NONE", "": "NONE", "0": "NONE"})
        df["carc_code"] = carc
    else:
        df["carc_code"] = "NONE"
    print("  carc_code                    : OK")

    if "prior_authorization_number" in df.columns:
        token = df["prior_authorization_number"].astype(str).str.strip()
        df["auth_token_present"] = (~token.isin({"", "nan", "None", "0"})).astype(int)
    else:
        df["auth_token_present"] = 0
    print(f"  auth_token_present           : OK  ({df['auth_token_present'].sum():,} with auth)")

    df["carc197_flag"] = (df["carc_code"] == "197").astype(int)
    print(f"  carc197_flag                 : OK  ({df['carc197_flag'].sum():,} CARC-197 lines)")

    df["post_approved_then_denied"] = (
        (df["auth_token_present"] == 1) &
        (df["denial_flag"]        == 1) &
        (df["carc197_flag"]       == 1)
    ).astype(int)
    print(f"  post_approved_then_denied    : OK  ({df['post_approved_then_denied'].sum():,} contradictions)")

    df["surprise_pa"] = (
        (df["auth_token_present"] == 0) &
        (df["denial_flag"]        == 1) &
        (df["carc197_flag"]       == 1)
    ).astype(int)
    print(f"  surprise_pa                  : OK  ({df['surprise_pa'].sum():,} surprise-PA denials)")

    return df


# STEP 9 — LINE-LEVEL DETAIL FLAGS

def add_line_detail_flags(df):
    print("\nStep 9: Line-level detail flags")

    if "units" in df.columns and "units_paid" in df.columns:
        billed_units = df["units"].fillna(0)
        paid_units   = df["units_paid"].fillna(0)
        shortfall    = (billed_units - paid_units).clip(lower=0)
        df["line_qty_shave_flag"] = (shortfall > 0).astype(int)
        df["line_unit_shortfall"] = shortfall
        print(f"  line_qty_shave_flag          : OK  ({df['line_qty_shave_flag'].sum():,} shaved lines)")
        print(f"  line_unit_shortfall          : OK")
    else:
        df["line_qty_shave_flag"] = 0
        df["line_unit_shortfall"] = 0.0
        print("  line_qty_shave_flag          : 0   (units or units_paid not found)")
        print("  line_unit_shortfall          : 0.0 (units or units_paid not found)")

    if CARC_COL in df.columns:
        carc_str       = df[CARC_COL].astype(str).str.strip()
        bundling_codes = [str(c) for c in BUNDLING_CARCS]
        df["line_bundled_any_flag"] = carc_str.isin(bundling_codes).astype(int)
        print(f"  line_bundled_any_flag        : OK  ({df['line_bundled_any_flag'].sum():,} bundled lines)")
    else:
        df["line_bundled_any_flag"] = 0
        print("  line_bundled_any_flag        : 0   (CARC column not found)")

    df["line_downcode_any_flag"]   = 0
    df["line_downcode_amount_sum"] = 0.0
    print("  line_downcode_any_flag       : 0   (835 has no separate paid CPT field)")
    print("  line_downcode_amount_sum     : 0.0 (835 has no separate paid CPT field)")

    return df
