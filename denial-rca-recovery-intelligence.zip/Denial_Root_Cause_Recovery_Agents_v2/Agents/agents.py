"""
agents.py
---------
Pipeline node functions and conditional routing helpers.

Pipeline
--------
decision_agent
    → [route_after_decision]
        → ml_agent
            → [route_after_ml]
                → retrieval_agent → rca_agent → evidence_agent → nba_agent
                → evidence_agent  → nba_agent                   (no RECOVERABLE lines)
        → nba_agent                                              (all CO/PR lines)

Node responsibilities
---------------------
decision_agent   Collects unique GROUP codes; writes state["group"], state["group_values"].
ml_agent         Scores non-CO/PR lines; classifies recovery status; writes state["ml_results"].
retrieval_agent  Resolves CARC/RARC/CPT descriptions for RECOVERABLE lines; writes state["retrieval_results"].
rca_agent        Root-cause analysis for RECOVERABLE lines; writes state["rca_results"].
evidence_agent   Denial evidence for all non-CO/PR lines; writes state["evidence_results"].
nba_agent        Next Best Action for every line; writes state["line_decisions"].

Routing helpers
---------------
route_after_decision  → "ml"        when any line is non-CO/PR, else "nba"
route_after_ml        → "retrieval" when any line is RECOVERABLE, else "evidence"

LLM calls
---------
retrieval_agent  RETRIEVAL_SYSTEM_PROMPT — CARC/RARC/CPT/modifier descriptions
rca_agent        RCA_PROMPT             — root-cause explanation
evidence_agent   EVIDENCE_PROMPT        — denial evidence + flag signals
nba_agent        NBA_PROMPT             — payer behaviour + action steps

All LLM-generated fields have rule-based fallbacks so any exception leaves
the function with valid deterministic output.

Config
------
All thresholds, column names, action costs, and code mappings come from
Config/config.py — no business rules are hard-coded here.
"""

import json

import pandas as pd

from Config.config import (
    GROUP_CODE_CO,
    GROUP_CODE_PR,
    CARC_COLUMN,
    RARC_COLUMN,
    NBA_ACTION_APPEAL,
    NBA_ACTION_REBILL,
    NBA_ACTION_WRITE_OFF,
    NBA_ACTION_BILL_PATIENT,
    NBA_ACTION_COSTS,
    RECOVERY_STATUS_NOT_RECOVERABLE,
    RECOVERY_STATUS_RECOVERABLE,
    RECOVERY_STATUS_EV_WRITE_OFF,
    RECOVERY_CHANNEL_APPEAL,
    RECOVERY_CHANNEL_REBILL,
    ACTION_PROB_MIN_SAMPLES,
    PAYER_BEHAVIOR_CATEGORIES,
    EBS_SIGNAL_METRICS,
    EARLY_SIGNAL_MESSAGES,
    KRI_FIELD_MAPPINGS,
    KPI_FIELD_MAPPINGS,
    SUBMISSION_FLAG_LABELS,
    DENIAL_GROUP_LABELS,
    CLAIM_STATUS_LABELS,
)
from Models.llm import ask_llm
from Models.ml_predictor import get_predictor
from Models.vector_store import search_similar_lines
from Prompts.evidence_prompt import EVIDENCE_PROMPT
from Prompts.nba_prompt import NBA_PROMPT
from Prompts.rca_prompt import RCA_PROMPT
from Prompts.retrieval_prompt import RETRIEVAL_SYSTEM_PROMPT, RETRIEVAL_USER_PROMPT
from Utilits.logger import get_logger

logger = get_logger(__name__)


# ---------------------------------------------------------------------------
# Module-level globals
# ---------------------------------------------------------------------------

# Multi-level action probability table — loaded once at startup by main.py.
# Nested by specificity: carc_int → by_payer → by_rarc (most → least specific).
# nba_agent selects the most specific level that has enough samples:
#   Payer+CARC+RARC → CARC+RARC → CARC-only.
action_prob_table: dict = {}

# Payer-level KRI/KPI lookup table — loaded once at startup by main.py.
# Keyed by payer_id (str). Values are flat dicts of KRI/KPI metric columns
# matching KRI_FIELD_MAPPINGS and KPI_FIELD_MAPPINGS in config.py.
payer_kri_kpi_table: dict = {}


def set_payer_kri_kpi_table(table: dict) -> None:
    """
    Store the pre-built payer KRI/KPI table in the module-level singleton.

    Called once at startup by main.py after build_payer_kri_kpi_table() runs.
    nba_agent looks up payer_id to populate KRI and KPI sections without
    requiring those columns to exist in merged_cleaned.xlsx.

    Parameters
    ----------
    table : dict
        Output of data_loader.build_payer_kri_kpi_table() —
        {payer_id_str: {metric_col: value, ...}}.
    """
    global payer_kri_kpi_table
    payer_kri_kpi_table = table
    logger.info("Payer KRI/KPI table loaded — %d payers.", len(table))


def set_action_prob_table(table: dict) -> None:
    """
    Store the pre-built action probability table in the module-level singleton.

    Called once at startup by main.py after build_action_prob_table() runs.
    The table is keyed by CARC code (int) and nested by payer and RARC, allowing
    nba_agent to look up historical appeal/resubmit rates at four specificity levels.

    Parameters
    ----------
    table : dict
        Output of data_loader.build_action_prob_table() — see that function's
        docstring for the exact nested structure.
    """
    global action_prob_table
    action_prob_table = table
    logger.info("Action probability table loaded — %d CARC entries.", len(table))


def parse_llm_json(text: str) -> dict:
    """
    Extract and parse the first JSON object from an LLM response string.

    Strips markdown code fences (```json ... ```) and uses raw_decode so any
    trailing prose after the closing brace is ignored without raising an error.

    Parameters
    ----------
    text : str
        Raw string returned by ask_llm().

    Returns
    -------
    dict
        Parsed JSON object, or {} if no valid JSON object is found.
    """
    clean = text.replace("```json", "").replace("```", "").strip()
    try:
        obj, _ = json.JSONDecoder().raw_decode(clean)
        return obj if isinstance(obj, dict) else {}
    except (ValueError, json.JSONDecodeError):
        return {}


def get_carc_rarc(data: dict) -> tuple:
    """
    Extract denial code identifiers from a claim sub-dict.

    The action probability table is keyed by int CARC, so carc_int is provided
    for table lookups. rarc_code is a clean string (or None) safe to use as a
    dict key after stripping sentinel values ("nan", "None", "").

    Parameters
    ----------
    data : dict
        Any dict that contains CARC_COLUMN and RARC_COLUMN keys (RCA, ML, or raw).

    Returns
    -------
    tuple : (carc_int, carc_raw, rarc_code, rarc_raw)
        carc_int  — int or None (used for action_prob_table lookup)
        carc_raw  — original value from data (may be str, int, float, or None)
        rarc_code — clean str or None (sentinel values replaced with None)
        rarc_raw  — original value from data
    """
    carc_raw = data.get(CARC_COLUMN)
    carc_int = None
    try:
        carc_int = int(carc_raw) if carc_raw is not None else None
    except (ValueError, TypeError):
        pass

    rarc_raw  = data.get(RARC_COLUMN)
    rarc_code = (
        str(rarc_raw)
        if rarc_raw is not None and str(rarc_raw) not in ("nan", "None", "")
        else None
    )
    return carc_int, carc_raw, rarc_code, rarc_raw


def compute_expected_values(recovery_prob: float, denied_amount: float) -> dict:
    """
    Compute the expected monetary value (EV) for every recoverable action.

    Formula: EV(action) = P(recover | action) × abs(denied_amount) − cost(action)

    Write Off is included with P=0 (no recovery attempted) to allow nba_agent
    to compare it against positive-EV actions. Bill Patient is excluded — it is
    only valid on the CO/PR rule-based path, not a denial-recovery action.
    Action costs come from NBA_ACTION_COSTS in config.py.

    Parameters
    ----------
    recovery_prob : float
        The ML model's P(Recovered) for this service line (0–1).
    denied_amount : float
        Raw denied amount from the claim; abs() is applied internally.

    Returns
    -------
    dict
        {action_name: expected_value_float} for Appeal, Resubmit, and Write Off.
    """
    raw_amount   = abs(denied_amount)
    ev_by_action = {}
    for action, cost in NBA_ACTION_COSTS.items():
        if action == NBA_ACTION_BILL_PATIENT:
            continue
        prob = 0.0 if action == NBA_ACTION_WRITE_OFF else recovery_prob
        ev_by_action[action] = round(prob * raw_amount - cost, 2)
    return ev_by_action


def decision_agent(state: dict) -> dict:
    """
    Collect unique GROUP codes across all service lines of the claim.

    Reads
    -----
    state["claim"]["service_lines"] : list[dict]
        Each service line dict must contain a "GROUP" key (CO, PR, OA, PI, …).

    Writes
    ------
    state["group_values"] : list[str]
        Ordered list of unique GROUP codes seen across all lines.
    state["group"] : str | None
        GROUP code of the first service line; used by downstream routing.
    """
    claim_data   = state.get("claim", {})
    line_items   = claim_data.get("service_lines", [])
    claim_id     = state.get("claim_id", "unknown")
    group_values = []

    logger.info(
        "[%s] DECISION AGENT | Input: %d service line(s) | Per-line groups: %s",
        claim_id, len(line_items),
        [(ln.get("line_number"), str(ln.get("GROUP", "")).strip().upper()) for ln in line_items],
    )

    for line in line_items:
        group = str(line.get("GROUP", "")).strip().upper()
        if group and group not in group_values:
            group_values.append(group)

    state["group_values"] = group_values
    state["group"]        = group_values[0] if group_values else None

    logger.info("[%s] Decision agent — unique GROUP values across lines = %s", claim_id, group_values)
    logger.info(
        "[%s] DECISION AGENT | Output: primary_group=%s | all_groups=%s | route → %s",
        claim_id, state["group"], group_values,
        "ml" if any(g not in (GROUP_CODE_CO, GROUP_CODE_PR) for g in group_values) else "nba",
    )
    return state

def route_after_decision(state: dict) -> str:
    """
    LangGraph conditional-edge router after decision_agent.

    Returns "ml" when at least one service line has a GROUP code that is not CO
    or PR (those lines need ML scoring). Returns "nba" when every line is CO or
    PR (direct rule-based path, no model involved).

    Reads
    -----
    state["group_values"] : list[str]
    """
    group_values = state.get("group_values", [])
    needs_ml     = any(g not in (GROUP_CODE_CO, GROUP_CODE_PR) for g in group_values)
    return "ml" if needs_ml else "nba"


def ml_agent(state: dict) -> dict:
    """
    Score every non-CO/PR service line with the ML model and classify recovery status.

    Passes raw merged rows to RecoveryPredictor.predict() as a single DataFrame
    (one call for all lines of the claim). Each prediction yields a recovery
    probability, a predicted class, top SHAP drivers, and payer signals.

    Recovery status is assigned in order:
      - "Not Recovered" prediction          → NOTRECOVERABLE  (skip RCA/NBA)
      - Best pursuit EV ≤ 0                 → EV_WRITE_OFF     (skip RCA/NBA)
      - Otherwise                           → RECOVERABLE      (continue to retrieval)

    Stamps on each service line dict
    ---------------------------------
    line["model_output"]  : {ml_prediction, recovery_probability, recovery_percent, top_shap_drivers}
    line["_payer_signals"]: raw payer behaviour and EBS signal dict from the predictor
    line["_ev_context"]   : {action_name: expected_value} computed by compute_expected_values()
    line["recovery_status"]: one of the RECOVERY_STATUS_* constants

    Writes
    ------
    state["ml_results"] : list[dict]
        One summary dict per scored line: {line_number, recovery_probability,
        recovery_status, ev_by_action}.
    """
    claim_data = state.get("claim", {})
    line_items = claim_data.get("service_lines", [])
    claim_id   = state.get("claim_id", "unknown")
    ml_results = []

    ml_lines = [
        line for line in line_items
        if str(line.get("GROUP", "")).strip().upper() not in (GROUP_CODE_CO, GROUP_CODE_PR)
    ]

    logger.info(
        "[%s] ML AGENT | Input: %d total line(s) | %d line(s) to score (non-CO/PR) | Skipped (CO/PR): %d",
        claim_id, len(line_items), len(ml_lines), len(line_items) - len(ml_lines),
    )
    logger.info("[%s] Line decision agent — %d service lines to process.", claim_id, len(line_items))

    if not ml_lines:
        logger.info("[%s] ML AGENT | No scorable lines — all CO/PR. Exiting.", claim_id)
        state["ml_results"] = ml_results
        return state

    predictor  = get_predictor()
    rawrows   = [
        line.get("raw") or {**line.get("ML", {}), **line.get("RCA", {}), **line.get("Evidence", {}), "GROUP": line.get("GROUP")}
        for line in ml_lines
    ]
    raw_preds  = predictor.predict(pd.DataFrame(rawrows))
    predictions = raw_preds if isinstance(raw_preds, list) else [raw_preds]

    for index, line in enumerate(ml_lines):
        if index >= len(predictions):
            continue

        prediction           = predictions[index]
        recovery_probability = prediction.get("probability", 0)
        predicted_class      = prediction.get("predicted_class", "Not Recovered")

        denied_amount = (
            prediction.get("denied_amount")
            or line.get("Evidence", {}).get("denied_amount")
            or line.get("raw", {}).get("denied_amount")
            or 0
        )
        ev_by_action = compute_expected_values(recovery_probability, denied_amount)

        if predicted_class == "Not Recovered":
            recovery_status = RECOVERY_STATUS_NOT_RECOVERABLE
        else:
            pursuit_evs = {a: v for a, v in ev_by_action.items() if a != NBA_ACTION_WRITE_OFF}
            best_ev     = max(pursuit_evs.values()) if pursuit_evs else float("-inf")
            recovery_status = (
                RECOVERY_STATUS_EV_WRITE_OFF if best_ev <= 0
                else RECOVERY_STATUS_RECOVERABLE
            )

        payer_signals = prediction.get("payer_signals") or {}
        mergedrow    = rawrows[index]

        # Predictor returns shap_top_features as {feature: shap_value}.
        # Convert to the list-of-objects format expected by the output schema.
        shap_dict         = prediction.get("shap_top_features") or {}
        shap_top_features = (
            [
                {
                    "feature"     : feat,
                    "value"       : mergedrow.get(feat),
                    "contribution": round(val, 4),
                }
                for feat, val in shap_dict.items()
            ]
            if isinstance(shap_dict, dict)
            else shap_dict
        )

        # Stamp onto the line so downstream agents can read all ML outputs.
        line["model_output"] = {
            "ml_prediction"       : predicted_class,
            "recovery_probability": round(recovery_probability, 4),
            "recovery_percent"    : f"{recovery_probability:.1%}",
            "top_shap_drivers"    : shap_top_features,
        }
        line["_payer_signals"]  = payer_signals
        line["_ev_context"]     = ev_by_action
        line["recovery_status"] = recovery_status

        line_num     = line.get("line_number")
        line_group   = str(line.get("GROUP", "")).strip().upper()
        shap_str     = " | ".join(
            f"{f['feature']}={f['value']} (contrib={f['contribution']})"
            for f in shap_top_features
        ) or "N/A"
        logger.info("[%s] Line %s — GROUP=%s", claim_id, line_num, line_group)
        logger.info(
            "[%s] Line %s | ML MODEL — Output:\n  Prediction: %s\n  Recovery Probability: %.4f (%.1f%%)\n  Top Features: %s",
            claim_id, line_num,
            predicted_class,
            recovery_probability, recovery_probability * 100,
            shap_str,
        )
        logger.info(
            "[%s] Line %s | ML AGENT | Recovery Classification: %s | "
            "EV — Appeal: $%.2f | Resubmit: $%.2f | Write Off: $%.2f",
            claim_id, line_num, recovery_status,
            ev_by_action.get(NBA_ACTION_APPEAL, 0),
            ev_by_action.get(NBA_ACTION_REBILL, 0),
            ev_by_action.get(NBA_ACTION_WRITE_OFF, 0),
        )

        ml_results.append({
            "line_number"         : line.get("line_number"),
            "recovery_probability": recovery_probability,
            "recovery_status"     : recovery_status,
            "ev_by_action"        : ev_by_action,
        })

    logger.info(
        "[%s] ML AGENT | Output: %d line(s) scored | Classifications: %s | route → %s",
        claim_id, len(ml_results),
        [(r["line_number"], r["recovery_status"], f"{r['recovery_probability']:.0%}") for r in ml_results],
        "retrieval" if any(r["recovery_status"] == RECOVERY_STATUS_RECOVERABLE for r in ml_results) else "evidence",
    )
    state["ml_results"] = ml_results
    return state


def route_after_ml(state: dict) -> str:
    """
    LangGraph conditional-edge router after ml_agent.

    Returns "retrieval" when at least one line has recovery_status == RECOVERABLE
    (those lines need CARC/RARC/CPT resolution and RCA before evidence).
    Returns "evidence" when no line is recoverable (skip retrieval and RCA entirely).

    Reads
    -----
    state["ml_results"] : list[dict]
    """
    ml_results      = state.get("ml_results", [])
    hasrecoverable = any(
        r.get("recovery_status") == RECOVERY_STATUS_RECOVERABLE
        for r in ml_results
    )
    return "retrieval" if hasrecoverable else "evidence"


def retrieval_agent(carc_raw, rarc_raw, cpt_raw, claim_id, line_num=None, modifier_raw=None):
    """
    Resolve official definitions for CARC, RARC, CPT, and modifier codes via LLM.

    Sends a structured JSON payload to the LLM using RETRIEVAL_SYSTEM_PROMPT and
    parses the returned JSON for carc_definition, rarc_definition, cpt_description,
    modifier_description, modifier_cpt_compatibility, and modifier_denialrisk.

    Called by retrieval_node once per RECOVERABLE service line. The returned dict
    is stamped onto line["retrieval_context"] so that rca_agent and nba_agent
    can read enriched code descriptions without making their own LLM calls.

    Parameters
    ----------
    carc_raw    : CARC code value as stored in the ADS (str, int, or float).
    rarc_raw    : RARC code value as stored in the ADS, or None.
    cpt_raw     : Procedure code value as stored in the ADS, or None.
    claim_id    : Claim control number string — used for log labels only.
    line_num    : Service line number — used for log labels only.
    modifier_raw: Procedure modifier value, or None.

    Returns
    -------
    dict with keys: "carc", "rarc", "cpt", "modifier"
        Each value is either a sub-dict {"description": str, ...} or None.
        Falls back to {"carc": None, "rarc": None, "cpt": None, "modifier": None}
        on any LLM or parsing failure.
    """
    label = f"[{claim_id}" + (f" L{line_num}]" if line_num else "]")
    empty = {"carc": None, "rarc": None, "cpt": None, "modifier": None}

    if not carc_raw and not rarc_raw and not cpt_raw and not modifier_raw:
        return empty

    try:
        claim_dict = {
            "carc"    : str(carc_raw)     if carc_raw     else "",
            "rarc"    : str(rarc_raw)     if rarc_raw     else "",
            "cpt"     : str(cpt_raw)      if cpt_raw      else "",
            "modifier": str(modifier_raw) if modifier_raw else "",
        }
        user_content = RETRIEVAL_USER_PROMPT.format(
            claim_json=json.dumps(claim_dict, indent=4)
        )

        logger.info("%s Retrieval Agent — LLM Input:\n%s", label, json.dumps(claim_dict, indent=2))
        print(f"\n{'─'*60}\n{label} | RETRIEVAL AGENT — LLM Input\n{'─'*60}\n{json.dumps(claim_dict, indent=2)}")

        raw      = ask_llm(RETRIEVAL_SYSTEM_PROMPT, user_content, agent_name="retrieval")
        parsed   = parse_llm_json(raw)

        retrieval    = parsed.get("retrieval") or {}
        carc_def     = retrieval.get("carc_definition") or ""
        rarc_def     = retrieval.get("rarc_definition") or ""
        cpt_def      = retrieval.get("cpt_description") or ""
        mod_def      = retrieval.get("modifier_description") or ""
        mod_validity = retrieval.get("modifier_cpt_compatibility") or ""
        mod_denial   = retrieval.get("modifier_denialrisk") or ""

        logger.info(
            "%s Retrieval Agent — LLM Output:\n  CARC Definition: %s\n  RARC Definition: %s\n"
            "  CPT Description: %s\n  Modifier Description: %s\n"
            "  Modifier-CPT Compatibility: %s\n  Modifier Denial Risk: %s",
            label,
            carc_def or "N/A", rarc_def or "N/A",
            cpt_def or "N/A", mod_def or "N/A",
            mod_validity or "N/A", mod_denial or "N/A",
        )
        print(
            f"\n{label} | RETRIEVAL AGENT — LLM Output"
            f"\n  CARC Definition           : {carc_def or 'N/A'}"
            f"\n  RARC Definition           : {rarc_def or 'N/A'}"
            f"\n  CPT Description           : {cpt_def or 'N/A'}"
            f"\n  Modifier Description      : {mod_def or 'N/A'}"
            f"\n  Modifier-CPT Compatibility: {mod_validity or 'N/A'}"
            f"\n  Modifier Denial Risk      : {mod_denial or 'N/A'}"
        )

        logger.info(
            "%s Retrieval — CARC=%s RARC=%s CPT=%s Modifier=%s resolved.",
            label, carc_raw or "N/A", rarc_raw or "N/A", cpt_raw or "N/A", modifier_raw or "N/A",
        )
        return {
            "carc"    : {"description": carc_def}  if carc_def  else None,
            "rarc"    : {"description": rarc_def}  if rarc_def  else None,
            "cpt"     : {"description": cpt_def}   if cpt_def   else None,
            "modifier": {
                "description" : mod_def,
                "compatibility": mod_validity,
                "denialrisk"  : mod_denial,
            } if (mod_def or mod_validity or mod_denial) else None,
        }

    except Exception as exc:
        logger.warning("%s Retrieval failed: %s", label, exc)
        return empty


def retrieval_node(state: dict) -> dict:
    """
    LangGraph node: call retrieval_agent for every RECOVERABLE service line.

    Iterates over all service lines and skips any whose recovery_status is not
    RECOVERABLE. For each RECOVERABLE line, calls retrieval_agent() and stamps
    the returned code definitions onto line["retrieval_context"] so that
    rca_agent can consume them in the next graph step.

    Reads
    -----
    state["claim"]["service_lines"] : list[dict]
        Each line must have a "RCA" sub-dict with CARC, RARC, procedure_code,
        and optional modifier columns, and a "recovery_status" key set by ml_agent.

    Writes
    ------
    state["retrieval_results"] : list[dict]
        One dict per RECOVERABLE line: {line_number, carc, rarc, cpt, modifier}.
    line["retrieval_context"] : dict
        Same structure as the retrieval_agent return value — consumed by rca_agent.
    """
    claim_data        = state.get("claim", {})
    line_items        = claim_data.get("service_lines", [])
    claim_id          = state.get("claim_id", "unknown")
    retrieval_results = []

    recoverable = [l for l in line_items if l.get("recovery_status") == RECOVERY_STATUS_RECOVERABLE]
    logger.info(
        "[%s] RETRIEVAL NODE | Input: %d RECOVERABLE line(s) to resolve "
        "(CARC / RARC / CPT / Modifier descriptions via LLM)",
        claim_id, len(recoverable),
    )

    for line in line_items:
        if line.get("recovery_status") != RECOVERY_STATUS_RECOVERABLE:
            continue

        try:
            rca_data       = line.get("RCA", {})
            retrieval_data = retrieval_agent(
                rca_data.get(CARC_COLUMN),
                rca_data.get(RARC_COLUMN),
                rca_data.get("procedure_code"),
                claim_id,
                line.get("line_number"),
                rca_data.get("procedure_modifier_1") or rca_data.get("line_procedure_modifier_1"),
            )

            # Stamp onto the line so rca_agent can read it directly.
            line["retrieval_context"] = retrieval_data

            ln = line.get("line_number")
            if retrieval_data.get("carc"):
                logger.info("[%s] Line %s — CARC description source: retrieval_agent", claim_id, ln)
            if retrieval_data.get("rarc"):
                logger.info("[%s] Line %s — RARC description source: retrieval_agent", claim_id, ln)
            cpt_src = "retrieval_agent" if retrieval_data.get("cpt") else "N/A"
            mod_src = "retrieval_agent" if retrieval_data.get("modifier") else "N/A"
            logger.info(
                "[%s] Line %s — CPT description source: %s | Modifier description source: %s",
                claim_id, ln, cpt_src, mod_src,
            )
            logger.info(
                "[%s] Line %s | RETRIEVAL NODE | Resolved: "
                "CARC=%s | RARC=%s | CPT=%s | Modifier=%s",
                claim_id, ln,
                "✓" if retrieval_data.get("carc") else "✗",
                "✓" if retrieval_data.get("rarc") else "✗",
                "✓" if retrieval_data.get("cpt") else "✗",
                "✓" if retrieval_data.get("modifier") else "✗",
            )

            retrieval_results.append({
                "line_number": line.get("line_number"),
                "carc"       : retrieval_data.get("carc"),
                "rarc"       : retrieval_data.get("rarc"),
                "cpt"        : retrieval_data.get("cpt"),
                "modifier"   : retrieval_data.get("modifier"),
            })

        except Exception as exc:
            logger.exception("Retrieval failed for line %s: %s", line.get("line_number"), exc)

    logger.info(
        "[%s] RETRIEVAL NODE | Output: %d line(s) resolved | "
        "Passing descriptions → rca_agent via line['retrieval_context']",
        claim_id, len(retrieval_results),
    )
    state["retrieval_results"] = retrieval_results
    return state


def rca_agent(state: dict) -> dict:
    """
    LangGraph node: produce a structured Root Cause Analysis for every RECOVERABLE line.

    Builds a rich LLM context from the denial codes (CARC/RARC with descriptions
    from retrieval_agent), procedure info (CPT, modifier, compatibility, denial risk),
    diagnoses (principal + secondary + tertiary), submission flags (prior auth, NPI,
    attachment), and the ML model output (recovery probability + top SHAP drivers).
    Sends this context to the LLM using RCA_PROMPT and parses the "summary" field.

    Reads per line
    --------------
    line["RCA"]                : raw RCA columns from the ADS
    line["Evidence"]           : used for denied_amount and service_date
    line["retrieval_context"] : CARC/RARC/CPT/modifier descriptions from retrieval_node
    line["model_output"]       : recovery_probability, ml_prediction, top_shap_drivers
    line["recovery_status"]    : must equal RECOVERABLE for the line to be processed

    Stamps on each processed line
    ------------------------------
    line["root_cause_analysis"] : {carc_code, carc_description, rarc_code,
                                   rarc_description, summary}
    line["rca_context"]        : same dict — consumed by evidence_agent and nba_agent

    Writes
    ------
    state["rca_results"] : list[dict]
        One dict per processed line: {line_number, carc_description, rarc_description,
        cpt_description, root_cause_analysis}.
    """
    claim_data  = state.get("claim", {})
    line_items  = claim_data.get("service_lines", [])
    claim_id    = state.get("claim_id", "unknown")
    rca_results = []

    rca_lines = [l for l in line_items if l.get("recovery_status") == RECOVERY_STATUS_RECOVERABLE]
    logger.info(
        "[%s] RCA AGENT | Input: %d RECOVERABLE line(s) | "
        "Context: CARC+RARC descriptions + CPT + Modifier + ML SHAP + Auth flags",
        claim_id, len(rca_lines),
    )

    for line in line_items:
        if line.get("recovery_status") != RECOVERY_STATUS_RECOVERABLE:
            continue

        try:
            rca_data = line.get("RCA", {})
            # retrieval_agent ran before this node — read the already-stamped context.
            retrieval_data = line.get("retrieval_context") or {}

            carc_def = (retrieval_data.get("carc") or {}).get("description") or f"CARC {rca_data.get(CARC_COLUMN)}"
            rarc_def = (retrieval_data.get("rarc") or {}).get("description") or ""
            cpt_def  = (retrieval_data.get("cpt")  or {}).get("description") or ""
            ev_data  = line.get("Evidence", {})

            mod_info     = retrieval_data.get("modifier") or {}
            modifier_val = rca_data.get("procedure_modifier_1") or rca_data.get("line_procedure_modifier_1")
            model_out    = line.get("model_output", {})
            prob         = model_out.get("recovery_probability", 0)
            prediction   = model_out.get("ml_prediction", "Unknown")
            top_features = model_out.get("top_shap_drivers") or []

            flag_statusrca = lambda v: "Present" if v == 1 else ("Missing" if v == 0 else "Unknown")
            denial_grp = next(
                (label for flag, label in DENIAL_GROUP_LABELS.items() if rca_data.get(flag)),
                line.get("GROUP") or "Unknown",
            )
            rarc_line = (
                f"RARC {rca_data.get(RARC_COLUMN)}: {rarc_def}\n" if rarc_def
                else (f"RARC {rca_data.get(RARC_COLUMN)}\n" if rca_data.get(RARC_COLUMN) else "RARC: None\n")
            )
            feature_lines = "\n".join(
                f"  - {f['feature']} = {f['value']} (contribution={f['contribution']})"
                for f in top_features
            ) or "  - No SHAP drivers available."

            rca_context = (
                f"Payer: {rca_data.get('payer_name') or rca_data.get('payer_id') or 'Unknown'}\n"
                f"Denial Group: {denial_grp}\n"
                f"\nDENIAL CODES\n"
                f"CARC {rca_data.get(CARC_COLUMN)}: {carc_def}\n"
                f"{rarc_line}"
                f"\nPROCEDURE\n"
                f"CPT Code: {rca_data.get('procedure_code') or 'Unknown'}\n"
                f"CPT Description: {cpt_def or 'Not available'}\n"
                f"Modifier: {modifier_val or 'None'}\n"
                f"Modifier Description: {mod_info.get('description') or 'Not available'}\n"
                f"Modifier-CPT Compatibility: {mod_info.get('compatibility') or 'Not assessed'}\n"
                f"Modifier Denial Risk: {mod_info.get('denialrisk') or 'Not assessed'}\n"
                f"\nDIAGNOSES\n"
                f"Principal Diagnosis: {rca_data.get('principal_diagnosis') or 'Unknown'}\n"
                f"Secondary Diagnosis: {rca_data.get('diagnosis_2') or 'None'}\n"
                f"Tertiary Diagnosis: {rca_data.get('diagnosis_3') or 'None'}\n"
                f"\nAUTHORIZATION AND SUBMISSION FLAGS\n"
                f"Prior Authorization Number: {rca_data.get('prior_authorization_number') or 'None on file'}\n"
                f"Prior Auth Present: {flag_statusrca(rca_data.get('has_prior_auth'))}\n"
                f"Modifier Present: {flag_statusrca(rca_data.get('has_modifier'))}\n"
                f"Attachment Present: {flag_statusrca(rca_data.get('has_attachment'))}\n"
                f"Billing Provider NPI: {flag_statusrca(rca_data.get('has_billing_provider_npi'))}\n"
                f"Rendering Provider NPI: {flag_statusrca(rca_data.get('has_rendering_provider_npi'))}\n"
                f"\nML MODEL OUTPUT\n"
                f"Recovery Probability: {prob:.1%}\n"
                f"ML Prediction: {prediction}\n"
                f"Top Contributing Features (SHAP):\n{feature_lines}\n"
            )

            logger.info("[%s] Line %s | RCA AGENT — LLM Input:\n%s", claim_id, line.get("line_number"), rca_context)
            rawrca    = ask_llm(RCA_PROMPT, rca_context, agent_name="rca")
            rca_parsed = parse_llm_json(rawrca)
            rca_summary      = rca_parsed.get("summary") or (rawrca if not rca_parsed else "")
            rca_primaryrc   = rca_parsed.get("primaryroot_cause") or None
            rca_secondaryrc = rca_parsed.get("secondaryroot_cause") or None
            logger.info("[%s] Line %s | RCA AGENT — LLM Output:\n%s", claim_id, line.get("line_number"), rca_summary)

            rca_output = {
                "carc_code"           : rca_data.get(CARC_COLUMN),
                "carc_description"    : carc_def,
                "rarc_code"           : rca_data.get(RARC_COLUMN),
                "rarc_description"    : rarc_def or None,
                "primaryroot_cause"  : rca_primaryrc,
                "secondaryroot_cause": rca_secondaryrc,
                "summary"             : rca_summary,
            }

            logger.info(
                "[%s] Line %s | RCA AGENT | Output summary:\n"
                "  Primary Root Cause   : %s\n"
                "  Secondary Root Cause : %s\n"
                "  CARC                 : %s | RARC: %s",
                claim_id, line.get("line_number"),
                rca_primaryrc or "N/A",
                rca_secondaryrc or "N/A",
                rca_output.get("carc_code"), rca_output.get("rarc_code"),
            )

            # Stamp onto the line so evidence_agent and nba_agent can read it.
            line["root_cause_analysis"] = rca_output
            line["rca_context"]        = rca_output

            rca_results.append({
                "line_number"        : line.get("line_number"),
                "carc_description"   : carc_def,
                "rarc_description"   : rarc_def,
                "cpt_description"    : cpt_def,
                "root_cause_analysis": rca_output,
            })

        except Exception as exc:
            logger.exception("RCA failed for line %s: %s", line.get("line_number"), exc)

    logger.info(
        "[%s] RCA AGENT | Output: %d line(s) analyzed | "
        "Passing rca_output → evidence_agent via line['rca_context']",
        claim_id, len(rca_results),
    )
    state["rca_results"] = rca_results
    return state


def build_line_evidence(claim_id: str, line_num, ev_data: dict, rca_out) -> dict:
    """
    Build structured denial evidence for one service line via LLM.

    Constructs a detailed context from claim attributes (payer, procedure, diagnoses,
    dates, amounts, submission flags) and the RCA summary produced by rca_agent, then
    calls the LLM using EVIDENCE_PROMPT. Parses denial_evidence (list), flag_signals
    (list), and evidence_summary (str) from the JSON response.

    CO and PR lines are excluded upstream by evidence_agent — this function is only
    called for non-CO/PR lines regardless of their recovery status.

    Parameters
    ----------
    claim_id : str
        Claim control number — used for log labels only.
    line_num : int | str
        Service line number — used for log labels only.
    ev_data  : dict
        The line's "Evidence" sub-dict from the ADS containing procedure, diagnosis,
        financial, and submission flag columns.
    rca_out  : dict | None
        The structured RCA output stamped by rca_agent, or None for non-recoverable
        lines (evidence is still built, but without an RCA summary).

    Returns
    -------
    dict with keys: carc_code, carc_description, rarc_code, rarc_description,
        denial_evidence (list), flag_signals (list), evidence_summary (str),
        billed_amount, denied_amount.
        All list/string fields default to empty on LLM failure.
    """
    _, carc_raw, rarc_code, _ = get_carc_rarc(ev_data)
    denial_evidence  = []
    flag_signals     = []
    evidence_summary = ""

    try:
        carc_desc_str = (rca_out.get("carc_description") if rca_out else None) or f"CARC {carc_raw}"
        rarc_desc_str = (rca_out.get("rarc_description") if rca_out else None) or ""
        rarc_line_str = f"RARC {rarc_code}: {rarc_desc_str}" if rarc_code else "No RARC code."
        rca_summary   = (
            rca_out.get("summary", "No RCA summary available.")
            if rca_out
            else "No RCA — this line is non-recoverable."
        )

        flag_lines = [
            f"  - {'MISSING' if v == 0 else 'PRESENT'}: {label}"
            for col, label in SUBMISSION_FLAG_LABELS.items()
            if (v := ev_data.get(col)) in (0, 1)
        ]

        denial_grp_ev = next(
            (label for flag, label in DENIAL_GROUP_LABELS.items() if ev_data.get(flag)),
            ev_data.get("GROUP") or "Unknown",
        )
        llm_input = (
            f"Payer: {ev_data.get('payer_name') or ev_data.get('payer_id') or 'Unknown'}\n"
            f"Denial Group: {denial_grp_ev}\n"
            f"Procedure Code: {ev_data.get('procedure_code', 'Unknown')}\n"
            f"Procedure Modifier: {ev_data.get('procedure_modifier_1') or ev_data.get('line_procedure_modifier_1') or 'None'}\n"
            f"Revenue Code: {ev_data.get('revenue_code') or 'Unknown'}\n"
            f"Principal Diagnosis: {ev_data.get('principal_diagnosis', 'Unknown')}\n"
            f"Secondary Diagnosis: {ev_data.get('diagnosis_2') or 'None'}\n"
            f"Tertiary Diagnosis: {ev_data.get('diagnosis_3') or 'None'}\n"
            f"Prior Authorization Number: {ev_data.get('prior_authorization_number') or 'None on file'}\n"
            f"Total Claim Charge: ${ev_data.get('total_claim_charge') or 0:,.2f}\n"
            f"Denied Amount: ${abs(ev_data.get('denied_amount') or 0):,.2f}\n"
            f"Service Date: {ev_data.get('service_date') or 'Unknown'}\n"
            f"Statement Period: {ev_data.get('statement_from_date') or 'Unknown'} to {ev_data.get('statement_to_date') or 'Unknown'}\n"
            f"Place of Service: {ev_data.get('place_of_service') or 'Unknown'}\n"
            f"Type of Bill: {ev_data.get('type_of_bill') or 'Unknown'}\n"
            f"Claim Filing Indicator: {ev_data.get('claim_filing_indicator') or 'Unknown'}\n"
            f"CARC {carc_raw}: {carc_desc_str}\n"
            f"{rarc_line_str}\n\n"
            f"RCA Summary: {rca_summary}\n\n"
            f"Submission Flags:\n"
            + ("\n".join(flag_lines) or "  - All required flags are present.")
        )

        logger.info("[%s] Line %s | EVIDENCE AGENT — LLM Input:\n%s", claim_id, line_num, llm_input)

        raw    = ask_llm(EVIDENCE_PROMPT, llm_input, agent_name="evidence")
        parsed = parse_llm_json(raw)

        if isinstance(parsed.get("denial_evidence"), list):
            denial_evidence = parsed["denial_evidence"]
        if isinstance(parsed.get("flag_signals"), list):
            flag_signals = parsed["flag_signals"]
        if parsed.get("evidence_summary"):
            evidence_summary = parsed["evidence_summary"]

        logger.info(
            "[%s] Line %s | EVIDENCE AGENT — LLM Output:\n  Denial Evidence: %s\n  Flag Signals: %s\n  Evidence Summary: %s",
            claim_id, line_num,
            denial_evidence,
            flag_signals,
            evidence_summary,
        )

    except Exception as exc:
        logger.warning("[%s] Line %s evidence LLM failed: %s", claim_id, line_num, exc)

    return {
        "carc_code"        : carc_raw,
        "carc_description" : (rca_out.get("carc_description") if rca_out else None),
        "rarc_code"        : ev_data.get(RARC_COLUMN),
        "rarc_description" : (rca_out.get("rarc_description") if rca_out else None),
        "denial_evidence"  : denial_evidence,
        "flag_signals"     : flag_signals if flag_signals else ["No missing submission flags identified for this denial."],
        "evidence_summary" : evidence_summary,
        "billed_amount"    : ev_data.get("total_claim_charge"),
        "denied_amount"    : ev_data.get("denied_amount"),
    }


def evidence_agent(state: dict) -> dict:
    """
    LangGraph node: build denial evidence for every non-CO/PR service line.

    Skips CO and PR lines (they follow the rule-based write-off / bill-patient path).
    For all other lines — whether RECOVERABLE, NOTrECOVERABLE, or EV_WRITE_OFF —
    calls build_line_evidence() to generate structured denial evidence via LLM.

    The evidence is stamped onto line["evidence"] so nba_agent can include it in
    the final output and in its LLM context for the NBA decision.

    Reads
    -----
    state["claim"]["service_lines"] : list[dict]
        Each line must have "GROUP", "Evidence" sub-dict, and optionally
        "rca_context" (stamped by rca_agent for RECOVERABLE lines).

    Stamps on each processed line
    ------------------------------
    line["evidence"] : dict returned by build_line_evidence()

    Writes
    ------
    state["evidence_results"] : list[dict]
        One summary dict per processed line: {line_number, carc_code,
        carc_description, rarc_code, rarc_description, denial_evidence,
        flag_signals, evidence_summary}.
    """
    claim_data       = state.get("claim", {})
    line_items       = claim_data.get("service_lines", [])
    claim_id         = state.get("claim_id", "unknown")
    evidence_results = []

    ev_lines = [
        l for l in line_items
        if str(l.get("GROUP", "")).strip().upper() not in (GROUP_CODE_CO, GROUP_CODE_PR)
    ]
    logger.info(
        "[%s] EVIDENCE AGENT | Input: %d line(s) to process (non-CO/PR) | "
        "Context: CARC+RARC + RCA summary + submission flags",
        claim_id, len(ev_lines),
    )

    for line in line_items:
        if str(line.get("GROUP", "")).strip().upper() in (GROUP_CODE_CO, GROUP_CODE_PR):
            continue

        try:
            evidence = build_line_evidence(
                claim_id,
                line.get("line_number"),
                line.get("Evidence", {}),
                line.get("rca_context"),
            )
            line["evidence"] = evidence
            logger.info(
                "[%s] Line %s | EVIDENCE AGENT | Output: %d denial evidence item(s) | "
                "%d flag signal(s) | Summary length: %d chars",
                claim_id, line.get("line_number"),
                len(evidence.get("denial_evidence", [])),
                len(evidence.get("flag_signals", [])),
                len(evidence.get("evidence_summary", "")),
            )

            evidence_results.append({
                "line_number"     : line.get("line_number"),
                "carc_code"       : evidence.get("carc_code"),
                "carc_description": evidence.get("carc_description"),
                "rarc_code"       : evidence.get("rarc_code"),
                "rarc_description": evidence.get("rarc_description"),
                "denial_evidence" : evidence.get("denial_evidence", []),
                "flag_signals"    : evidence.get("flag_signals", []),
                "evidence_summary": evidence.get("evidence_summary", ""),
            })

        except Exception as exc:
            logger.exception("Evidence failed for line %s: %s", line.get("line_number"), exc)

    logger.info(
        "[%s] EVIDENCE AGENT | Output: %d line(s) processed | "
        "Passing evidence → nba_agent via line['evidence']",
        claim_id, len(evidence_results),
    )
    state["evidence_results"] = evidence_results
    return state


def decide_nba_action(hist_probs: dict, ev_by_action: dict, similar: list) -> str:
    """
    Select the recommended recovery action using a four-level priority waterfall.

    Priority order (first decisive level wins):
      1. Higher expected value (EV) — primary signal.
      2. Higher historical success rate from hist_probs — tiebreaker when EVs are equal.
      3. Majority vote from similar recovered claims — tiebreaker when hist rates are equal.
      4. Action with the highest absolute EV — final fallback when all else is tied.

    Parameters
    ----------
    hist_probs   : dict | None
        Historical appeal/resubmit rates at the most specific available granularity
        (Payer+CARC+RARC → CARC+RARC → CARC). Keys: "appeal", "resubmit".
        Pass None when no level meets ACTION_PROB_MIN_SAMPLES.
    ev_by_action : dict
        {action_name: expected_value} from compute_expected_values().
    similar      : list[dict]
        Similar historical claim records from search_similar_lines(); each record
        should have a "recovery_channel" key.

    Returns
    -------
    str
        One of NBA_ACTION_APPEAL or NBA_ACTION_REBILL.
    """
    appeal_ev   = ev_by_action.get(NBA_ACTION_APPEAL, float("-inf"))
    resubmit_ev = ev_by_action.get(NBA_ACTION_REBILL, float("-inf"))

    if appeal_ev > resubmit_ev:
        return NBA_ACTION_APPEAL
    if resubmit_ev > appeal_ev:
        return NBA_ACTION_REBILL

    if hist_probs:
        if hist_probs.get("appeal", 0.0) > hist_probs.get("resubmit", 0.0):
            return NBA_ACTION_APPEAL
        if hist_probs.get("resubmit", 0.0) > hist_probs.get("appeal", 0.0):
            return NBA_ACTION_REBILL

    appeal_votes   = sum(1 for s in similar if s.get("recovery_channel") == RECOVERY_CHANNEL_APPEAL)
    resubmit_votes = sum(1 for s in similar if s.get("recovery_channel") == RECOVERY_CHANNEL_REBILL)
    if appeal_votes > resubmit_votes:
        return NBA_ACTION_APPEAL
    if resubmit_votes > appeal_votes:
        return NBA_ACTION_REBILL

    return max(ev_by_action, key=ev_by_action.get)


def get_nbarationale(claim_id: str, action: str, fallbackrationale: str, context: str) -> tuple:
    """
    Generate the NBA narrative and action plan via LLM using NBA_PROMPT.

    Passes the recommended action and the full 5-section context string (RCA,
    Evidence, ML output, Payer Behaviour with KPI/KRI/EBS, Financial Impact)
    to the LLM and parses payer_behavior, action_steps, recovery_drivers,
    risk_drivers, and required_corrections from the JSON response.

    Parameters
    ----------
    claim_id          : str   — used for log labels only.
    action            : str   — the action selected by decide_nba_action().
    fallbackrationale: str   — returned as payer_behavior if the LLM call fails.
    context           : str   — the full 5-section context string built by nba_agent.

    Returns
    -------
    tuple : (payer_behavior, action_steps, recovery_drivers, risk_drivers, required_corrections)
        All list fields default to [] and payer_behavior defaults to fallbackrationale
        on any LLM or parsing failure.
    """
    try:
        raw    = ask_llm(NBA_PROMPT, f"Recommended Action: {action}\n{context}", agent_name="nba")
        parsed = parse_llm_json(raw)

        payer_behavior       = parsed.get("payer_behavior") or fallbackrationale
        action_steps         = parsed.get("action_steps") or []
        recovery_drivers     = parsed.get("recovery_drivers") or []
        risk_drivers         = parsed.get("risk_drivers") or []
        required_corrections = parsed.get("required_corrections") or []

        return (
            payer_behavior,
            action_steps         if isinstance(action_steps,         list) else [],
            recovery_drivers     if isinstance(recovery_drivers,     list) else [],
            risk_drivers         if isinstance(risk_drivers,         list) else [],
            required_corrections if isinstance(required_corrections, list) else [],
        )
    except Exception as exc:
        logger.warning("[%s] NBA LLM call failed: %s", claim_id, exc)
        return fallbackrationale, [], [], [], []


def nba_agent(state: dict) -> dict:
    """
    LangGraph node: produce the final Next Best Action decision for every service line.

    Handles all four line types in a single pass:
      - CO lines → Write Off (rule-based, no model or LLM).
      - PR lines → Bill Patient (rule-based, no model or LLM).
      - NOTrECOVERABLE / EV_WRITE_OFF lines → Write Off with evidence output.
      - RECOVERABLE lines → full NBA path:
          1. Search for similar historical claims (vector store).
          2. Resolve historical appeal/resubmit rates from action_prob_table at
             the most specific available level (Payer+CARC+RARC → CARC+RARC → CARC).
          3. Select the recommended action via decide_nba_action().
          4. Build a rich 5-section LLM context (RCA, Evidence, ML output,
             Payer Behaviour with EBS/KPI/KRI, Financial Impact).
          5. Call get_nbarationale() for payer_behavior, action_steps,
             recovery_drivers, risk_drivers, required_corrections.
          6. Assemble the full line decision dict.

    Temp keys cleaned up
    --------------------
    line["_payer_signals"], line["_ev_context"], line["rca_context"] are consumed
    here and NOT forwarded to line_decisions — they exist only for inter-node communication.

    Writes
    ------
    state["line_decisions"] : list[dict]
        One complete decision dict per service line, containing claim_details,
        denialreason, executive_summary, model_output, root_cause_analysis,
        evidence, next_best_action, financial_impact, similar_case_summary,
        payer_behaviors, early_signals, and all supporting metadata fields.
    """
    claim_data   = state.get("claim", {})
    line_items   = claim_data.get("service_lines", [])
    claim_id     = state.get("claim_id", "unknown")
    lineresults = []

    logger.info(
        "[%s] NBA AGENT | Input: %d total line(s) | Groups: %s",
        claim_id, len(line_items),
        [(l.get("line_number"), str(l.get("GROUP", "")).strip().upper(),
          l.get("recovery_status", "N/A")) for l in line_items],
    )

    # Build claim-level details once from the first non-CO/PR line, emitted at state level.
    claim_details: dict | None = None
    for _ln in line_items:
        if str(_ln.get("GROUP", "")).strip().upper() not in (GROUP_CODE_CO, GROUP_CODE_PR):
            r = _ln.get("RCA", {})
            lagraw = _ln.get("ML", {}).get("submission_lag_days") or r.get("submission_lag_days")
            claim_details = {
                "claim_id"              : claim_id,
                "total_lines"           : len(line_items),
                "service_date"          : str(r.get("service_date") or ""),
                "statement_from_date"   : str(r.get("statement_from_date") or ""),
                "statement_to_date"     : str(r.get("statement_to_date") or ""),
                "place_of_service"      : r.get("place_of_service"),
                "type_of_bill"          : r.get("type_of_bill"),
                "procedure_code"        : r.get("procedure_code"),
                "procedure_modifier"    : r.get("procedure_modifier_1") or r.get("line_procedure_modifier_1"),
                "principal_diagnosis"   : r.get("principal_diagnosis"),
                "secondary_diagnosis"   : r.get("diagnosis_2"),
                "tertiary_diagnosis"    : r.get("diagnosis_3"),
                "units"                 : r.get("units"),
                "total_claim_charge"    : r.get("total_claim_charge"),
                "claim_filing_indicator": r.get("claim_filing_indicator"),
                "resubmission_indicator": bool(r.get("resubmission_indicator")),
                "submission_lag_days"   : int(lagraw) if lagraw is not None else None,
            }
            break
    state["claim_details"] = claim_details

    for line in line_items:
        group         = str(line.get("GROUP", "")).strip().upper()
        line_rca_data = line.get("RCA", {})

        try:
            flag_status = lambda v: "Present" if v == 1 else ("Absent" if v == 0 else None)

            ln = line.get("line_number")

            # CO — contractual write-off, rule-based, no model needed.
            if group == GROUP_CODE_CO:
                logger.info("[%s] Line %s — GROUP=CO", claim_id, ln)
                line["recovery_status"] = "WRITE_OFF"
                lineresults.append({
                    "line_number" : ln,
                    "group"       : group,
                    "final_action": "Write Off",
                    "groupreason": "CO — contractual write-off. The adjusted amount is the provider's contracted responsibility and is not recoverable from the payer.",
                })
                logger.info("[%s] Line %s → Write Off (CO)", claim_id, ln)
                continue

            # PR — patient responsibility, rule-based.
            if group == GROUP_CODE_PR:
                logger.info("[%s] Line %s — GROUP=PR", claim_id, ln)
                line["recovery_status"] = "PATIENTrESPONSIBILITY"
                lineresults.append({
                    "line_number" : ln,
                    "group"       : group,
                    "final_action": "Bill Patient",
                    "groupreason": "PR — patient responsibility. The amount (deductible, copay, or coinsurance) is owed by the patient, not the payer. Bill the patient directly.",
                })
                logger.info("[%s] Line %s → Bill Patient (PR)", claim_id, ln)
                continue

            # ML scored the line as not worth pursuing.
            if line.get("recovery_status") in (RECOVERY_STATUS_NOT_RECOVERABLE, RECOVERY_STATUS_EV_WRITE_OFF):
                rs   = line.get("recovery_status")
                prob = (line.get("model_output") or {}).get("recovery_probability", 0)
                lineresults.append({
                    "line_number"    : ln,
                    "group"          : group,
                    "recovery_status": rs,
                    "model_output"   : line.get("model_output", {}),
                    "evidence"       : line.get("evidence"),
                    "final_action"   : "Write Off",
                    "groupreason"   : "Line did not meet recovery criteria.",
                })
                logger.info("[%s] Line %s → Write Off (%s, prob=%.4f)", claim_id, ln, rs, prob)
                continue

            # RECOVERABLE — run full NBA logic.
            if line.get("recovery_status") == RECOVERY_STATUS_RECOVERABLE:
                ev_data       = line.get("Evidence", {})
                payer_signals = line.get("_payer_signals") or {}
                model_out     = line.get("model_output", {})
                rca_out       = line.get("root_cause_analysis") or {}

                mergedrow    = {**line.get("ML", {}), **line.get("RCA", {}), **ev_data, "GROUP": group}
                similar_cases = search_similar_lines(mergedrow, exclude_claim_id=claim_id)

                # Resolve hist_probs at the most specific available level.
                carc_int, carc_raw, rarc_code, rarc_raw = get_carc_rarc(line_rca_data)
                payer_id  = str(line_rca_data.get("payer_id") or ev_data.get("payer_id") or "")
                entry      = action_prob_table.get(carc_int, {})
                hist_probs = None

                if payer_id and rarc_code:
                    candidate = (
                        entry.get("by_payer", {})
                             .get(payer_id, {})
                             .get("by_rarc", {})
                             .get(rarc_code, {})
                    )
                    if candidate.get("sample_count", 0) >= ACTION_PROB_MIN_SAMPLES:
                        hist_probs = candidate

                if hist_probs is None and rarc_code:
                    candidate = entry.get("by_rarc", {}).get(rarc_code, {})
                    if candidate.get("sample_count", 0) >= ACTION_PROB_MIN_SAMPLES:
                        hist_probs = candidate

                if hist_probs is None and entry.get("sample_count", 0) >= ACTION_PROB_MIN_SAMPLES:
                    hist_probs = entry

                ev_by_action = line.get("_ev_context") or {}
                nba_action   = decide_nba_action(hist_probs, ev_by_action, similar_cases)

                recovery_prob = model_out.get("recovery_probability", 0)
                denied_amount = abs(ev_data.get("denied_amount") or 0)
                nba_ev        = ev_by_action.get(nba_action, 0)

                # ── Similar-case summary (needed by context_str below) ────────
                recovered_cases     = [s for s in similar_cases if s.get("outcome") == "Recovered"]
                notrecovered_cases = [s for s in similar_cases if s.get("outcome") != "Recovered"]
                recoveryrate_pct   = (
                    f"{len(recovered_cases) / len(similar_cases):.0%}" if similar_cases else "0%"
                )
                action_votes = {}
                for s in recovered_cases:
                    ch = s.get("recovery_channel")
                    if ch:
                        action_votes[ch] = action_votes.get(ch, 0) + 1
                most_successful = max(action_votes, key=action_votes.get) if action_votes else nba_action

                evidence_out  = line.get("evidence", {})
                top_features_nba = model_out.get("top_shap_drivers") or []
                nba_feature_lines = "\n".join(
                    f"  - {f['feature']} = {f['value']} (contribution={f['contribution']})"
                    for f in top_features_nba
                ) or "  - No SHAP drivers available."

                # ── Payer behaviour categories with confidence ────────────────
                behav_lines = []
                for cat, flags in PAYER_BEHAVIOR_CATEGORIES.items():
                    for f in flags:
                        if payer_signals.get(f):
                            conf_key = f.replace("_flag", "_confidence")
                            conf_val = payer_signals.get(conf_key)
                            conf_str = f" (confidence={conf_val:.2f})" if conf_val is not None else ""
                            behav_lines.append(f"  - [{cat}] {f.replace('_flag','').upper()}{conf_str}")
                behav_block = "\n".join(behav_lines) or "  - No active behavior flags."

                # ── EBS: quantitative early signal values ─────────────────────
                ebs_lines = []
                for ebs_key, meta in EBS_SIGNAL_METRICS.items():
                    parts = [
                        f"{alias}={payer_signals[col]}"
                        for col, alias in meta["fields"]
                        if col in payer_signals
                    ]
                    if parts:
                        ebs_lines.append(f"  {meta['label']}: {', '.join(parts)}")
                ebs_block = "\n".join(ebs_lines) or "  - No EBS signals available."

                # ── KPI at payer+CARC level (all 4 granularity tiers) ─────────
                carc_entry_nba = action_prob_table.get(carc_int, {})
                payer_entry_nba = carc_entry_nba.get("by_payer", {}).get(payer_id, {})

                def rate_line(label, d):
                    if not d or d.get("sample_count", 0) == 0:
                        return f"  {label}: Insufficient data."
                    return (
                        f"  {label}: Appeal={d.get('appeal', 0):.0%}, "
                        f"Resubmit={d.get('resubmit', 0):.0%}, n={d.get('sample_count', 0)}"
                    )

                carc_rarc_entry = carc_entry_nba.get("by_rarc", {}).get(rarc_code, {}) if rarc_code else {}
                payer_carc_entry = payer_entry_nba
                payer_carc_rarc_entry = payer_entry_nba.get("by_rarc", {}).get(rarc_code, {}) if rarc_code and payer_entry_nba else {}

                kpi_block = "\n".join([
                    rate_line(f"CARC {carc_raw} overall",           carc_entry_nba),
                    rate_line(f"CARC {carc_raw}+RARC {rarc_code}",  carc_rarc_entry),
                    rate_line(f"Payer+CARC {carc_raw}",             payer_carc_entry),
                    rate_line(f"Payer+CARC {carc_raw}+RARC {rarc_code}", payer_carc_rarc_entry),
                ])

                # ── KRI and KPI operational — from payer-level lookup table ──
                payer_kri_kpi = payer_kri_kpi_table.get(str(payer_id), {})
                kri_lines = []
                for kri_label, fields in KRI_FIELD_MAPPINGS.items():
                    parts = [
                        f"{alias}={payer_kri_kpi[col]}"
                        for col, alias in fields
                        if col in payer_kri_kpi and payer_kri_kpi[col] is not None
                    ]
                    if parts:
                        kri_lines.append(f"  {kri_label}: {', '.join(parts)}")
                kri_block = "\n".join(kri_lines) or "  - KRI data not available."

                kpi_op_lines = []
                for kpi_label, fields in KPI_FIELD_MAPPINGS.items():
                    parts = [
                        f"{alias}={payer_kri_kpi[col]}"
                        for col, alias in fields
                        if col in payer_kri_kpi and payer_kri_kpi[col] is not None
                    ]
                    if parts:
                        kpi_op_lines.append(f"  {kpi_label}: {', '.join(parts)}")
                kpi_op_block = "\n".join(kpi_op_lines) or "  - KPI operational data not available."

                evranked = "\n".join(
                    f"  - {a}: ${v:,.2f}" for a, v in sorted(ev_by_action.items(), key=lambda x: -x[1])
                ) or "  - No EV data."
                hist_summary = (
                    f"  Similar claims retrieved: {len(similar_cases)}\n"
                    f"  Recovery rate: {recoveryrate_pct}\n"
                    f"  Most successful action: {most_successful}\n"
                    f"  Individual similar cases:\n" +
                    "\n".join(
                        f"    * {s.get('payer_name') or s.get('payer_id') or 'Unknown payer'} | "
                        f"CARC {s.get('carc_code')} | outcome={s.get('outcome')} | "
                        f"channel={s.get('recovery_channel')} | sim={s.get('cosine_similarity')}"
                        for s in similar_cases[:5]
                    )
                ) if similar_cases else "  No similar cases found."

                context_str = (
                    f"=== RCA OUTPUT ===\n"
                    f"Payer: {line_rca_data.get('payer_name') or line_rca_data.get('payer_id') or 'Unknown'}\n"
                    f"Denial Group: {group}\n"
                    f"CARC {carc_raw}: {rca_out.get('carc_description', '')}\n"
                    f"RARC {rarc_raw}: {rca_out.get('rarc_description', '') or 'N/A'}\n"
                    f"Root Cause Summary: {rca_out.get('summary', 'Not available.')}\n"
                    f"\n=== EVIDENCE OUTPUT ===\n"
                    f"Evidence Summary: {evidence_out.get('evidence_summary', 'Not available.')}\n"
                    f"Denial Evidence:\n" +
                    "\n".join(f"  - {e}" for e in (evidence_out.get("denial_evidence") or [])) +
                    f"\nFlag Signals:\n" +
                    "\n".join(f"  - {s}" for s in (evidence_out.get("flag_signals") or [])) +
                    f"\nResolution History:\n{hist_summary}\n"
                    f"\n=== ML MODEL OUTPUT ===\n"
                    f"Recovery Probability: {recovery_prob:.1%}\n"
                    f"ML Prediction: {model_out.get('ml_prediction', 'Unknown')}\n"
                    f"Top Contributing Features (SHAP):\n{nba_feature_lines}\n"
                    f"\n=== PAYER BEHAVIOUR ===\n"
                    f"Payer Name: {line_rca_data.get('payer_name') or 'Unknown'}\n"
                    f"Payer ID: {line_rca_data.get('payer_id') or 'Unknown'}\n"
                    f"Behavior Signals (B01-B12):\n{behav_block}\n"
                    f"Early Behavior Signals (EBS E01-E03):\n{ebs_block}\n"
                    f"KPI — Historical Recovery Rates (payer+CARC level):\n{kpi_block}\n"
                    f"KPI — Operational Payer Metrics:\n{kpi_op_block}\n"
                    f"KRI — Payer Risk Indicators:\n{kri_block}\n"
                    f"\n=== FINANCIAL IMPACT ===\n"
                    f"Denied Amount: ${denied_amount:,.2f}\n"
                    f"Expected Value by Action (ranked):\n{evranked}\n"
                )
                logger.info("[%s] Line %s | NBA AGENT — LLM Input:\n%s", claim_id, ln, context_str)
                payer_behavior, action_steps, recovery_drivers, risk_drivers, required_corrections = get_nbarationale(
                    claim_id,
                    nba_action,
                    f"Pursue {nba_action} based on recovery analysis.",
                    context_str,
                )
                logger.info(
                    "[%s] Line %s | NBA AGENT — LLM Output:\n  Recommended Action: %s\n  Payer Behaviour: %s\n  Action Steps: %s",
                    claim_id, ln,
                    nba_action,
                    payer_behavior,
                    action_steps,
                )

                # ── Confidence tier ──────────────────────────────────────────
                confidence = "High" if recovery_prob >= 0.8 else ("Medium" if recovery_prob >= 0.5 else "Low")

                # ── Payer behaviour flags with confidence ────────────────────
                payer_behavior_flags: dict = {}
                for cat, flags in PAYER_BEHAVIOR_CATEGORIES.items():
                    triggered = []
                    for f in flags:
                        if payer_signals.get(f):
                            conf_key = f.replace("_flag", "_confidence")
                            conf = payer_signals.get(conf_key)
                            entry: dict = {"code": f.replace("_flag", "").upper()}
                            if conf is not None:
                                entry["confidence"] = round(float(conf), 3)
                            triggered.append(entry)
                    if triggered:
                        payer_behavior_flags[cat] = triggered

                # ── Active EBS signals (flag=1 only, with quantitative values) ─
                active_ebs: dict = {}
                for ebs_key, ebs_meta in EBS_SIGNAL_METRICS.items():
                    flag_col = f"{ebs_key}_flag"
                    if payer_signals.get(flag_col):
                        ebs_vals: dict = {"label": ebs_meta["label"]}
                        for col, alias in ebs_meta["fields"]:
                            if col != flag_col and payer_signals.get(col) is not None:
                                ebs_vals[alias] = payer_signals[col]
                        active_ebs[ebs_key.upper()] = ebs_vals

                # ── KPI — historical recovery rates at all 4 granularity levels ─
                payer_kpi: dict = {}
                for kpi_label, kpi_entry in [
                    (f"CARC {carc_raw} overall",                carc_entry_nba),
                    (f"CARC {carc_raw}+RARC {rarc_code}",       carc_rarc_entry),
                    (f"Payer+CARC {carc_raw}",                  payer_carc_entry),
                    (f"Payer+CARC {carc_raw}+RARC {rarc_code}", payer_carc_rarc_entry),
                ]:
                    if kpi_entry and kpi_entry.get("sample_count", 0) > 0:
                        payer_kpi[kpi_label] = {
                            "appealrate"  : f"{kpi_entry.get('appeal', 0):.0%}",
                            "resubmitrate": f"{kpi_entry.get('resubmit', 0):.0%}",
                            "n"            : kpi_entry.get("sample_count", 0),
                        }

                # ── KRI — payer risk indicators from payer-level lookup ────────
                payer_kri: dict = {}
                for kri_label, kri_fields in KRI_FIELD_MAPPINGS.items():
                    kri_vals: dict = {}
                    for col, alias in kri_fields:
                        val = payer_kri_kpi.get(col)
                        if val is not None:
                            kri_vals[alias] = val
                    if kri_vals:
                        payer_kri[kri_label] = kri_vals

                payer_behaviors = {
                    "behavior_flags"           : payer_behavior_flags,
                    "early_behavior_signals"   : active_ebs,
                    "historicalrecoveryrates": payer_kpi,
                    "risk_indicators"          : payer_kri,
                }

                # ── Claim status label ────────────────────────────────────────
                raw_status = line_rca_data.get("claim_final_status")
                status_label = (
                    CLAIM_STATUS_LABELS.get(str(raw_status).upper())
                    or (str(raw_status) if raw_status else None)
                )
                lineresults.append({
                    "line_number"    : line.get("line_number"),
                    "group"          : group,
                    "denialreason"  : {
                        "carc_code"       : carc_int,
                        "carc_description": rca_out.get("carc_description"),
                        "rarc_code"       : rarc_code,
                        "rarc_description": rca_out.get("rarc_description"),
                    },
                    "executive_summary": {
                        "claim_id"           : claim_id,
                        "recovery_probability": f"{recovery_prob:.0%}",
                        "predicted_status"   : "Recoverable",
                        "recommended_action" : nba_action,
                        "denied_amount"      : denied_amount,
                        "expectedrecovery"  : nba_ev,
                        "confidence"         : confidence,
                        "primaryroot_cause"  : rca_out.get("primaryroot_cause") or None,
                        "secondaryroot_cause": rca_out.get("secondaryroot_cause") or None,
                    },
                    "model_output"        : model_out,
                    "recovery_drivers"    : recovery_drivers,
                    "risk_drivers"        : risk_drivers,
                    "required_corrections": required_corrections,
                    "recovery_status"     : line.get("recovery_status"),
                    "root_cause_analysis" : rca_out,
                    "evidence"            : line.get("evidence"),
                    "next_best_action"    : {
                        "recommended_action": nba_action,
                        "payer_behavior"    : payer_behavior,
                        "action_steps"      : action_steps,
                    },
                    "payer_behaviors"     : payer_behaviors,
                    "claim_status"        : {
                        "claim_final_status": status_label,
                        "raw_value"         : raw_status,
                    },
                    "filing_limit_info"   : {
                        "submission_lag_days"   : int(_sl) if (_sl := (line.get("ML", {}).get("submission_lag_days") or line_rca_data.get("submission_lag_days"))) is not None else None,
                        "late_submission_flag"  : flag_status(payer_signals.get("b11_flag")),
                        "resubmission_indicator": bool(line_rca_data.get("resubmission_indicator")),
                    },
                    "payer_information"   : {
                        "payer_name"             : line_rca_data.get("payer_name"),
                        "payer_id"               : line_rca_data.get("payer_id"),
                        "claim_filing_indicator" : line_rca_data.get("claim_filing_indicator"),
                    },
                    "provider_information": {
                        "billing_provider_npi_present"  : flag_status(line_rca_data.get("has_billing_provider_npi")),
                        "rendering_provider_npi_present": flag_status(line_rca_data.get("has_rendering_provider_npi")),
                        "billing_provider_taxonomy"     : line_rca_data.get("billing_provider_taxonomy"),
                        "billing_provider_state"        : line_rca_data.get("billing_provider_state"),
                        "facility_code"                 : line_rca_data.get("facility_code_value"),
                        "subscriber_state"              : line_rca_data.get("subscriber_state"),
                    },
                    "authorization_status": {
                        "prior_authorization_present": bool(line_rca_data.get("has_prior_auth")),
                        "prior_authorization_number" : line_rca_data.get("prior_authorization_number"),
                        "modifier_present"           : flag_status(line_rca_data.get("has_modifier")),
                        "attachment_present"         : flag_status(line_rca_data.get("has_attachment")),
                        "secondary_diagnosis_present": flag_status(line_rca_data.get("has_secondary_diagnosis")),
                    },
                    "resolution_history"  : {
                        "similar_claimsretrieved": len(similar_cases),
                        "cases"                   : [
                            {
                                "carc"               : s.get("CARC"),
                                "rarc"               : s.get("RARC"),
                                "procedure_code"     : s.get("procedure_code"),
                                "principal_diagnosis": s.get("principal_diagnosis"),
                                "outcome"            : s.get("outcome"),
                                "recovery_channel"   : s.get("recovery_channel"),
                                "payer"              : s.get("payer_name") or s.get("payer_id"),
                                "similarity_score"   : s.get("cosine_similarity"),
                            }
                            for s in similar_cases[:5]
                        ],
                    },
                    "financial_impact"    : {
                        "denied_amount"          : denied_amount,
                        "expected_value_by_action": {a: round(v, 2) for a, v in ev_by_action.items()},
                        "recommended_action"     : nba_action,
                        "recommended_action_ev"  : round(nba_ev, 2),
                        "ev_summary"             : (
                            f"Recommended action '{nba_action}' yields an expected net return of "
                            f"${nba_ev:,.2f} on a denied amount of ${denied_amount:,.2f} (staff cost deducted)."
                        ),
                    },
                    "similar_case_summary": {
                        "total_cases"        : len(similar_cases),
                        "recovered"          : len(recovered_cases),
                        "notrecovered"      : len(notrecovered_cases),
                        "recoveryrate"      : recoveryrate_pct,
                        "most_successful_action": most_successful,
                    },
                })
                logger.info(
                    "[%s] Line %s → %s (Recoverable, prob=%.4f)",
                    claim_id, ln, nba_action, recovery_prob,
                )
                continue

            # Fallback — should not be reached in normal operation.
            lineresults.append({
                "line_number" : line.get("line_number"),
                "group"       : group,
                "final_action": "Review Manually",
                "groupreason": "Line could not be assigned to a recovery decision.",
            })

        except Exception as exc:
            logger.exception("NBA failed for line %s: %s", line.get("line_number"), exc)
            lineresults.append({
                "line_number" : line.get("line_number"),
                "group"       : group,
                "final_action": "Review Manually",
                "groupreason": "NBA processing failed — manual review required.",
            })

    # Clean up temporary inter-agent data from service lines.
    for line in line_items:
        for key in ("_ev_context", "retrieval_context", "rca_context", "_payer_signals"):
            line.pop(key, None)

    decision_summary = [
        (
            r.get("line_number"),
            r.get("group"),
            r.get("final_action") or (r.get("next_best_action") or {}).get("recommended_action"),
            r.get("recovery_status"),
        )
        for r in lineresults
    ]
    logger.info(
        "[%s] NBA AGENT | Output: %d line decision(s) | Summary: %s",
        claim_id, len(lineresults), decision_summary,
    )

    state["line_decisions"] = lineresults
    return state



